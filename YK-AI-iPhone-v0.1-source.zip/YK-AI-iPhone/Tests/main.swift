import Foundation

// Run with scripts/check-mac.command on a Mac. These tests do not contact a server,
// request a location, or require Apple Intelligence to be enabled.
func check(_ condition: @autoclosure () -> Bool, _ label: String) {
    guard condition() else { fatalError("FAIL: \(label)") }
    print("PASS: \(label)")
}

check(OutingIntent.query(from: "近くのカフェを探して") == "カフェ", "nearby place request")
check(OutingIntent.query(from: "新宿駅まで案内して") == "新宿駅", "named destination")
check(OutingIntent.query(from: "周辺のトイレはどこ？") == "公衆トイレ", "public toilet request")
check(OutingIntent.query(from: "カフェの歴史を教えて") == nil, "general questions stay in chat")
check(OutingIntent.query(from: "僕は近くのカフェが好き") == nil, "casual conversation does not request a search")
check(OutingIntent.query(from: "まで案内して") == nil, "empty destination does not launch navigation")
check(OutingIntent.query(from: String(repeating: "近く", count: 200) + "カフェを探して") == nil,
      "oversized input is not routed")

let history = [Message(role: "user", text: "近くのカフェを探して"),
               Message(role: "assistant", text: "場所を探すボタンから確認してね"),
               Message(role: "user", text: "はなそ"),
               Message(role: "assistant", text: "うん、僕もお話ししたいな！"),
               Message(role: "user", text: "未完了の質問")]
let recent = ConversationContext.recent(history, characterLimit: 20)
check(recent.reduce(0) { $0 + $1.text.count } <= 20, "context respects the character budget")
check(recent.map(\.role) == ["user", "assistant"] && recent.first?.text == "はなそ",
      "latest completed exchange retains native speaker roles")
check(!recent.contains { $0.text.contains("カフェ") }, "whole oldest pair drops when budget is full")
check(ConversationContext.recent([], characterLimit: 0).isEmpty, "empty history")
check(ConversationContext.recent(history, characterLimit: 1).isEmpty,
      "oversized exchange never leaves an orphan response")
let failed = [Message(role: "user", text: "失敗した質問"),
              Message(role: "assistant", text: "途中の返答", completed: false),
              Message(role: "user", text: "次の質問"),
              Message(role: "assistant", text: "完了した返答", completed: true)]
check(ConversationContext.recent(failed).map(\.text) == ["次の質問", "完了した返答"],
      "interrupted replies are saved but excluded from subsequent context")
let unanswered = [Message(role: "user", text: "回答なし"),
                  Message(role: "user", text: "ねーねー"),
                  Message(role: "assistant", text: "ん、どうしたの？")]
check(ConversationContext.recent(unanswered).first?.text == "ねーねー",
      "consecutive user messages do not get merged or assigned to the wrong reply")
check(ConversationContext.recent(history, after: history[1].id).map(\.text)
      == ["はなそ", "うん、僕もお話ししたいな！"], "new topic excludes earlier cafe exchange")
check(ConversationContext.recent(history, after: history.last!.id).isEmpty,
      "new topic begins with no old transcript")
check(ConversationContext.recent(history, after: UUID()).isEmpty,
      "missing topic boundary does not revive unrelated history")

let state = SavedState(messages: history, preferences: Preferences(), memoryNote: "紅茶が好き",
                       contextAfterMessageID: history[1].id)
let data = try JSONEncoder().encode(state)
let restored = try JSONDecoder().decode(SavedState.self, from: data)
var chatBook = try ChatLibrary(migrating: restored)
let legacyChatID = chatBook.selectedID
check(chatBook.selected.messages == history && chatBook.selected.contextAfterMessageID == history[1].id,
      "chat migration preserves every old message and topic boundary")
chatBook.update(messages: history, boundary: history[1].id, archives: [], draft: "書きかけ")
chatBook.create()
let secondChatID = chatBook.selectedID
check(chatBook.selected.messages.isEmpty && chatBook.selected.draft.isEmpty && chatBook.selected.archives.isEmpty,
      "new chat starts with no transcript draft attachments or edit archives")
check(ConversationContext.recent(chatBook.selected.messages).isEmpty,
      "new chat cannot leak another chat into model context")
let separate = [Message(role: "user", text: "別の話"), Message(role: "assistant", text: "うんっ")]
chatBook.update(messages: separate, boundary: nil, archives: [], draft: "別の下書き")
chatBook.rename(secondChatID, to: "  おでかけ  ")
check(chatBook.select(legacyChatID) && chatBook.selected.messages == history && chatBook.selected.draft == "書きかけ",
      "switching back restores original messages and unsent draft")
check(!chatBook.select(UUID()) && chatBook.selectedID == legacyChatID,
      "missing chat id cannot break current selection")
let multistate = SavedState(version: 2, preferences: Preferences(), memoryNote: "共通メモ", chatLibrary: chatBook)
let multiRestored = try JSONDecoder().decode(SavedState.self, from: JSONEncoder().encode(multistate))
let multiBook = try ChatLibrary(migrating: multiRestored)
check(multiBook == chatBook && multiRestored.memoryNote == "共通メモ",
      "all chat sessions selection names and drafts survive restart")
check(multiBook.chats.first(where: { $0.id == secondChatID })?.title == "おでかけ",
      "renaming one chat does not overwrite another")
let sharedImage = ImageAttachment(recognizedText: "資料")
let photoMessage = Message(role: "user", text: "写真", attachment: sharedImage)
let editSnapshot = ConversationArchive(editedMessageID: photoMessage.id, messages: [photoMessage], contextAfterMessageID: nil)
chatBook.update(messages: history, boundary: nil, archives: [editSnapshot], draft: "")
chatBook.select(secondChatID)
chatBook.update(messages: [photoMessage], boundary: nil, archives: [], draft: "")
check(chatBook.remove(secondChatID).isEmpty && chatBook.selectedID == legacyChatID,
      "deleting a chat retains an image referenced in another edit archive")
check(chatBook.remove(legacyChatID) == [sharedImage.id] && chatBook.chats.count == 1 && chatBook.selected.messages.isEmpty,
      "deleting final chat identifies orphaned images and leaves usable blank chat")
do {
    _ = try ChatLibrary(migrating: SavedState(version: 2))
    fatalError("Missing version 2 chat library must not erase data")
} catch { print("PASS: damaged v2 library is rejected without overwriting legacy data") }
check(Preferences().profileInstruction.contains("男性"), "owner's stated male profile is explicit rather than inferred from image")
var unknownProfile = Preferences(); unknownProfile.userGender = "unspecified"
check(!unknownProfile.profileInstruction.contains("男性と"), "profile can be unset without forcing a gender")
let groundedPhoto = ImageAttachment(recognizedText: "", visualDescription: "黒い髪。グレーのコートと白いシャツ。金色のピン。")
check(PhotoReaction.isGrounded("わ、似合ってるね！\nグレーのコートと白いシャツの組み合わせ、僕好きだなぁ。", evidence: "グレーのコート", photo: groundedPhoto),
      "grounded affectionate reaction is allowed")
check(!PhotoReaction.isGrounded("胸もお尻も大きくて太ってるし、イケメン！", evidence: "グレーのコート", photo: groundedPhoto),
      "reported body fabrication never reaches display or speech")
check(!PhotoReaction.isGrounded("白いズボンが似合うね。", evidence: "グレーのコート", photo: groundedPhoto),
      "unseen trousers regression is rejected")
check(!PhotoReaction.isGrounded("青い帽子、好きだな。", evidence: "青い帽子", photo: groundedPhoto),
      "invented evidence is rejected")
check(!PhotoReaction.isGrounded("可愛い女の子だね。", evidence: "黒い髪", photo: groundedPhoto),
      "photo reactions do not assign a gender from appearance")
check(PhotoReaction.concise(response: "わぁ！似合うね！", impression: "僕、この色好き。もう一つ。三つ目。", short: true)
      == "わぁ！\n僕、この色好き。", "short photo reaction contains two complete sentences")
check(!PhotoReaction.prompt("どうよ", photo: groundedPhoto,
      history: [Message(role: "assistant", text: "古い身体の作り話")], memo: "").contains("古い身体の作り話"),
      "photo response does not repeat earlier model fabrications")
check(restored.messages == history && restored.memoryNote == state.memoryNote, "Japanese history survives a save/load round trip")
check(restored.preferences.personality == "devoted", "default personality is preserved")
check(restored.contextAfterMessageID == history[1].id, "topic boundary persists across restart")
let restoredFailed = try JSONDecoder().decode([Message].self, from: JSONEncoder().encode(failed))
check(restoredFailed == failed, "partial replies and completion status survive storage")
var legacy = try JSONSerialization.jsonObject(with: data) as! [String: Any]
legacy.removeValue(forKey: "contextAfterMessageID")
legacy["messages"] = (legacy["messages"] as! [[String: Any]]).map { item in
    var previous = item
    previous.removeValue(forKey: "completed")
    return previous
}
let oldState = try JSONDecoder().decode(SavedState.self, from: JSONSerialization.data(withJSONObject: legacy))
check(oldState.messages == history && oldState.contextAfterMessageID == nil,
      "0.1.3 history migrates without deleting messages or changing settings")
let previousPreferences = Data("{\"name\":\"ゆきAI\",\"personality\":\"romance\",\"readAloud\":false,\"emoji\":false}".utf8)
let migrated = try JSONDecoder().decode(Preferences.self, from: previousPreferences)
check(migrated.shortReplies && migrated.personality == "romance" && !migrated.emoji,
      "adding reply speed preference preserves previous saved settings")
check(migrated.voiceEngine == "system" && migrated.backgroundAudio && !migrated.voiceConversation,
      "old settings do not unexpectedly switch voices or auto-send microphone input")
var custom = migrated
custom.personality = "custom"
custom.customPersonality = "一人称は僕、甘えん坊で話して"
custom.voiceEngine = "voicevox"
custom.voiceStyle = 32
custom.voiceSpeed = 1.15
custom.voicePitch = 0.02
custom.voiceConversation = true
let restoredCustom = try JSONDecoder().decode(Preferences.self, from: JSONEncoder().encode(custom))
check(restoredCustom == custom,
      "custom tone and voice settings survive restart")
check(PersonalityRequest.proposal(from: custom.customPersonality) == custom.customPersonality,
      "explicit tone request proposes a custom setting")
check(PersonalityRequest.proposal(from: "甘えん坊ってどういう性格？") == nil,
      "questions about personalities do not change settings")
check(PersonalityRequest.proposal(from: "友達が「甘えん坊にして」と言った") == nil,
      "quoted instructions do not propose persistent preferences")
check(PersonalityRequest.proposal(from: "/性格 いつも落ち着いた声で") == "いつも落ち着いた声で",
      "explicit command accepts arbitrary user-authored tone")
check(PersonalityRequest.proposal(from: "/性格 " + String(repeating: "あ", count: 401)) == nil,
      "oversized personality is not silently truncated on proposal")
let route = TransitRequest.parse("新宿駅から東京駅まで電車で行きたい")
check(route == TransitRequest(origin: "新宿駅", destination: "東京駅"), "train request extracts both places")
check(TransitRequest.parse("電車で本を読むのが好き") == nil, "casual train conversation stays in chat")
check(TransitRequest.parse("終電は何時？") == TransitRequest(timeMode: .last), "unspecified station asks for editable route")
check(TransitRequest(destination: "   ").googleURL == nil, "empty route cannot open maps")
let special = TransitRequest(origin: "A&B駅", destination: "東京駅 #1")
let routeComponents = URLComponents(url: special.googleURL!, resolvingAgainstBaseURL: false)!
check(routeComponents.host == "www.google.com" && routeComponents.queryItems?.first(where: { $0.name == "origin" })?.value == "A&B駅"
      && routeComponents.queryItems?.first(where: { $0.name == "destination" })?.value == "東京駅 #1",
      "map URL safely preserves Japanese and query metacharacters")
let text = "こんにちは。今日は何を話そう？" + String(repeating: "猫", count: 200)
let chunks = SpeechText.chunks(text)
check(chunks.joined() == text && chunks.allSatisfy { $0.count <= 120 }, "speech chunks preserve every character within the bound")
let attached = Message(role: "user", text: "ここどこ？", attachment: ImageAttachment(recognizedText: "東京駅"))
let attachedData = try JSONEncoder().encode(attached)
let restoredAttachment = try JSONDecoder().decode(Message.self, from: attachedData)
check(restoredAttachment == attached,
      "photo reference and recognized Japanese text survive storage")
check(!String(decoding: attachedData, as: UTF8.self).contains("latitude"), "saved attachment reference has no GPS metadata")
let photoPair = [Message(role: "user", text: "画像", attachment: ImageAttachment(recognizedText: String(repeating: "駅", count: 500))),
                 Message(role: "assistant", text: "地名")]
check(ConversationContext.recent(photoPair, characterLimit: 100).isEmpty,
      "image reference text counts toward context budget")
let editableHistory = [history[0], history[1], attached,
                       Message(role: "assistant", text: "東京駅の文字があります"),
                       Message(role: "user", text: "別の話"),
                       Message(role: "assistant", text: "以前の続き", completed: false)]
let edit = ConversationEdit.prepare(messages: editableHistory, after: history[1].id,
                                    replacing: attached.id, with: "  看板には何て書いてある？  ")!
check(edit.replacement.text == "看板には何て書いてある？" && edit.replacement.id != attached.id,
      "edited message trims whitespace and gets a new identity")
check(edit.replacement.attachment == attached.attachment, "editing retains the original photo and OCR")
check(edit.prefix == Array(editableHistory.prefix(2)), "editing removes old answer and later turns from active context")
check(edit.archive.messages == editableHistory, "archive preserves original text, later turns, and partial replies")
check(edit.boundary == history[1].id && ConversationContext.recent(edit.prefix, after: edit.boundary).isEmpty,
      "editing retains an earlier topic boundary")
let laterReset = ConversationEdit.prepare(messages: editableHistory, after: editableHistory.last!.id,
                                          replacing: attached.id, with: "文字を読んで")!
check(ConversationContext.recent(laterReset.prefix, after: laterReset.boundary).isEmpty,
      "editing before a topic reset never revives discarded context")
let firstEdit = ConversationEdit.prepare(messages: editableHistory, after: editableHistory.last!.id,
                                         replacing: history[0].id, with: "近くの公園を探して")!
check(firstEdit.prefix.isEmpty && firstEdit.boundary == nil, "first-message edit starts an empty context")
check(ConversationEdit.prepare(messages: editableHistory, after: nil, replacing: attached.id, with: " \n ") == nil,
      "blank edit is rejected")
check(ConversationEdit.prepare(messages: editableHistory, after: nil, replacing: attached.id, with: attached.text) == nil,
      "unchanged edit does not create an archive or retry")
check(ConversationEdit.prepare(messages: editableHistory, after: nil, replacing: attached.id,
                               with: String(repeating: "あ", count: 601)) == nil, "oversized edit is rejected")
check(ConversationEdit.prepare(messages: editableHistory, after: nil, replacing: history[1].id, with: "書き換え") == nil,
      "assistant messages cannot be edited as user messages")
check(ConversationEdit.prepare(messages: editableHistory, after: nil, replacing: UUID(), with: "書き換え") == nil,
      "stale editor does not replace an unrelated message")
var revisedState = state
revisedState.messages = edit.prefix + [edit.replacement]
revisedState.conversationArchives = [edit.archive]
let restoredRevised = try JSONDecoder().decode(SavedState.self, from: JSONEncoder().encode(revisedState))
check(restoredRevised.messages == revisedState.messages && restoredRevised.conversationArchives == [edit.archive],
      "active edit and original conversation survive a save/load round trip together")
check(oldState.conversationArchives == nil, "pre-editing save files load with no archives")
let oldPhotoData = Data("{\"id\":\"00000000-0000-0000-0000-000000000001\",\"recognizedText\":\"東京駅\"}".utf8)
let oldPhoto = try JSONDecoder().decode(ImageAttachment.self, from: oldPhotoData)
check(oldPhoto.visualDescription == nil && oldPhoto.textOnly == nil,
      "old photos load without inventing a visual analysis or silently opting into text-only")
var described = oldPhoto
described.visualDescription = "木の机の上に麺と揚げ物がある。"
described.visualModel = "Qwen3-VL-2B-Instruct-4bit"
let recoveredPhoto = try JSONDecoder().decode(ImageAttachment.self, from: JSONEncoder().encode(described))
check(recoveredPhoto == described, "visual observation and its model persist alongside OCR")
check(described.reference(limit: 1100).contains("麺と揚げ物") && described.reference(limit: 1100).contains("東京駅"),
      "conversation reference includes visual content and OCR instead of only repeating the question")
check(oldPhoto.reference(limit: 300).contains("見た目は未解析"), "OCR-only references explicitly disclose missing visual information")
described.visualDescription = (1...40).map { "写真の\($0)番目の札が並んでいる。" }.joined()
let describedPair = [Message(role: "user", text: "これどう？", attachment: described), Message(role: "assistant", text: "猫だね")]
check(ConversationContext.recent(describedPair, characterLimit: 100).isEmpty,
      "visual descriptions count toward the history budget")
check(described.reference(limit: 300).count == 300 && described.reference(limit: 0).isEmpty,
      "visual history is bounded without corrupting stored observation")
let photoEdit = ConversationEdit.prepare(messages: describedPair, after: nil, replacing: describedPair[0].id, with: "何が写ってる？")!
check(photoEdit.replacement.attachment == described && photoEdit.archive.messages == describedPair,
      "editing retains image recognition and its original archive")
let plainRequest = "今日はどうだった？"
check(ConversationPrompt.message(plainRequest) == plainRequest,
      "plain chat does not acquire a photo task or synthetic conversation")
let captionRequest = ConversationPrompt.message("これどう？", memo: "青が好き", attachment: recoveredPhoto)
check(captionRequest.hasSuffix("【相手の発言】\nこれどう？") && captionRequest.contains("麺と揚げ物"),
      "the photo remains context and the actual user request comes last")
let longReference = ConversationPrompt.message("最新の質問", memo: String(repeating: "覚", count: 500),
                                               attachment: described, referenceLimit: 100)
check(longReference.filter { $0 == "覚" }.count == 400 && longReference.filter { $0 == "猫" }.count <= 100
      && longReference.hasSuffix("最新の質問"), "large references are bounded without truncating the user request")
let oldPersona = try JSONDecoder().decode(Persona.self, from: Data("{\"id\":\"old\",\"name\":\"old\",\"prompt\":\"短く話す\"}".utf8))
check(oldPersona.examples == nil, "persona resources without examples remain compatible")
let customStyle = Persona(id: "custom", name: "自分の話し方", prompt: "一人称は私。丁寧に話してください。")
let customInstructions = ConversationPrompt.instructions(preferences: Preferences(), persona: customStyle, hasPhoto: false)
check(customInstructions.contains(customStyle.prompt) && !customInstructions.contains("マグカップ")
      && !customInstructions.contains("【話し方の見本"), "custom style is not replaced with a sweet preset or its example")
let examplePersona = Persona(id: "example", name: "example", prompt: "親しい話し方", examples: [
    ConversationExample(situation: "架空の場面", input: "見本だけの質問", reply: "見本だけの返事")])
let exampleInstructions = ConversationPrompt.instructions(preferences: Preferences(), persona: examplePersona, hasPhoto: true)
check(exampleInstructions.contains("見本だけの返事") && !ConversationPrompt.message("実際の質問").contains("見本だけ"),
      "style examples are isolated from the real user prompt and history")
let brokenCaption = "木のテーブルに料理がある。" + String(repeating: "右側には、たまごのたまごが、白い麺と並んでいます。", count: 4)
check(CaptionQuality.issue(in: brokenCaption) == .repetition, "reproduced photo caption loop is rejected")
check(CaptionQuality.issue(in: "たまごのたまごのたまごのたまごの") == .repetition,
      "Japanese phrase loop is detected without sentence punctuation")
check(CaptionQuality.issue(in: "A bowl of noodles. A bowl of noodles. A bowl of noodles.") == .repetition,
      "fallback language loops are also rejected")
check(CaptionQuality.issue(in: "  \n ") == .empty, "empty visual generation cannot become a caption")
check(CaptionQuality.issue(in: "麺の隣には、") == .incomplete, "dangling old caption is not trusted")
check(CaptionQuality.issue(in: "木の机に料理がある。", completed: false) == .incomplete,
      "hitting the generation budget is not reported as a completed caption")
check(CaptionQuality.issue(in: String(repeating: "あ", count: 901)) == .tooLong,
      "oversized captions are rejected instead of silently clipped")
let soundCaptions = ["海苔がのったそばと、えびや野菜の天ぷらが並んでいる。木のテーブルに黒い器が置かれている。",
                     "白い皿に赤いりんご、青い皿に赤いりんご、緑の皿に赤いりんごがある。",
                     "A red cup sits beside a blue bowl. Both are on a wooden table.",
                     "東京駅", "猫が2匹、犬が2匹写っている。"]
check(soundCaptions.allSatisfy { CaptionQuality.issue(in: $0) == nil },
      "normal captions, repeated object names, short labels, and numbers remain usable")
var brokenPhoto = recoveredPhoto
brokenPhoto.visualDescription = brokenCaption
let brokenPhotoPair = [Message(role: "user", text: "これどう？", attachment: brokenPhoto),
                       Message(role: "assistant", text: "弁当です")]
check(brokenPhoto.needsVisualAnalysis && !recoveredPhoto.needsVisualAnalysis,
      "editing a corrupted saved photo requires reanalysis but a sound one is reused")
check(!brokenPhoto.reference(limit: 1100).contains("たまご") && brokenPhoto.reference(limit: 1100).contains("東京駅"),
      "bad visual text cannot reach the conversation model while OCR remains available")
check(ConversationContext.recent(brokenPhotoPair).isEmpty && brokenPhotoPair[0].attachment?.visualDescription == brokenCaption,
      "corrupted photo and its derived reply are excluded from context without deleting disk history")
let preservedBadPhoto = try JSONDecoder().decode(ImageAttachment.self, from: JSONEncoder().encode(brokenPhoto))
check(preservedBadPhoto == brokenPhoto && preservedBadPhoto.visualIssue == .repetition,
      "old malformed captions stay recoverable but unusable after a storage round trip")
brokenPhoto.textOnly = true
check(!brokenPhoto.needsVisualAnalysis, "explicit text-only mode never launches a visual retry")
let catalog = try JSONDecoder().decode(VoiceCatalog.self,
    from: Data(contentsOf: URL(fileURLWithPath: "YKCompanion/VoiceCatalog.json")))
let allStyles = catalog.characters.flatMap(\.styles)
check(catalog.characters.count == 7 && allStyles.count == 25 && Set(allStyles.map(\.id)).count == 25,
      "seven voice characters expose 25 distinct style choices")
check(catalog.character(for: Preferences().voiceStyle)?.name == "白上虎太郎",
      "existing default keeps the same character")
check(catalog.character(for: 1)?.name == "ずんだもん" && catalog.style(1)?.model == "0.vvm"
      && catalog.character(for: 75)?.name == "ずんだもん" && catalog.style(75)?.model == "15.vvm",
      "one character may select styles from different model groups")
check(catalog.style(-1) == nil && catalog.style(999) == nil, "unknown voice never silently substitutes another character")
check(allStyles.allSatisfy { style in catalog.models.contains { $0.name == style.model } },
      "every exposed style points to a bundled model")
var voicePreferences = Preferences()
voicePreferences.voiceEngine = "voicevox"
voicePreferences.voiceStyle = 1
let restoredVoice = try JSONDecoder().decode(Preferences.self, from: JSONEncoder().encode(voicePreferences))
check(restoredVoice.voiceStyle == 1 && restoredVoice.voiceEngine == "voicevox"
      && restoredVoice.personality == voicePreferences.personality, "zundamon sweet voice persists independently of conversation personality")
let selfie = ImageAttachment(recognizedText: "", visualDescription: "人物が白いシャツにグレーのコートを着ている。")
let stalePhotoHistory = [Message(role: "user", text: "自撮りしたー", attachment: selfie),
                        Message(role: "assistant", text: "「この写真」は「自撮り」をしている「人物」です😊")]
check(PhotoReaction.reference(for: "自撮りしたー", attachment: selfie, history: []) == selfie,
      "selfie sharing uses a reaction rather than a classification reply")
for utterance in ["イケメーン？", "じゃーん！", "これダサいかな？", "今日の一枚", ""] {
    check(PhotoReaction.reference(for: utterance, attachment: selfie, history: stalePhotoHistory) == selfie,
          "attached photo reaches reaction for arbitrary sharing wording: \(utterance)")
}
check(PhotoReaction.reference(for: "これどう思う〜？", attachment: recoveredPhoto, history: stalePhotoHistory) == recoveredPhoto,
      "a new photo takes precedence over an older selfie")
check(PhotoReaction.reference(for: "他は？", attachment: nil, history: stalePhotoHistory) == selfie,
      "a short follow-up can reuse the photo without inventing a new one")
check(PhotoReaction.reference(for: "今日は疲れた", attachment: nil, history: stalePhotoHistory) == nil,
      "ordinary chat after a photo never becomes a photo reaction")
check(PhotoReaction.reference(for: "可愛いの買った", attachment: nil, history: stalePhotoHistory) == nil,
      "text-only sharing does not reuse an unrelated old image")
check(PhotoReaction.reference(for: "他は？", attachment: nil, history: []) == nil,
      "a new topic cannot revive a photo outside its context")
check(["文字を読んで", "これ見て。どこ？", "これ何？", "自撮りしたけど頬が腫れた", "似合う？あと料金教えて",
       "かわいいけどこれ誰？", "この料理どうやって作るの？"].allSatisfy {
    PhotoReaction.reference(for: $0, attachment: selfie, history: []) == nil
}, "OCR, identity, location, medical and factual requests retain the answer path")
check(PhotoReaction.reference(for: "これどう？", attachment: brokenPhoto, history: []) == nil,
      "text-only or malformed observations cannot feed a visual impression")
check(PhotoReaction.reference(for: "これどう？", attachment: ImageAttachment(recognizedText: "看板"), history: []) == nil,
      "OCR alone never fabricates a visual reaction")
check(PhotoReaction.text(response: "ね、見せてくれたんだ！", impression: nil) == "ね、見せてくれたんだ！"
      && PhotoReaction.text(response: "ね、見せてくれたんだ！", impression: "襟の色が好きだな。")
      == "ね、見せてくれたんだ！\n襟の色が好きだな。", "streamed fields compose without JSON or duplicate prefixes")
var noEmoji = Preferences()
noEmoji.emoji = false
let reactionInstructions = PhotoReaction.instructions(preferences: noEmoji, persona: customStyle)
check(reactionInstructions.contains(customStyle.prompt) && reactionInstructions.contains("絵文字は使わず")
      && !reactionInstructions.contains("甘えん坊"), "reaction honors custom tone and emoji preference")
let reactionInput = PhotoReaction.prompt("自撮りしたー", photo: selfie, history: stalePhotoHistory, memo: "好きな色は青")
check(reactionInput.hasSuffix("自撮りしたー") && reactionInput.contains("グレーのコート")
      && reactionInput.contains("好きな色は青"), "reaction receives the real photo, memo and latest utterance")
check(stalePhotoHistory[1].text == "「この写真」は「自撮り」をしている「人物」です😊"
      && !reactionInstructions.contains(stalePhotoHistory[1].text), "earlier replies stay on disk without entering reaction instructions")
let travelNow = ISO8601DateFormatter().date(from: "2026-11-02T01:00:00Z")!
let arrivalRequest = TransitRequest.parse("明日新宿駅から東京駅に１８時４２分までに着きたい", now: travelNow)!
check(arrivalRequest.origin == "新宿駅" && arrivalRequest.destination == "東京駅" && arrivalRequest.timeMode == .arrival,
      "chat extracts fullwidth arrival-time request")
let arrivalParts = TransitRequest.japan.dateComponents([.day, .hour, .minute], from: arrivalRequest.requestedDate!)
check(arrivalParts.day == 3 && arrivalParts.hour == 18 && arrivalParts.minute == 42, "tomorrow and time use Japan calendar")
check(TransitRequest.parse("18時までに東京駅に着きたい", now: travelNow)?.destination == "東京駅", "time-first request extracts destination")
check(TransitRequest.parse("電車で東京駅に午後6時半までに着きたい", now: travelNow)?.requestedDate
      == TransitRequest.japan.date(bySettingHour: 18, minute: 30, second: 0, of: travelNow), "PM half hour parses")
check(TransitRequest.parse("東京駅に午前12時に到着したい", now: travelNow).map {
    TransitRequest.japan.component(.hour, from: $0.requestedDate!) == 0
} == true, "midnight is midnight, not noon")
check(TransitRequest.parse("電車で東京駅に25時99分に行きたい", now: travelNow)?.requestedDate == nil, "invalid clock is never fabricated")
check(TransitRequest.parse("現在地から東京駅まで電車で行きたい")?.origin == "", "current location requires choosing an origin station")
check(TransitRequest(origin: "", destination: "東京駅").yahooURL() == nil, "Yahoo requires explicit origin")
let yahoo = URLComponents(url: arrivalRequest.yahooURL(now: travelNow)!, resolvingAgainstBaseURL: false)!
func yahooValue(_ name: String) -> String? { yahoo.queryItems?.first { $0.name == name }?.value }
check(yahoo.host == "transit.yahoo.co.jp" && yahooValue("type") == "4", "Yahoo arrival search type")
check(yahooValue("y") == "2026" && yahooValue("m") == "11" && yahooValue("d") == "03"
      && yahooValue("hh") == "18" && yahooValue("m1") == "4" && yahooValue("m2") == "2", "Yahoo exact date and split-minute fields")
let escapedYahoo = URLComponents(url: special.yahooURL(now: travelNow)!, resolvingAgainstBaseURL: false)!
check(escapedYahoo.queryItems?.first { $0.name == "from" }?.value == "A&B駅", "Yahoo query metacharacters remain one place")
check(TransitTime.first.yahooValue == "3" && TransitTime.last.yahooValue == "2", "Yahoo first and last train modes")
check(OutingIntent.query(from: "東京タワーまでナビして") == "東京タワー", "chat walking navigation request")
check(TravelLinks.google(destination: "東京駅", mode: "flying") == nil, "invalid transport mode rejected")
let walkingURL = URLComponents(url: TravelLinks.google(destination: "35.0,139.0")!, resolvingAgainstBaseURL: false)!
check(walkingURL.queryItems?.first { $0.name == "dir_action" }?.value == "navigate", "Google walking link requests navigation")
var train = TrainReminder(station: "東京駅", line: "テスト線", departure: travelNow.addingTimeInterval(600))
check(!train.valid(now: travelNow), "unconfirmed train cannot schedule notification")
train.confirmed = true
check(train.valid(now: travelNow), "confirmed upcoming train is valid")
check(train.announcement.contains("番線は駅の表示で確認") && !train.announcement.contains("1番線"), "missing platform is never invented")
train.platform = "3番線"; train.boundFor = "テスト駅"
check(train.announcement.contains("3番線") && train.announcement.contains("テスト駅行き"), "only registered platform and headsign are spoken")
train.arrival = travelNow.addingTimeInterval(1800)
check(train.arrivalMessage(deadline: travelNow.addingTimeInterval(2100))?.contains("5分前") == true, "arrival margin from confirmed schedule")
check(train.arrivalMessage(deadline: travelNow.addingTimeInterval(1740))?.contains("1分過ぎ") == true, "late arrival is not called on time")
check(!train.valid(now: travelNow.addingTimeInterval(500)), "less than two minutes cannot schedule past notification")
check(!train.valid(now: travelNow.addingTimeInterval(-7 * 86400)), "reminders limited to seven days")
train.arrival = travelNow
check(!train.valid(now: travelNow), "arrival before departure rejected")
var walking = WalkProgress(points: [WalkPoint(x: 0, y: 0), WalkPoint(x: 100, y: 0), WalkPoint(x: 100, y: 100)])
check(walking.length == 200, "walking geometry length")
check(walking.update(WalkPoint(x: 70, y: 4), accuracy: 10, age: 0) && walking.progress == 70, "GPS projects to actual route segment")
check(walking.update(WalkPoint(x: 100, y: 20), accuracy: 10, age: 0) && walking.progress == 120, "turn advances along polyline")
check(!walking.update(WalkPoint(x: 100, y: 50), accuracy: 60, age: 0) && walking.progress == 120, "inaccurate GPS cannot advance instruction")
check(!walking.update(WalkPoint(x: 100, y: 50), accuracy: 10, age: -20) && walking.progress == 120, "stale GPS cannot advance instruction")
check(walking.update(WalkPoint(x: 100, y: 10), accuracy: 10, age: 0) && walking.progress == 120, "GPS jitter cannot replay earlier turn")
check(!walking.update(WalkPoint(x: 400, y: 400), accuracy: 10, age: 0) && !walking.paused, "one GPS outlier does not stop route")
_ = walking.update(WalkPoint(x: 400, y: 400), accuracy: 10, age: 0)
_ = walking.update(WalkPoint(x: 400, y: 400), accuracy: 10, age: 0)
check(walking.paused && !walking.update(WalkPoint(x: 100, y: 40), accuracy: 10, age: 0), "repeated off-route GPS pauses until explicit recalculation")
var jump = WalkProgress(points: [WalkPoint(x: 0, y: 0), WalkPoint(x: 1000, y: 0)])
check(!jump.update(WalkPoint(x: 800, y: 0), accuracy: 10, age: 0) && jump.progress == 0, "route matcher cannot jump to faraway segment")
let akiba = TravelOffer.parse("秋葉原に行きたい")!
check(akiba.request.destination == "秋葉原" && akiba.mode == .choice, "plain travel wish offers a transport choice")
check(akiba.reply(personality: "sweet").count < 70 && akiba.reply(personality: "sweet").contains("案内しよっか")
      && akiba.reply(personality: "sweet").contains("秋葉原"), "travel wish gets a short warm proposal with the actual destination")
check(TravelOffer.parse("東京タワーへ行きたい！！")?.request.destination == "東京タワー", "casual punctuation preserves destination")
check(TravelOffer.parse("京都に行こうかな")?.request.destination == "京都", "tentative outing gets a proposal only")
check(TravelOffer.parse("近くにカフェある？")?.nearby == true, "nearby question preserves explicit location-search mode")
check(TravelOffer.parse("秋葉原の歴史を教えて") == nil && TravelOffer.parse("秋葉原には行きたくない") == nil,
      "information and negative travel wishes remain normal chat")
check(TravelOffer.parse("僕は秋葉原に行きたいって言った") == nil, "quoted wish is not a destination")
check(TravelOffer.parse("東京駅まで歩いて行きたい")?.mode == .walking, "explicit walking opens the inline walking form")
check(TravelOffer.parse("電車で東京駅に行きたい")?.mode == .transit, "explicit train request opens the transit form")
check(TravelOffer.followup("徒歩で！") == .walking && TravelOffer.followup("電車でお願い") == .transit, "brief follow-up can select transportation")
check(TravelOffer.followup("お願い") == .choice && TravelOffer.followup("今はいい") == .dismissed, "acceptance still asks mode and refusal dismisses")
check(TravelOffer.followup("電車の話をしよう") == nil, "unrelated train chat cannot start guidance")
let offerMessage = Message(role: "assistant", text: akiba.reply(personality: "sweet"), completed: false, travelOffer: akiba)
let restoredOffer = try JSONDecoder().decode(Message.self, from: JSONEncoder().encode(offerMessage))
check(restoredOffer == offerMessage,
      "travel proposal survives save/reload with no coordinates")
let legacyOffer = try JSONDecoder().decode(Message.self, from: Data("{\"id\":\"11111111-1111-1111-1111-111111111111\",\"role\":\"user\",\"text\":\"old\",\"date\":0}".utf8))
check(legacyOffer.travelOffer == nil,
      "pre-proposal chat data remains readable")
check(ConversationContext.recent([Message(role: "user", text: "秋葉原に行きたい"), offerMessage]).isEmpty,
      "offline navigation state cannot become fake LLM history")
check(ConversationBrevity.isBrief("これいいよね〜", enabled: true), "casual reactions use short output")
check(!ConversationBrevity.isBrief("行き方を詳しく教えて", enabled: true)
      && !ConversationBrevity.isBrief("コードを書いて", enabled: true), "requested explanation and code are not clipped")
check(!ConversationBrevity.isBrief("話そう", enabled: false), "explicit long-answer preference is preserved")
let brief = ConversationBrevity.preview("いいね！僕はこの色好きだな。以下に詳しく説明します。")
check(brief.finished && brief.text == "いいね！僕はこの色好きだな。", "stream stops after two complete casual sentences")
check(ConversationBrevity.preview("いいね！！この色好き。").text == "いいね！！この色好き。", "repeated punctuation is a single sentence ending")
check(!ConversationBrevity.preview("僕はこの色").finished, "partial stream continues until a complete response")
check(ConversationBrevity.preview(String(repeating: "あ", count: 250)).text.count <= 200, "unpunctuated rambling is bounded for display and speech")
print("Core checks complete.")
