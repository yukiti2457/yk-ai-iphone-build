import Foundation

enum TransitTime: String, Codable, CaseIterable, Identifiable {
    case now, departure, arrival, first, last
    var id: String { rawValue }
    var title: String {
        switch self {
        case .now: return "今から"
        case .departure: return "出発時刻"
        case .arrival: return "到着時刻"
        case .first: return "始発"
        case .last: return "終電"
        }
    }
    var yahooValue: String {
        switch self {
        case .now, .departure: return "1"
        case .arrival: return "4"
        case .first: return "3"
        case .last: return "2"
        }
    }
}

struct TransitRequest: Codable, Equatable {
    var origin = ""
    var destination = ""
    var timeMode: TransitTime = .now
    var requestedDate: Date? = nil
    static var japan: Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Asia/Tokyo")!
        return calendar
    }

    static func parse(_ raw: String, now: Date = Date()) -> TransitRequest? {
        let text = raw.precomposedStringWithCompatibilityMapping.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.count <= 300,
              (["乗換", "乗り換え", "電車", "終電", "始発", "時刻表"].contains(where: text.contains)
                || (text.contains("駅") && ["着きたい", "到着", "間に合"].contains(where: text.contains))),
              ["教えて", "調べて", "案内", "行きたい", "探して", "何時", "時刻表", "着きたい", "到着", "間に合", "ナビ"].contains(where: text.contains)
        else { return nil }
        var result = TransitRequest()
        result.timeMode = text.contains("終電") ? .last : text.contains("始発") ? .first : .now
        var placeText = text
        if let match = text.range(of: #"(?:午前|午後)?\d{1,2}(?:時(?:\d{1,2}分?|半)?|:\d{2})"#, options: .regularExpression) {
            let clock = String(text[match])
            let numbers = clock.components(separatedBy: CharacterSet.decimalDigits.inverted).compactMap(Int.init)
            if var hour = numbers.first {
                let minute = clock.contains("半") ? 30 : numbers.count > 1 ? numbers[1] : 0
                if clock.contains("午後") && hour < 12 { hour += 12 }
                if clock.contains("午前") && hour == 12 { hour = 0 }
                if (0...23).contains(hour), (0...59).contains(minute) {
                    let day = japan.date(byAdding: .day, value: text.contains("明日") ? 1 : 0, to: now)!
                    result.requestedDate = japan.date(bySettingHour: hour, minute: minute, second: 0, of: day)
                    result.timeMode = ["までに", "着きたい", "到着", "間に合"].contains(where: text.contains) ? .arrival : .departure
                }
            }
            placeText.removeSubrange(match)
        }
        var changed = true
        while changed {
            changed = false
            placeText = placeText.trimmingCharacters(in: CharacterSet(charactersIn: " 、"))
            for prefix in ["今日", "明日", "今から", "現在地", "ここ", "電車で", "までに", "に"] where placeText.hasPrefix(prefix) {
                placeText = String(placeText.dropFirst(prefix.count))
                changed = true
            }
        }
        placeText = placeText.trimmingCharacters(in: CharacterSet(charactersIn: " 、に"))
        if let from = placeText.range(of: "から") {
            result.origin = String(placeText[..<from.lowerBound])
            placeText = String(placeText[from.upperBound...])
        }
        if let end = ["まで", "に", "へ"].compactMap({ placeText.range(of: $0) }).min(by: { $0.lowerBound < $1.lowerBound }) {
            result.destination = String(placeText[..<end.lowerBound])
        }
        result.origin = result.origin.trimmingCharacters(in: .whitespacesAndNewlines)
        result.destination = result.destination.trimmingCharacters(in: .whitespacesAndNewlines)
        if result.origin.count > 100 { result.origin = "" }
        if result.destination.count > 100 { result.destination = "" }
        return result
    }

    func yahooURL(now: Date = Date()) -> URL? {
        let start = origin.trimmingCharacters(in: .whitespacesAndNewlines)
        let end = destination.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !start.isEmpty, !end.isEmpty, start.count <= 100, end.count <= 100 else { return nil }
        let date = Self.japan.dateComponents([.year, .month, .day, .hour, .minute], from: timeMode == .now ? now : requestedDate ?? now)
        var url = URLComponents(string: "https://transit.yahoo.co.jp/search/result")!
        url.queryItems = ["from": start, "to": end, "type": timeMode.yahooValue,
            "y": String(date.year!), "m": String(format: "%02d", date.month!), "d": String(format: "%02d", date.day!),
            "hh": String(format: "%02d", date.hour!), "m1": String(date.minute! / 10), "m2": String(date.minute! % 10),
            "ticket": "ic"].map { URLQueryItem(name: $0.key, value: $0.value) }
        return url.url
    }

    var googleURL: URL? { TravelLinks.google(destination: destination, origin: origin, mode: "transit") }
}

enum TravelLinks {
    static func google(destination: String, origin: String = "", mode: String = "walking") -> URL? {
        let end = destination.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !end.isEmpty, end.count <= 100, origin.count <= 100,
              ["walking", "driving", "transit"].contains(mode) else { return nil }
        var url = URLComponents(string: "https://www.google.com/maps/dir/")!
        url.queryItems = [.init(name: "api", value: "1"), .init(name: "destination", value: end),
                          .init(name: "travelmode", value: mode)]
        if !origin.isEmpty { url.queryItems?.append(.init(name: "origin", value: origin)) }
        if mode != "transit" { url.queryItems?.append(.init(name: "dir_action", value: "navigate")) }
        return url.url
    }
}

// Only confirmed timetable fields are spoken. No language model fills missing fields.
struct TrainReminder {
    var station = ""
    var line = ""
    var boundFor = ""
    var platform = ""
    var departure = Date()
    var arrival: Date? = nil
    var confirmed = false
    var announcement: String {
        let date = TransitRequest.japan.dateComponents([.hour, .minute], from: departure)
        var text = "登録した予定では、\(station)を\(date.hour!)時\(date.minute!)分発の\(line)"
        if !boundFor.isEmpty { text += "、\(boundFor)行き" }
        text += "だよ。"
        text += platform.isEmpty ? "番線は駅の表示で確認してね。" : "登録した番線は\(platform)だよ。"
        return text + "運行変更はYahoo!乗換案内と駅の表示を確認してね。"
    }
    func valid(now: Date = Date()) -> Bool {
        confirmed && !station.trimmingCharacters(in: .whitespaces).isEmpty
            && !line.trimmingCharacters(in: .whitespaces).isEmpty
            && [station, line, boundFor, platform].allSatisfy { $0.count <= 100 }
            && departure > now.addingTimeInterval(120) && departure < now.addingTimeInterval(7 * 86400)
            && (arrival == nil || arrival! >= departure)
    }
    func arrivalMessage(deadline: Date?) -> String? {
        guard let arrival, let deadline, arrival >= departure else { return nil }
        let minutes = Int((deadline.timeIntervalSince(arrival) / 60).rounded(.down))
        return minutes >= 0 ? "登録した予定では、希望時刻の\(minutes)分前に到着。遅延と駅からの移動時間は含みません。"
            : "登録した到着予定は、希望時刻を\(-minutes)分過ぎています。別の経路を確認してください。"
    }
}

struct WalkPoint: Equatable {
    var x: Double
    var y: Double
    func distance(to p: WalkPoint) -> Double { hypot(x - p.x, y - p.y) }
}

struct WalkProgress {
    let points: [WalkPoint]
    var progress: Double = 0
    var offRouteSamples = 0
    var paused = false
    var length: Double { zip(points, points.dropFirst()).reduce(0) { $0 + $1.0.distance(to: $1.1) } }

    mutating func update(_ location: WalkPoint, accuracy: Double, age: Double, allowance: Double = 120) -> Bool {
        guard !paused, accuracy >= 0, accuracy <= 25, abs(age) <= 15, points.count > 1 else { return false }
        var offset = 0.0
        var nearest = Double.greatestFiniteMagnitude
        var match = progress
        for (a, b) in zip(points, points.dropFirst()) {
            let distance = a.distance(to: b)
            defer { offset += distance }
            guard distance > 0, offset + distance >= progress - 30, offset <= progress + allowance else { continue }
            let t = min(1, max(0, ((location.x-a.x)*(b.x-a.x)+(location.y-a.y)*(b.y-a.y))/(distance*distance)))
            let along = offset + t * distance
            guard along >= progress - 30, along <= progress + allowance else { continue }
            let gap = location.distance(to: WalkPoint(x: a.x+t*(b.x-a.x), y: a.y+t*(b.y-a.y)))
            if gap < nearest { nearest = gap; match = along }
        }
        if nearest > 60 {
            offRouteSamples += 1
            if offRouteSamples >= 3 { paused = true }
            return false
        }
        offRouteSamples = 0
        guard nearest <= 30 else { return false }
        progress = max(progress, match)
        return true
    }
}
