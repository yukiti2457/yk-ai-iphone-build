import AVFoundation
import Combine
import Speech

@MainActor
final class MicrophoneService: ObservableObject {
    @Published private(set) var isListening = false
    @Published private(set) var transcript = ""
    @Published private(set) var notice: String?
    private let engine = AVAudioEngine()
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "ja-JP"))
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var recognition: SFSpeechRecognitionTask?
    private var startTask: Task<Void, Never>?
    private var timeoutTask: Task<Void, Never>?
    private var tapInstalled = false
    private var sessionID = UUID()
    private var completion: ((String) -> Void)?

    func start(onFinish: @escaping (String) -> Void) {
        cancel()
        let id = sessionID
        transcript = ""
        notice = "マイクの準備中…"
        isListening = true
        completion = onFinish
        startTask = Task { [weak self] in
            guard let self else { return }
            let speech = await withCheckedContinuation { continuation in
                SFSpeechRecognizer.requestAuthorization { continuation.resume(returning: $0) }
            }
            guard !Task.isCancelled, self.sessionID == id else { return }
            guard speech == .authorized else {
                self.fail("音声認識が許可されていません。iPhoneの設定 → プライバシーとセキュリティ → 音声認識を確認してください。")
                return
            }
            let microphone = await AVAudioApplication.requestRecordPermission()
            guard !Task.isCancelled, self.sessionID == id else { return }
            guard microphone else {
                self.fail("マイクが許可されていません。iPhoneの設定 → プライバシーとセキュリティ → マイクを確認してください。")
                return
            }
            guard let recognizer = self.recognizer, recognizer.isAvailable,
                  recognizer.supportsOnDeviceRecognition else {
                self.fail("日本語の端末内音声認識を利用できません。ネット送信には切り替えません。キーボードで入力してください。")
                return
            }
            do {
                let audioSession = AVAudioSession.sharedInstance()
                try audioSession.setCategory(.record, mode: .measurement, options: .duckOthers)
                try audioSession.setActive(true)
                let request = SFSpeechAudioBufferRecognitionRequest()
                request.requiresOnDeviceRecognition = true
                request.shouldReportPartialResults = true
                self.request = request
                let input = self.engine.inputNode
                let format = input.outputFormat(forBus: 0)
                guard format.sampleRate > 0, format.channelCount > 0 else {
                    throw VoicevoxEngine.Failure(message: "マイクを利用できません。通話を終了して再度お試しください。")
                }
                input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in request.append(buffer) }
                self.tapInstalled = true
                self.recognition = recognizer.recognitionTask(with: request) { [weak self] result, error in
                    let text = result?.bestTranscription.formattedString
                    let isFinal = result?.isFinal == true
                    let failed = error != nil
                    Task { @MainActor in
                        guard let self, self.sessionID == id else { return }
                        if let text { self.transcript = String(text.prefix(600)) }
                        if isFinal { self.finish() }
                        else if failed { self.fail("音声を聞き取れませんでした。入力欄に残った文章を確認して、もう一度お試しください。") }
                    }
                }
                self.engine.prepare()
                try self.engine.start()
                self.notice = "聞いています。もう一度マイクを押すと確定します。"
                self.timeoutTask = Task { [weak self] in
                    try? await Task.sleep(for: .seconds(60))
                    guard !Task.isCancelled, let self, self.sessionID == id else { return }
                    self.fail("60秒でマイクを停止しました。入力欄の文章を確認して送信してください。")
                }
            } catch { self.fail(error.localizedDescription) }
        }
    }

    func finish() {
        let text = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        let callback = completion
        cancel()
        if !text.isEmpty { callback?(text) }
        else { notice = "聞き取れませんでした。もう一度マイクを押して話してください。" }
    }

    private func fail(_ message: String) {
        cancel()
        notice = message
    }

    func cancel() {
        sessionID = UUID()
        startTask?.cancel()
        startTask = nil
        timeoutTask?.cancel()
        timeoutTask = nil
        engine.stop()
        if tapInstalled { engine.inputNode.removeTap(onBus: 0); tapInstalled = false }
        request?.endAudio()
        recognition?.cancel()
        recognition = nil
        request = nil
        completion = nil
        if isListening { try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation) }
        isListening = false
        notice = nil
    }
}
