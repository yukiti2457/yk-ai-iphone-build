import Combine
import ImageIO
import MapKit
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers
import Vision

struct AnalyzedImage: Sendable {
    var attachment: ImageAttachment
    var jpeg: Data
    var latitude: Double?
    var longitude: Double?
}

enum ImageFiles {
    static var directory: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("YKCompanion/Attachments", isDirectory: true)
    }
    static func url(_ id: UUID) -> URL { directory.appendingPathComponent(id.uuidString + ".jpg") }
    static func save(_ image: AnalyzedImage) throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var folder = directory
        var values = URLResourceValues()
        values.isExcludedFromBackup = true
        try folder.setResourceValues(values)
        try image.jpeg.write(to: url(image.attachment.id), options: [.atomic, .completeFileProtection])
    }
    static func remove(_ id: UUID) { try? FileManager.default.removeItem(at: url(id)) }
}

actor ImageAnalyzer {
    func analyze(_ data: Data) throws -> AnalyzedImage {
        guard data.count <= 30_000_000,
              let source = CGImageSourceCreateWithData(data as CFData, nil),
              let image = CGImageSourceCreateThumbnailAtIndex(source, 0, [
                kCGImageSourceCreateThumbnailFromImageAlways: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceThumbnailMaxPixelSize: 1800
              ] as CFDictionary) else {
            throw VoicevoxEngine.Failure(message: "画像を開けませんでした。30MB以下の写真・スクショを選んでください。")
        }
        try Task.checkCancellation()
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.recognitionLanguages = ["ja-JP", "en-US"]
        request.usesLanguageCorrection = true
        try VNImageRequestHandler(cgImage: image).perform([request])
        let text = (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
        let output = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(output, UTType.jpeg.identifier as CFString, 1, nil) else {
            throw VoicevoxEngine.Failure(message: "画像を準備できませんでした。")
        }
        // Re-encode pixels only: saved preview has no source EXIF/GPS or identifying metadata.
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: 0.75] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else {
            throw VoicevoxEngine.Failure(message: "画像を準備できませんでした。")
        }
        let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any]
        let gps = properties?[kCGImagePropertyGPSDictionary] as? [CFString: Any]
        var lat = gps?[kCGImagePropertyGPSLatitude] as? Double
        var lon = gps?[kCGImagePropertyGPSLongitude] as? Double
        if gps?[kCGImagePropertyGPSLatitudeRef] as? String == "S" { lat = lat.map { -$0 } }
        if gps?[kCGImagePropertyGPSLongitudeRef] as? String == "W" { lon = lon.map { -$0 } }
        if let a = lat, let b = lon, (!a.isFinite || !b.isFinite || abs(a) > 90 || abs(b) > 180) { lat = nil; lon = nil }
        return AnalyzedImage(attachment: ImageAttachment(recognizedText: String(text.prefix(2000))),
                             jpeg: output as Data, latitude: lat, longitude: lon)
    }
}

@MainActor
final class AttachmentStore: ObservableObject {
    @Published private(set) var draft: AnalyzedImage?
    @Published private(set) var isLoading = false
    @Published private(set) var notice: String?
    private let analyzer = ImageAnalyzer()
    private var task: Task<Void, Never>?
    private var requestID = UUID()

    func load(_ item: PhotosPickerItem) {
        clear()
        isLoading = true
        let id = requestID
        task = Task { [weak self] in
            guard let self else { return }
            do {
                guard let data = try await item.loadTransferable(type: Data.self) else {
                    throw VoicevoxEngine.Failure(message: "写真を読み込めませんでした。")
                }
                let result = try await self.analyzer.analyze(data)
                try Task.checkCancellation()
                guard self.requestID == id else { return }
                self.draft = result
                self.isLoading = false
            } catch {
                guard self.requestID == id, !Task.isCancelled else { return }
                self.isLoading = false
                self.notice = error.localizedDescription
            }
        }
    }

    func clear() {
        requestID = UUID()
        task?.cancel()
        task = nil
        draft = nil
        notice = nil
        isLoading = false
    }

    func setTextOnly(_ value: Bool) { draft?.attachment.textOnly = value }
}

struct AttachmentDraftView: View {
    @EnvironmentObject private var attachments: AttachmentStore
    @EnvironmentObject private var places: PlacesStore
    var openPlaces: () -> Void
    @State private var searchTerm = ""
    @State private var showVisualSetup = false
    @ObservedObject private var visual = VisualModelStore.shared

    var body: some View {
        if let photo = attachments.draft {
            VStack(alignment: .leading, spacing: 8) {
                HStack(alignment: .top) {
                    if let uiImage = UIImage(data: photo.jpeg) {
                        Image(uiImage: uiImage).resizable().scaledToFit().frame(width: 85, height: 70)
                    }
                    Text(photo.attachment.textOnly == true ? "画像の文字だけで質問します。見た目は解析しません。" : visual.ready ? "送信すると、写真の見た目をiPhone内で確認します。" : "写真の見た目を読むには、写真AIの準備が必要です。")
                        .font(.caption).foregroundStyle(.secondary)
                    Spacer()
                    Button { attachments.clear() } label: { Image(systemName: "xmark.circle.fill") }
                        .accessibilityLabel("添付を取り消す")
                }
                if !visual.ready && photo.attachment.textOnly != true {
                    Button("写真AIを準備する（初回約1.8GB）") { showVisualSetup = true }
                        .font(.caption).accessibilityIdentifier("setupVisualModel")
                }
                Toggle("文字だけで質問（見た目は解析しない）", isOn: Binding(
                    get: { photo.attachment.textOnly == true }, set: { attachments.setTextOnly($0) }))
                    .font(.caption)
                DisclosureGroup("文字を確認・場所を探す") {
                    ScrollView {
                        Text(photo.attachment.recognizedText.isEmpty ? "文字を読み取れませんでした。風景だけから場所は特定できません。" : photo.attachment.recognizedText)
                            .font(.caption).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
                    }.frame(maxHeight: 100)
                    TextField("画像内の店名・住所を入力", text: $searchTerm).textFieldStyle(.roundedBorder)
                        .onChange(of: searchTerm) { _, value in searchTerm = String(value.prefix(100)) }
                    Button("この地名・店名で探す") {
                        places.query = searchTerm
                        openPlaces()
                    }.disabled(searchTerm.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    if let lat = photo.latitude, let lon = photo.longitude {
                        Button("写真の撮影地点をAppleマップで開く") {
                            let item = MKMapItem(placemark: MKPlacemark(coordinate: .init(latitude: lat, longitude: lon)))
                            item.name = "写真に記録された撮影地点"
                            item.openInMaps()
                        }
                        Text("写真に含まれた位置情報をマップへ渡します。現在地とは限りません。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }.font(.caption)
            }.padding(10).background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 12))
                .padding(.horizontal)
                .sheet(isPresented: $showVisualSetup) {
                    NavigationStack {
                        Form { VisualModelSection() }.navigationTitle("写真AI")
                            .toolbar { Button("閉じる") { showVisualSetup = false } }
                    }
                }
        } else if attachments.isLoading {
            HStack { ProgressView(); Text("画像の文字を端末内で読んでいます…").font(.caption) }
        } else if let notice = attachments.notice {
            Text(notice).font(.caption).foregroundStyle(.orange).padding(.horizontal)
        }
    }
}

struct MessageImageView: View {
    var attachment: ImageAttachment
    @State private var preview: UIImage?
    var body: some View {
        Group {
            if let preview {
                Image(uiImage: preview).resizable().scaledToFit().frame(maxHeight: 240)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            } else { Label("添付画像", systemImage: "photo") }
            DisclosureGroup(attachment.visualDescription == nil ? "画像から読み取った文字" : "写真から読み取った内容") {
                if let caption = attachment.visualDescription {
                    if attachment.visualIssue != nil {
                        Text("以前の認識結果に繰り返しや途切れがあるため、会話には使いません。同じ写真を添付し直すと再解析できます。")
                            .font(.caption).foregroundStyle(.orange)
                    } else {
                        Text(caption).font(.caption).textSelection(.enabled)
                    }
                    Text("端末内の画像認識結果です。間違う場合があります。")
                        .font(.caption2).foregroundStyle(.secondary)
                    Divider()
                }
                Text(attachment.recognizedText.isEmpty ? "文字は読み取れませんでした。" : attachment.recognizedText)
                    .font(.caption).textSelection(.enabled)
            }.font(.caption)
        }.task(id: attachment.id) { preview = UIImage(contentsOfFile: ImageFiles.url(attachment.id).path) }
    }
}
