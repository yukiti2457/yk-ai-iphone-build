import Foundation
import voicevox_core

// All blocking C calls and owned handles stay on this actor, away from the UI.
actor VoicevoxEngine {
    private var synthesizer: OpaquePointer?
    private var dictionary: OpaquePointer?
    private var loadedModel: String?

    struct Failure: LocalizedError {
        var message: String
        var errorDescription: String? { message }
    }

    private func check(_ code: Int32) throws {
        if code != 0 {
            throw Failure(message: "VOICEVOX: \(String(cString: voicevox_error_result_to_message(code)))（\(code)）")
        }
    }

    private func prepare(modelFile: String) throws -> OpaquePointer {
        if let synthesizer, loadedModel == modelFile { return synthesizer }
        guard let assets = Bundle.main.resourceURL?.appendingPathComponent("VoicevoxAssets"),
              FileManager.default.fileExists(atPath: assets.appendingPathComponent(modelFile).path) else {
            throw Failure(message: "VOICEVOXの音声データがありません。アプリの更新が必要です。")
        }
        // Hold only one model group at a time, including when changing characters.
        releaseResources()
        var runtime: OpaquePointer?
        try check(voicevox_onnxruntime_init_once(&runtime))
        var jtalk: OpaquePointer?
        try assets.appendingPathComponent("open_jtalk_dic_utf_8-1.11").path.withCString {
            try check(voicevox_open_jtalk_rc_new($0, &jtalk))
        }
        guard let jtalk else { throw Failure(message: "辞書を読み込めませんでした。") }
        var synth: OpaquePointer?
        do {
            var options = voicevox_make_default_initialize_options()
            options.acceleration_mode = 1 // C ABI int32_t: VOICEVOX_ACCELERATION_MODE_CPU
            options.cpu_num_threads = 2
            try check(voicevox_synthesizer_new(runtime, jtalk, options, &synth))
            guard let synth else { throw Failure(message: "音声エンジンを初期化できませんでした。") }
            var model: OpaquePointer?
            try assets.appendingPathComponent(modelFile).path.withCString {
                try check(voicevox_voice_model_file_open($0, &model))
            }
            guard let model else { throw Failure(message: "音声モデルを開けませんでした。") }
            defer { voicevox_voice_model_file_delete(model) }
            try check(voicevox_synthesizer_load_voice_model(synth, model,
                voicevox_make_default_load_voice_model_options()))
            dictionary = jtalk
            synthesizer = synth
            loadedModel = modelFile
            return synth
        } catch {
            if let synth { voicevox_synthesizer_delete(synth) }
            voicevox_open_jtalk_rc_delete(jtalk)
            throw error
        }
    }

    func synthesize(_ text: String, style: Int, speed: Double, pitch: Double) throws -> Data {
        try Task.checkCancellation()
        guard let selectedStyle = VoiceCatalog.shared.style(style) else {
            throw Failure(message: "選んだ声が見つかりません。設定で音声キャラクターを選び直してください。")
        }
        let synth = try prepare(modelFile: selectedStyle.model)
        try Task.checkCancellation()
        let styleID = UInt32(selectedStyle.id)
        var query: UnsafeMutablePointer<CChar>?
        try text.withCString { try check(voicevox_synthesizer_create_audio_query(synth, $0, styleID, &query)) }
        guard let query else { throw Failure(message: "読み上げ内容を解析できませんでした。") }
        defer { voicevox_string_free(query) }
        guard var value = try JSONSerialization.jsonObject(with: Data(String(cString: query).utf8)) as? [String: Any] else {
            throw Failure(message: "音声の設定を読み取れませんでした。")
        }
        value["speedScale"] = min(1.5, max(0.7, speed))
        value["pitchScale"] = min(0.1, max(-0.1, pitch))
        let json = String(decoding: try JSONSerialization.data(withJSONObject: value), as: UTF8.self)
        var length: UInt = 0
        var wav: UnsafeMutablePointer<UInt8>?
        try json.withCString {
            try check(voicevox_synthesizer_synthesis(synth, $0, styleID,
                voicevox_make_default_synthesis_options(), &length, &wav))
        }
        guard let wav else { throw Failure(message: "音声が生成されませんでした。") }
        defer { voicevox_bytes_free(wav) }
        guard length > 44 else { throw Failure(message: "音声が生成されませんでした。") }
        try Task.checkCancellation()
        return Data(bytes: wav, count: Int(length))
    }

    // Called before loading the much larger photo model. Actor isolation waits
    // for any in-flight C synthesis to finish before destroying its handles.
    func releaseResources() {
        if let synthesizer { voicevox_synthesizer_delete(synthesizer) }
        if let dictionary { voicevox_open_jtalk_rc_delete(dictionary) }
        synthesizer = nil
        dictionary = nil
        loadedModel = nil
    }

    deinit {
        if let synthesizer { voicevox_synthesizer_delete(synthesizer) }
        if let dictionary { voicevox_open_jtalk_rc_delete(dictionary) }
    }
}
