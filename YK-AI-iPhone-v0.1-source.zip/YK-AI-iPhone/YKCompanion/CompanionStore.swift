import AVFoundation
import Combine
import Foundation
import FoundationModels

@MainActor
final class CompanionStore: ObservableObject {
    @Published var messages: [Message] = []
    @Published private(set) var library = ChatLibrary()
    @Published var draft = "" { didSet { if ready { save() } } }
    var activeChatID: UUID { library.selectedID }
    var chatTitle: String { library.selected.title }
    @Published private(set) var conversationArchives: [ConversationArchive] = []
    @Published var preferences = Preferences() {
        didSet { if ready { save() } }
    }
    @Published var memoryNote = "" {
        didSet { if ready { save() } }
    }
    @Published var isReplying = false
    @Published var replyStage = "返信を作っています…"
    @Published var notice: String?
    @Published var storageNotice: String?
    var activeTravelMessage: Message? {
        guard let last = messages.last, last.role == "assistant",
              let offer = last.travelOffer, offer.mode != .dismissed else { return nil }
        return last
    }
    @Published var pendingPersonality: String?
    @Published var modelStatus = "確認中"
    @Published var modelAvailable = false
    @Published var lastReplyTiming: ReplyTiming?
    @Published var lastAIErrorDetails: String?
    @Published var aiTestResult: String?
    @Published var photoReactionTestResult: String?
    @Published private(set) var contextAfterMessageID: UUID?

    var selectedPersona: Persona {
        if preferences.personality == "custom" {
            return Persona(id: "custom", name: "自分の話し方", prompt: String(preferences.customPersonality.prefix(400)))
        }
        return Persona.all.first { $0.id == preferences.personality } ?? Persona.all[0]
    }

    private var ready = false
    private var storageWritable = true
    private var replyTask: Task<Void, Never>?
    let audio = AudioService()
    private let fileURL: URL

    init() {
        var directory = FileManager.default.urls(for: .applicationSupportDirectory,
                                                  in: .userDomainMask)[0]
            .appendingPathComponent("YKCompanion", isDirectory: true)
        #if DEBUG && targetEnvironment(simulator)
        if ProcessInfo.processInfo.environment["YK_UI_TEST"] == "1" {
            directory.appendPathComponent("UITestState", isDirectory: true)
        }
        #endif
        fileURL = directory.appendingPathComponent("state.json")
        if FileManager.default.fileExists(atPath: fileURL.path) {
            do {
                let saved = try JSONDecoder().decode(SavedState.self, from: Data(contentsOf: fileURL))
                library = try ChatLibrary(migrating: saved)
                messages = library.selected.messages
                draft = library.selected.draft
                preferences = saved.preferences
                memoryNote = saved.memoryNote
                contextAfterMessageID = library.selected.contextAfterMessageID
                conversationArchives = library.selected.archives
            } catch {
                storageWritable = false
                storageNotice = "保存データを読み込めませんでした。元のファイルは上書きしません。この起動中の会話は保存されません。"
            }
        }
        ready = true
        refreshAvailability()
        #if DEBUG && targetEnvironment(simulator)
        if ProcessInfo.processInfo.environment["YK_UI_TEST_SEED"] == "1" {
            library = ChatLibrary()
            messages = []
            draft = ""
            conversationArchives = []
            contextAfterMessageID = nil
            preferences = Preferences()
            // Real offline place routing; no simulated AI responses.
            send("近くのカフェを探して")
            send("近くの公園を探して")
        }
        if ProcessInfo.processInfo.environment["YK_UI_TEST_TRAVEL"] == "1" {
            library = ChatLibrary(); messages = []; draft = ""; contextAfterMessageID = nil
            preferences = Preferences()
            send("秋葉原に行きたい")
        }
        #endif
    }

    func refreshAvailability() {
        switch SystemLanguageModel.default.availability {
        case .available:
            modelAvailable = true
            modelStatus = lastAIErrorDetails == nil
                ? "iPhone内のAI · モデル利用可能"
                : "iPhone内のAI · 直前の生成に失敗"
        case .unavailable(.deviceNotEligible):
            modelAvailable = false
            modelStatus = "この端末ではAppleの端末内AIを利用できません"
        case .unavailable(.modelNotReady):
            modelAvailable = false
            modelStatus = "AIの準備中です。設定でApple Intelligenceを確認してください"
        case .unavailable(.appleIntelligenceNotEnabled):
            modelAvailable = false
            modelStatus = "設定でApple Intelligenceをオンにしてください"
        case .unavailable:
            modelAvailable = false
            modelStatus = "Apple Intelligenceの設定・利用可能な言語や地域を確認してください"
        @unknown default:
            modelAvailable = false
            modelStatus = "端末内AIを利用できません。時間をおいて再確認してください"
        }
    }

    @discardableResult
    func send(_ raw: String, detectSettings: Bool = true, image: AnalyzedImage? = nil,
              replacing messageID: UUID? = nil) -> Bool {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        let text = trimmed.isEmpty && image != nil ? "この画像について教えて" : trimmed
        guard !text.isEmpty, text.count <= 600, !isReplying else { return false }
        let edit = messageID.flatMap {
            ConversationEdit.prepare(messages: messages, after: contextAfterMessageID, replacing: $0, with: text)
        }
        if messageID != nil && edit == nil { return false }
        if edit != nil && !storageWritable {
            notice = "保存データを保護するため編集できません。設定の保存状態を確認してください。"
            return false
        }
        let attachment = image?.attachment ?? edit?.replacement.attachment
        if let attachment, attachment.needsVisualAnalysis,
           !VisualModelFiles.ready() {
            notice = "写真の見た目を読むには、添付欄または設定から「写真AI」を準備してください。文字だけの質問は、添付欄で「文字だけで質問」を選べます。"
            return false
        }
        let startedAt = ProcessInfo.processInfo.systemUptime
        lastReplyTiming = nil
        notice = nil
        pendingPersonality = nil
        audio.stop()

        if attachment == nil, edit == nil, detectSettings, let proposal = PersonalityRequest.proposal(from: text) {
            pendingPersonality = proposal
            return true
        }
        var travel = attachment == nil ? TravelOffer.parse(text) : nil
        if travel == nil, attachment == nil, edit == nil,
           var previous = activeTravelMessage?.travelOffer, let mode = TravelOffer.followup(text) {
            previous.mode = mode
            travel = previous
        }
        if travel == nil {
            refreshAvailability()
            guard modelAvailable else {
                notice = modelStatus + "。場所の検索は「おでかけ」から使えます。"
                return false
            }
        }
        if let image {
            do { try ImageFiles.save(image) }
            catch { notice = "画像を保存できませんでした。空き容量を確認してください。"; return false }
        }
        if let edit {
            conversationArchives.append(edit.archive)
            messages = edit.prefix + [edit.replacement]
            contextAfterMessageID = edit.boundary
            // Save the archive and replacement atomically before generating anything.
            // On storage failure the active conversation remains unchanged.
            guard save() else {
                messages = edit.archive.messages
                contextAfterMessageID = edit.archive.contextAfterMessageID
                conversationArchives.removeLast()
                notice = "編集前の会話を保存できなかったため、変更しませんでした。"
                return false
            }
        } else {
            messages.append(Message(role: "user", text: text, attachment: attachment))
        }
        if let travel {
            let reply = travel.reply(personality: preferences.personality)
            messages.append(Message(role: "assistant", text: reply, completed: false, travelOffer: travel))
            save()
            if preferences.readAloud || preferences.voiceConversation { speak(reply) }
            return true
        }
        let history = ConversationContext.recent(Array(messages.dropLast()), after: contextAfterMessageID)
        let answerID = UUID()
        messages.append(Message(id: answerID, role: "assistant", text: "", completed: false))
        isReplying = true
        replyStage = "返信を作っています…"
        save()

        let instructions = ConversationPrompt.instructions(preferences: preferences, persona: selectedPersona,
            hasPhoto: attachment != nil || history.contains { $0.attachment != nil })
        let memo = String(memoryNote.prefix(400))
        let prompt = ConversationPrompt.message(text, memo: memo, attachment: attachment)
        let readAloud = preferences.readAloud || preferences.voiceConversation
        let brief = ConversationBrevity.isBrief(text, enabled: preferences.shortReplies)
        let maximumTokens = brief ? 180 : 512
        let replyPreferences = preferences
        let replyPersona = selectedPersona
        replyTask = Task { [weak self] in
            guard let self else { return }
            var firstTextSeconds: Double?
            var completed = false
            defer {
                self.lastReplyTiming = ReplyTiming(firstTextSeconds: firstTextSeconds,
                    totalSeconds: ProcessInfo.processInfo.systemUptime - startedAt,
                    characterCount: self.messages.first(where: { $0.id == answerID })?.text.count ?? 0,
                    completed: completed)
                self.isReplying = false
                self.replyTask = nil
                self.messages.removeAll { $0.id == answerID && $0.text.isEmpty }
                self.save()
            }
            do {
                var responsePrompt = prompt
                var analyzedAttachment = attachment
                if var photo = attachment, photo.needsVisualAnalysis {
                    self.replyStage = "写真の見た目をiPhone内で確認しています…"
                    await self.audio.prepareForVisualAnalysis()
                    try Task.checkCancellation()
                    photo.visualDescription = try await VisualCaptionEngine.shared.describe(imageURL: ImageFiles.url(photo.id))
                    photo.visualModel = "Qwen3-VL-2B-Instruct-4bit"
                    try Task.checkCancellation()
                    if let userIndex = self.messages.lastIndex(where: { $0.role == "user" && $0.attachment?.id == photo.id }) {
                        self.messages[userIndex].attachment = photo
                    }
                    responsePrompt = ConversationPrompt.message(text, memo: memo, attachment: photo)
                    analyzedAttachment = photo
                    self.replyStage = "写真への返事を作っています…"
                    self.save()
                }
                @MainActor func publish(_ content: String) throws {
                    try Task.checkCancellation()
                    if firstTextSeconds == nil && !content.isEmpty {
                        firstTextSeconds = ProcessInfo.processInfo.systemUptime - startedAt
                    }
                    if let index = self.messages.firstIndex(where: { $0.id == answerID }) {
                        self.messages[index].text = content
                    }
                }
                if let photo = PhotoReaction.reference(for: text, attachment: analyzedAttachment, history: history) {
                    self.replyStage = "写真への感想を考えています…"
                    _ = try await PhotoResponseGenerator.generate(text: text, photo: photo, history: history,
                        memo: memo, preferences: replyPreferences, persona: replyPersona) { content in
                            try publish(content)
                        }
                } else {
                    var entries: [Transcript.Entry] = [
                        .instructions(.init(segments: [.text(.init(content: instructions))], toolDefinitions: []))
                    ]
                    for message in history {
                        let content = message.role == "user"
                            ? ConversationPrompt.message(message.text, attachment: message.attachment, referenceLimit: 300)
                            : message.text
                        let segments: [Transcript.Segment] = [.text(.init(content: content))]
                        if message.role == "user" {
                            entries.append(.prompt(.init(segments: segments)))
                        } else {
                            entries.append(.response(.init(assetIDs: [], segments: segments)))
                        }
                    }
                    let session = LanguageModelSession(transcript: Transcript(entries: entries))
                    let stream = session.streamResponse(to: responsePrompt,
                        options: GenerationOptions(temperature: 0.7, maximumResponseTokens: maximumTokens))
                    for try await snapshot in stream {
                        if brief {
                            let preview = ConversationBrevity.preview(snapshot.content)
                            try publish(preview.text)
                            if preview.finished { break }
                        } else { try publish(snapshot.content) }
                    }
                }
                try Task.checkCancellation()
                guard self.messages.first(where: { $0.id == answerID })?.text
                    .trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false else {
                    throw AIResponseError.emptyResponse
                }
                completed = true
                if let index = self.messages.firstIndex(where: { $0.id == answerID }) {
                    self.messages[index].completed = true
                }
                self.lastAIErrorDetails = nil
                self.refreshAvailability()
                if readAloud, let reply = self.messages.first(where: { $0.id == answerID }) {
                    self.speak(reply.text)
                }
            } catch is CancellationError {
                self.notice = "返信を停止しました。"
            } catch {
                if Task.isCancelled {
                    self.notice = "返信を停止しました。"
                } else {
                    self.notice = self.describeFailure(error)
                        + (error is VisualFailure ? "" : "\n「設定」→「AI動作テスト」で、会話設定と切り離して確認できます。")
                }
            }
        }
        return true
    }

    // Uses the same streaming API, but never reads or edits conversation/persona/memory.
    // This is a user-triggered health check, not an automatic retry of a rejected request.
    func testAI() {
        guard !isReplying else { return }
        refreshAvailability()
        guard modelAvailable else {
            aiTestResult = modelStatus
            return
        }
        isReplying = true
        aiTestResult = "短い日本語の挨拶で確認しています…"
        audio.stop()
        let startedAt = ProcessInfo.processInfo.systemUptime
        replyTask = Task { [weak self] in
            guard let self else { return }
            defer {
                self.isReplying = false
                self.replyTask = nil
            }
            do {
                let session = LanguageModelSession(instructions:
                    "あなたは親切なアシスタントです。自然な日本語で一文だけ答えてください。")
                var answer = ""
                for try await snapshot in session.streamResponse(
                    to: "こんにちは。日本語で短く挨拶してください。",
                    options: GenerationOptions(temperature: 0.7, maximumResponseTokens: 128)) {
                    try Task.checkCancellation()
                    answer = snapshot.content
                }
                try Task.checkCancellation()
                guard !answer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    throw AIResponseError.emptyResponse
                }
                let elapsed = ProcessInfo.processInfo.systemUptime - startedAt
                self.aiTestResult = "テスト成功（\(String(format: "%.1f秒", elapsed))）\n\(answer)\n"
                    + "基本の文章生成は動いています。通常の会話だけ失敗する場合は、その診断コードを確認してください。"
                self.lastAIErrorDetails = nil
                self.notice = nil
                self.refreshAvailability()
            } catch {
                if Task.isCancelled || error is CancellationError {
                    self.aiTestResult = "テストを停止しました。"
                } else {
                    self.aiTestResult = self.describeFailure(error)
                }
            }
        }
    }

    // A user-run quality preview, not an automatic "success" score. No personal
    // photos, history or memory are read, and no generated examples are saved.
    func testPhotoReaction() {
        guard !isReplying else { return }
        refreshAvailability()
        guard modelAvailable else { photoReactionTestResult = modelStatus; return }
        let settings = preferences
        let persona = selectedPersona
        let photo = ImageAttachment(recognizedText: "",
            visualDescription: "人物が白いシャツにグレーのコートを重ねている。コートの襟に小さな金色のピンが付いている。", visualModel: "sample")
        isReplying = true
        audio.stop()
        photoReactionTestResult = "\(persona.name)の話し方で、サンプルへの感想を生成しています…"
        replyTask = Task { [weak self] in
            guard let self else { return }
            defer { self.isReplying = false; self.replyTask = nil }
            do {
                let reply = try await PhotoResponseGenerator.generate(text: "自撮りしたー", photo: photo,
                    history: [], memo: "", preferences: settings, persona: persona) { content in
                        self.photoReactionTestResult = content
                    }
                self.photoReactionTestResult = "\(persona.name)で生成した返事：\n\(reply)"
            } catch {
                self.photoReactionTestResult = Task.isCancelled || error is CancellationError
                    ? "テストを停止しました。" : self.describeFailure(error)
            }
        }
    }

    private enum AIResponseError: Error { case emptyResponse }

    private func describeFailure(_ error: Error) -> String {
        if let visualError = error as? VisualFailure { return visualError.localizedDescription }
        let code: String
        let guidance: String
        if let generationError = error as? LanguageModelSession.GenerationError {
            switch generationError {
            case .assetsUnavailable:
                code = "assetsUnavailable"
                guidance = "AppleのAIモデルを読み込めません。設定のダウンロード状況と空き容量を確認してください。"
            case .unsupportedLanguageOrLocale:
                code = "unsupportedLanguageOrLocale"
                guidance = "AIが言語・地域に対応できませんでした。iPhoneとSiriの言語設定を確認してください。"
            case .exceededContextWindowSize:
                code = "exceededContextWindowSize"
                guidance = "会話設定・メモ・履歴がモデルの上限を超えました。AI動作テストで基本動作を確認できます。"
            case .guardrailViolation:
                code = "guardrailViolation"
                guidance = "Appleの安全判定により生成が止まりました。入力だけでなく性格設定や履歴が影響する場合もあります。"
            case .refusal:
                code = "refusal"
                guidance = "モデルがこの内容への回答を断りました。別の内容でお試しください。"
            case .rateLimited:
                code = "rateLimited"
                guidance = "AIへの要求が一時的に制限されています。少し時間をおいてお試しください。"
            case .concurrentRequests:
                code = "concurrentRequests"
                guidance = "AIの処理が重なりました。処理を止めてから、もう一度お試しください。"
            case .decodingFailure:
                code = "decodingFailure"
                guidance = "モデルの返答を読み取れませんでした。AI動作テストで確認してください。"
            case .unsupportedGuide:
                code = "unsupportedGuide"
                guidance = "モデルが生成形式に対応できませんでした。アプリ側の確認が必要です。"
            @unknown default:
                code = "unknownGenerationError"
                guidance = "モデルから未分類のエラーが返りました。設定の技術情報で詳細を確認できます。"
            }
        } else if let failure = error as? PhotoResponseGenerator.Failure {
            switch failure {
            case .incompleteResponse:
                code = "incompletePhotoReaction"
                guidance = "写真への感想を最後まで生成できませんでした。途中の返事は次の会話の参考には使いません。"
            case .ungroundedResponse:
                code = "photoGroundingCheck"
                guidance = "写真の資料と合わない表現を検出したため、返答の表示と読み上げを止めました。"
            }
        } else if error is AIResponseError {
            code = "emptyResponse"
            guidance = "モデルから文章が返りませんでした。AI動作テストで確認してください。"
        } else {
            let nsError = error as NSError
            code = "\(nsError.domain):\(nsError.code)"
            guidance = "AIの処理に失敗しました。設定の技術情報で詳細を確認できます。"
        }
        // Local, in-memory diagnostic only. Never send error/context or chat to a server.
        lastAIErrorDetails = "\(code)\n\(String(String(reflecting: error).prefix(2400)))"
        refreshAvailability()
        return "\(guidance)\n診断コード：\(code)"
    }

    func stop() {
        replyTask?.cancel()
        audio.stop()
    }

    func enterBackground(preserveNavigationAudio: Bool = false) {
        replyTask?.cancel()
        if !preferences.backgroundAudio && !preserveNavigationAudio { audio.stop() }
        save()
    }

    func applyPersonality(_ raw: String) {
        let text = String(raw.prefix(400)).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isReplying else { return }
        preferences.customPersonality = text
        preferences.personality = "custom"
        pendingPersonality = nil
        // Preserve history on disk, but let the changed tone begin without old replies.
        contextAfterMessageID = messages.last?.id
        notice = "話し方を保存しました。次の返答から使います。「設定」で変更できます。"
        save()
    }

    // Do not change sessions while a reply or a diagnostic can still publish.
    // The UI also cancels microphone input before switching.
    @discardableResult
    func newChat() -> Bool {
        guard !isReplying, save() else { return false }
        let previous = library
        library.create()
        loadSelectedChat()
        guard save() else { library = previous; loadSelectedChat(); return false }
        return true
    }

    @discardableResult
    func selectChat(_ id: UUID) -> Bool {
        guard !isReplying, library.chats.contains(where: { $0.id == id }), save() else { return false }
        let previous = library
        library.select(id)
        loadSelectedChat()
        guard save() else { library = previous; loadSelectedChat(); return false }
        return true
    }

    func renameChat(_ id: UUID, to title: String) {
        guard !isReplying, save() else { return }
        let previous = library
        library.rename(id, to: title)
        if !save() { library = previous }
    }

    func deleteChat(_ id: UUID) {
        guard !isReplying, save() else { return }
        let previous = library
        let orphaned = library.remove(id)
        loadSelectedChat()
        guard save() else { library = previous; loadSelectedChat(); return }
        for imageID in orphaned { ImageFiles.remove(imageID) }
    }

    private func loadSelectedChat() {
        audio.stop()
        ready = false
        let chat = library.selected
        messages = chat.messages
        conversationArchives = chat.archives
        contextAfterMessageID = chat.contextAfterMessageID
        draft = chat.draft
        ready = true
        pendingPersonality = nil
        notice = nil
        lastReplyTiming = nil
        lastAIErrorDetails = nil
        refreshAvailability()
        // Offers are restored from the selected chat's messages, never another chat.
    }

    func chooseTravel(_ mode: TravelMode, messageID: UUID) {
        guard !isReplying, activeTravelMessage?.id == messageID,
              let index = messages.firstIndex(where: { $0.id == messageID }),
              var offer = messages[index].travelOffer else { return }
        offer.mode = mode
        messages[index].travelOffer = offer
        messages[index].text = offer.reply(personality: preferences.personality)
        save()
        audio.stop()
        if preferences.readAloud || preferences.voiceConversation { speak(messages[index].text) }
    }

    func updateTravelRequest(_ request: TransitRequest, messageID: UUID) {
        guard activeTravelMessage?.id == messageID,
              let index = messages.firstIndex(where: { $0.id == messageID }),
              messages[index].travelOffer?.request != request else { return }
        messages[index].travelOffer?.request = request
        save()
    }

    func speak(_ text: String) {
        audio.speak(text, preferences: preferences)
    }

    @discardableResult
    func save() -> Bool {
        guard ready, storageWritable else { return false }
        do {
            let directory = fileURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            var excludedDirectory = directory
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try excludedDirectory.setResourceValues(values)
            library.update(messages: messages, boundary: contextAfterMessageID,
                           archives: conversationArchives, draft: draft)
            let state = SavedState(version: 2, preferences: preferences, memoryNote: memoryNote,
                                   chatLibrary: library)
            let data = try JSONEncoder().encode(state)
            try data.write(to: fileURL, options: [.atomic, .completeFileProtection])
            storageNotice = nil
            return true
        } catch {
            storageNotice = "会話を保存できませんでした。端末の空き容量を確認してください。"
            return false
        }
    }

    func clearHistoryAndMemory() {
        guard !isReplying else { return }
        library.update(messages: messages, boundary: contextAfterMessageID,
                       archives: conversationArchives, draft: draft)
        let previous = library
        let previousMemory = memoryNote
        let images = Set(library.chats.flatMap(\.allMessages).compactMap { $0.attachment?.id })
        library = ChatLibrary()
        loadSelectedChat()
        ready = false
        memoryNote = ""
        ready = true
        storageWritable = true
        guard save() else {
            library = previous
            loadSelectedChat()
            ready = false; memoryNote = previousMemory; ready = true
            return
        }
        for id in images { ImageFiles.remove(id) }
    }
}
