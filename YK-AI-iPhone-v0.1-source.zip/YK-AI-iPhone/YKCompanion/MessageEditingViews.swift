import SwiftUI

struct MessageEditorSheet: View {
    @EnvironmentObject private var store: CompanionStore
    @Environment(\.dismiss) private var dismiss
    @FocusState private var editorFocused: Bool
    @State private var text: String
    @State private var error: String?
    let message: Message

    init(message: Message) {
        self.message = message
        _text = State(initialValue: message.text)
    }

    private var trimmed: String { text.trimmingCharacters(in: .whitespacesAndNewlines) }

    var body: some View {
        NavigationStack {
            Form {
                Section("送った文章") {
                    TextEditor(text: $text)
                        .frame(minHeight: 140)
                        .focused($editorFocused)
                        .accessibilityLabel("送信済みの文章を編集")
                        .accessibilityIdentifier("message-editor")
                        .onChange(of: text) { _, value in
                            if value.count > 600 { text = String(value.prefix(600)) }
                            error = nil
                        }
                    Text("\(text.count) / 600文字").font(.caption).foregroundStyle(.secondary)
                    if let attachment = message.attachment {
                        MessageImageView(attachment: attachment)
                        Text("添付画像はそのまま引き継ぎます。")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section {
                    Text("この文章から回答を作り直します。元の文章とその後の会話は、画面左上の「編集前の会話」に保存します。今の性格とメモで返信します。")
                        .font(.footnote).foregroundStyle(.secondary)
                    if store.isReplying {
                        HStack { ProgressView(); Text("返信を停止しています…") }
                    }
                    if let error { Text(error).foregroundStyle(.orange).font(.footnote) }
                    Button("保存して再送信") {
                        if store.send(text, detectSettings: false, replacing: message.id) {
                            editorFocused = false
                            dismiss()
                        } else {
                            error = store.notice ?? "文章を確認して、もう一度お試しください。"
                        }
                    }
                    .disabled(store.isReplying || trimmed.isEmpty || trimmed == message.text || text.count > 600)
                    .accessibilityIdentifier("save-edited-message")
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("文章を編集")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") { dismiss() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { editorFocused = false } label: {
                        Image(systemName: "keyboard.chevron.compact.down")
                    }.accessibilityLabel("編集キーボードを閉じる")
                }
            }
        }
    }
}

struct ConversationArchivesView: View {
    @EnvironmentObject private var store: CompanionStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            List {
                Section {
                    ForEach(store.conversationArchives.reversed()) { archive in
                        NavigationLink {
                            ArchivedConversationView(archive: archive)
                        } label: {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(archive.title).lineLimit(2)
                                Text(archive.date, format: .dateTime.month().day().hour().minute())
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }.accessibilityIdentifier("archive-\(archive.id)")
                    }
                } footer: {
                    Text("編集前の会話は見返すための記録です。現在の返信には使いません。設定の「会話とメモをすべて削除」で、この記録と添付画像も削除します。")
                }
            }
            .navigationTitle("編集前の会話")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { dismiss() } } }
        }
    }
}

private struct ArchivedConversationView: View {
    @EnvironmentObject private var store: CompanionStore
    let archive: ConversationArchive

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 16) {
                ForEach(archive.messages) { message in
                    VStack(alignment: .leading, spacing: 8) {
                        Text(message.role == "user" ? "あなた" : store.preferences.name)
                            .font(.caption).foregroundStyle(.secondary)
                        if let attachment = message.attachment { MessageImageView(attachment: attachment) }
                        Text(message.text).textSelection(.enabled)
                        if message.id == archive.editedMessageID {
                            Label("編集前の文章", systemImage: "pencil").font(.caption).foregroundStyle(.teal)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading).padding(14)
                    .background(message.role == "user" ? Color.teal.opacity(0.13) : Color(.secondarySystemBackground),
                                in: RoundedRectangle(cornerRadius: 18))
                }
            }.padding()
        }
        .navigationTitle("編集前の記録").navigationBarTitleDisplayMode(.inline)
    }
}
