import Foundation

enum TravelMode: String, Codable { case choice, walking, transit, dismissed }

struct TravelOffer: Codable, Equatable {
    var request: TransitRequest
    var mode: TravelMode = .choice
    var nearby = false

    static func parse(_ text: String) -> TravelOffer? {
        if let route = TransitRequest.parse(text) { return TravelOffer(request: route, mode: .transit) }
        guard let destination = OutingIntent.query(from: text) else { return nil }
        return TravelOffer(request: TransitRequest(destination: destination),
            mode: ["徒歩", "歩いて"].contains(where: text.contains) ? .walking : .choice,
            nearby: ["近く", "周辺", "この辺"].contains(where: text.contains))
    }

    // Only the last assistant proposal can accept a short follow-up. No LLM guess
    // starts location access, navigation, another app or a notification.
    static func followup(_ raw: String) -> TravelMode? {
        let text = raw.filter { !$0.isWhitespace && !"。！!？?〜～".contains($0) }
        if ["徒歩", "徒歩で", "歩く", "歩いて", "歩いて行く", "歩いてお願い"].contains(text) { return .walking }
        if ["電車", "電車で", "電車でお願い", "乗換案内", "乗り換え", "乗換で"].contains(text) { return .transit }
        if ["うん", "お願い", "案内して", "案内お願い", "よろしく"].contains(text) { return .choice }
        if ["今はいい", "やめとく", "案内はいらない", "キャンセル"].contains(text) { return .dismissed }
        return nil
    }

    func reply(personality: String) -> String {
        let destination = request.destination.isEmpty ? "行き先" : request.destination
        let polite = personality == "secretary"
        switch mode {
        case .choice:
            if polite { return "\(destination)、いいですね。こちらでご案内しましょうか？" }
            if personality == "sweet" { return "\(destination)いいね〜！ね、僕が案内しよっか？" }
            if personality == "devoted" { return "\(destination)いいね、ご主人！僕が案内しよっか？" }
            return "\(destination)いいね！ここで案内しようか？"
        case .walking:
            return polite ? "徒歩ですね。まず目的地の候補をご確認ください。" : "歩いて行こっか。まず、行き先はここで合ってるか確認しよ！"
        case .transit:
            return polite ? "電車ですね。出発駅と時刻を指定して確認しましょう。" : "電車で行こっか！どの駅から乗る？"
        case .dismissed:
            return polite ? "承知しました。また必要なときにどうぞ。" : "うん、また案内が欲しくなったら言ってね。"
        }
    }
}
