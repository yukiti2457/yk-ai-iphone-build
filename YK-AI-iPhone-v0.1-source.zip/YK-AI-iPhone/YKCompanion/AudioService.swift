import AVFoundation
import Combine
import UIKit

@MainActor
final class AudioService: NSObject, ObservableObject, AVSpeechSynthesizerDelegate, AVAudioPlayerDelegate {
    @Published private(set) var status = ""
    @Published private(set) var isBusy = false
    private let speaker = AVSpeechSynthesizer()
    private let voicevox = VoicevoxEngine()
    private var player: AVAudioPlayer?
    private var activeUtterance: AVSpeechUtterance?
    private var task: Task<Void, Never>?
    private var requestID = UUID()
    private var finished: CheckedContinuation<Bool, Never>?
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid
    private var interruption: AnyCancellable?

    override init() {
        super.init()
        speaker.delegate = self
        interruption = NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)
            .receive(on: RunLoop.main).sink { [weak self] notification in
                if notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt
                    == AVAudioSession.InterruptionType.began.rawValue {
                    self?.stop()
                    self?.status = "通話などにより読み上げを停止しました。"
                }
            }
    }

    private func activate() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .spokenAudio)
        try session.setActive(true)
    }

    func speak(_ text: String, preferences: Preferences) {
        stop()
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        let id = requestID
        isBusy = true
        if preferences.voiceEngine != "voicevox" {
            do {
                try activate()
                let utterance = AVSpeechUtterance(string: text)
                utterance.voice = AVSpeechSynthesisVoice(language: "ja-JP")
                utterance.rate = AVSpeechUtteranceDefaultSpeechRate * Float(preferences.voiceSpeed)
                utterance.pitchMultiplier = Float(pow(2, preferences.voicePitch * 4))
                activeUtterance = utterance
                status = "iPhone標準音声で読み上げ中"
                speaker.speak(utterance)
            } catch { fail(error) }
            return
        }
        status = "VOICEVOXの声を準備しています…（初回は時間がかかります）"
        // Finite work only: never keep the app alive by playing silent audio.
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "Voice synthesis") { [weak self] in
            Task { @MainActor in self?.stop() }
        }
        task = Task { [weak self] in
            guard let self else { return }
            do {
                for chunk in SpeechText.chunks(text) {
                    let data = try await self.voicevox.synthesize(chunk, style: preferences.voiceStyle,
                        speed: preferences.voiceSpeed, pitch: preferences.voicePitch)
                    try Task.checkCancellation()
                    guard self.requestID == id else { return }
                    try self.activate()
                    let audio = try AVAudioPlayer(data: data)
                    self.player = audio
                    audio.delegate = self
                    self.status = "\(VoiceCatalog.shared.character(for: preferences.voiceStyle)?.credit ?? "VOICEVOX") · 読み上げ中"
                    let success = await withCheckedContinuation { continuation in
                        self.finished = continuation
                        if !audio.play() { self.resolvePlayback(false) }
                    }
                    try Task.checkCancellation()
                    guard success else { throw VoicevoxEngine.Failure(message: "音声を再生できませんでした。") }
                }
                guard self.requestID == id else { return }
                self.finish()
            } catch {
                guard self.requestID == id, !Task.isCancelled else { return }
                self.fail(error)
            }
        }
    }

    func stop() {
        requestID = UUID()
        task?.cancel()
        task = nil
        activeUtterance = nil
        speaker.stopSpeaking(at: .immediate)
        player?.stop()
        player = nil
        resolvePlayback(false)
        finish()
    }

    func prepareForVisualAnalysis() async {
        let previousTask = task
        stop()
        await previousTask?.value
        await voicevox.releaseResources()
    }

    private func resolvePlayback(_ success: Bool) {
        let continuation = finished
        finished = nil
        continuation?.resume(returning: success)
    }

    private func finish() {
        isBusy = false
        status = ""
        task = nil
        player = nil
        activeUtterance = nil
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        if backgroundTask != .invalid {
            UIApplication.shared.endBackgroundTask(backgroundTask)
            backgroundTask = .invalid
        }
    }

    private func fail(_ error: Error) {
        finish()
        status = error.localizedDescription
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        let identity = ObjectIdentifier(utterance)
        Task { @MainActor in
            guard self.activeUtterance.map(ObjectIdentifier.init) == identity else { return }
            self.finish()
        }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        let identity = ObjectIdentifier(utterance)
        Task { @MainActor in
            guard self.activeUtterance.map(ObjectIdentifier.init) == identity else { return }
            self.finish()
        }
    }

    nonisolated func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        let identity = ObjectIdentifier(player)
        Task { @MainActor in
            guard self.player.map(ObjectIdentifier.init) == identity else { return }
            self.resolvePlayback(flag)
        }
    }

    nonisolated func audioPlayerDecodeErrorDidOccur(_ player: AVAudioPlayer, error: Error?) {
        let identity = ObjectIdentifier(player)
        Task { @MainActor in
            guard self.player.map(ObjectIdentifier.init) == identity else { return }
            self.resolvePlayback(false)
        }
    }
}
