import Foundation
import FoundationModels

@Generable
struct PhotoConversationResponse {
    @Guide(description: "今の写真資料から、感想で触れる服・色・形など一点を示す短い箇所を、そのまま抜き出す。資料の原文を使い、翻訳や追加はしない。身体の特徴や性別は選ばない。")
    var evidence: String

    @Guide(description: "相手の今の発言に応じた自然な反応を一文。選択された性格の口調で相手に直接話しかける。喜び、驚き、関心、いたわりなど場面に合う反応。写真の説明から始めない。")
    var response: String

    @Guide(description: "反応に続く具体的な感想を一〜二文。同じ性格の口調で、写真資料からわかる色・服・形など一つの見た目に触れ、それへの印象を言う。人物や物の分類だけで終えず、資料にない特徴を作らない。")
    var impression: String
}

// One local generation request, no canned reply and no retries after a refusal.
// The diagnostic uses this exact production path with fictional text observations.
@MainActor
enum PhotoResponseGenerator {
    enum Failure: Error { case incompleteResponse, ungroundedResponse }

    static func generate(text: String, photo: ImageAttachment, history: [Message], memo: String,
                         preferences: Preferences, persona: Persona,
                         onUpdate: @MainActor (String) throws -> Void) async throws -> String {
        let session = LanguageModelSession(instructions: PhotoReaction.instructions(preferences: preferences, persona: persona))
        let stream = session.streamResponse(to: PhotoReaction.prompt(text, photo: photo, history: history, memo: memo),
            generating: PhotoConversationResponse.self,
            options: GenerationOptions(temperature: 0.4, maximumResponseTokens: 400))
        var evidence: String?
        var response: String?
        var impression: String?
        for try await snapshot in stream {
            try Task.checkCancellation()
            evidence = snapshot.content.evidence
            response = snapshot.content.response
            impression = snapshot.content.impression
            // Photo reactions are checked before display and speech. Ordinary chat streams.
        }
        try Task.checkCancellation()
        guard response?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false,
              impression?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false else {
            throw Failure.incompleteResponse
        }
        let result = PhotoReaction.concise(response: response!, impression: impression!, short: preferences.shortReplies)
        guard PhotoReaction.isGrounded(result, evidence: evidence ?? "", photo: photo) else {
            throw Failure.ungroundedResponse
        }
        try onUpdate(result)
        return result
    }
}
