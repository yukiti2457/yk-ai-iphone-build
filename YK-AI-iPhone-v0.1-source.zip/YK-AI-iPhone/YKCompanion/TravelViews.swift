import SwiftUI
import MapKit

struct TransitSearchView: View {
    @EnvironmentObject private var places: PlacesStore
    @EnvironmentObject private var reminders: TrainReminderStore
    @Environment(\.openURL) private var openURL
    @State private var showRoute = false
    @State private var showReminder = false
    @FocusState private var editingStation: Bool
    private var date: Binding<Date> {
        Binding(get: { places.transit.requestedDate ?? Date() }, set: { places.transit.requestedDate = $0 })
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Yahoo!乗換案内", systemImage: "tram.fill").font(.headline)
            TextField("出発駅・出発地", text: $places.transit.origin)
                .focused($editingStation).submitLabel(.done).onSubmit { editingStation = false }
                .textFieldStyle(.roundedBorder).accessibilityIdentifier("transit-origin")
                .onChange(of: places.transit.origin) { _, value in places.transit.origin = String(value.prefix(100)) }
            TextField("到着駅・目的地", text: $places.transit.destination)
                .focused($editingStation).submitLabel(.done).onSubmit { editingStation = false }
                .textFieldStyle(.roundedBorder).accessibilityIdentifier("transit-destination")
                .onChange(of: places.transit.destination) { _, value in places.transit.destination = String(value.prefix(100)) }
            Picker("検索する時刻", selection: $places.transit.timeMode) {
                ForEach(TransitTime.allCases) { mode in Text(mode.title).tag(mode) }
            }.accessibilityIdentifier("transit-time-mode")
            if places.transit.timeMode != .now {
                DatePicker("日本時間", selection: date,
                           displayedComponents: [.first, .last].contains(places.transit.timeMode) ? [.date] : [.date, .hourAndMinute])
                    .environment(\.timeZone, TimeZone(identifier: "Asia/Tokyo")!)
            }
            if places.transit.yahooURL() != nil {
                Button {
                    if let url = places.transit.yahooURL() { openURL(url) }
                } label: { Label("Yahoo!で時刻・番線を確認", systemImage: "arrow.up.right.square") }
                    .buttonStyle(.borderedProminent).accessibilityIdentifier("open-yahoo-transit")
            } else { Text("出発駅と目的地を入力してください。").font(.caption).foregroundStyle(.secondary) }
            if let url = places.transit.googleURL {
                Link("Googleマップでも確認", destination: url).font(.callout)
            }
            Text("駅名・指定時刻をYahoo!へ渡します。Web版が開く場合もあります。Googleマップの時刻は開いた先で指定してください。")
                .font(.caption).foregroundStyle(.secondary)
            Button("近くの出発駅を探す") { places.query = "駅"; places.search(nearby: true) }
                .disabled(places.isSearching)
            HStack {
                Button("経路を貼り付けて読む") { showRoute = true }.accessibilityIdentifier("paste-transit-route")
                Spacer()
                Button("発車前のお知らせ") { showReminder = true }.accessibilityIdentifier("train-reminder")
            }.font(.callout)
            Text("Yahoo!の結果で共有・コピーした文章を貼り付けられます。最新の時刻・番線・遅延は、乗換案内と駅の表示で確認してください。")
                .font(.caption).foregroundStyle(.secondary)
            if reminders.hasReminder { Text("発車前のお知らせを予約中").font(.caption).foregroundStyle(.teal) }
        }
        .padding().background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 18))
        .sheet(isPresented: $showRoute) { RouteClipboardView() }
        .sheet(isPresented: $showReminder) { TrainReminderView() }
        .task { await reminders.refresh() }
    }
}

struct RouteClipboardView: View {
    @EnvironmentObject private var companion: CompanionStore
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Yahoo!乗換案内で経路を共有・コピーし、ここに貼り付けてください。URLだけの場合は経路の本文をコピーしてください。")
                    PasteButton(payloadType: String.self) { values in text = String(values.joined(separator: "\n").prefix(4000)) }
                    TextEditor(text: $text).frame(minHeight: 200)
                        .accessibilityIdentifier("route-text")
                        .onChange(of: text) { _, value in text = String(value.prefix(4000)) }
                    Button("貼り付けた経路を読み上げる") { companion.speak(text) }
                        .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    Button("読み上げを停止") { companion.audio.stop() }
                    Text("入力された文章を設定中の声で読み上げます。AIによる経路の補完や最新情報の取得はしません。この欄は閉じると消えます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("経路の読み上げ")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { dismiss() } } }
        }
    }
}

struct TrainReminderView: View {
    @EnvironmentObject private var places: PlacesStore
    @EnvironmentObject private var companion: CompanionStore
    @EnvironmentObject private var reminders: TrainReminderStore
    @Environment(\.dismiss) private var dismiss
    @State private var plan = TrainReminder(departure: Date(timeIntervalSince1970: floor(Date().timeIntervalSince1970 / 60) * 60 + 600))
    @State private var hasArrival = false
    @State private var arrival = Date().addingTimeInterval(3600)
    var body: some View {
        NavigationStack {
            Form {
                Section("Yahoo!で確認した電車を登録") {
                    TextField("出発駅", text: $plan.station)
                    TextField("路線名", text: $plan.line)
                    TextField("行き先（分かる場合）", text: $plan.boundFor)
                    TextField("番線（分かる場合・例：3番線）", text: $plan.platform)
                    DatePicker("発車・日本時間", selection: $plan.departure, displayedComponents: [.date, .hourAndMinute])
                    Toggle("到着予定も入力", isOn: $hasArrival)
                    if hasArrival {
                        DatePicker("到着・日本時間", selection: $arrival, displayedComponents: [.date, .hourAndMinute])
                            .onChange(of: arrival) { _, value in plan.arrival = value }
                    }
                    Toggle("乗換案内で日時・経路を確認した", isOn: $plan.confirmed)
                        .accessibilityIdentifier("confirm-train-plan")
                    Text("発車2分前に通知します。予約は1件で、新しい予約に置き換わります。2分以上先・7日以内の予定を登録できます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section {
                    if let message = plan.arrivalMessage(deadline: places.transit.timeMode == .arrival ? places.transit.requestedDate : nil) {
                        Text(message)
                    }
                    Button("この電車の案内を聞く") { companion.speak(plan.announcement) }
                        .disabled(!plan.valid())
                    Button("発車2分前に通知する") { Task { await reminders.schedule(plan) } }
                        .disabled(!plan.valid() || reminders.isSaving).accessibilityIdentifier("schedule-train-reminder")
                    Text(reminders.status).font(.callout)
                    if reminders.hasReminder { Button("予約を取り消す", role: .destructive) { reminders.cancel() } }
                    Text("画面ロック中は通知音と文章でお知らせします。音声の自動読み上げはしません。通知の表示はiPhoneの設定・集中モードに従います。登録内容は通知に表示されます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .environment(\.timeZone, TimeZone(identifier: "Asia/Tokyo")!)
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle("発車前のお知らせ")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { dismiss() } } }
            .onChange(of: hasArrival) { _, value in plan.arrival = value ? arrival : nil }
            .onChange(of: plan.station) { _, value in plan.station = String(value.prefix(100)); plan.confirmed = false }
            .onChange(of: plan.line) { _, value in plan.line = String(value.prefix(100)); plan.confirmed = false }
            .onChange(of: plan.boundFor) { _, value in plan.boundFor = String(value.prefix(100)); plan.confirmed = false }
            .onChange(of: plan.platform) { _, value in plan.platform = String(value.prefix(100)); plan.confirmed = false }
            .onChange(of: plan.departure) { _, _ in plan.confirmed = false }
            .onChange(of: plan.arrival) { _, _ in plan.confirmed = false }
            .task { plan.station = places.transit.origin; await reminders.refresh() }
        }
    }
}

struct WalkingNavigationView: View {
    @EnvironmentObject private var navigation: NavigationStore
    @EnvironmentObject private var companion: CompanionStore
    @EnvironmentObject private var microphone: MicrophoneService
    var body: some View {
        if navigation.isPreparing || navigation.route != nil || navigation.destination != nil {
            VStack(alignment: .leading, spacing: 12) {
                Label("ゆきAIの徒歩ナビ", systemImage: "figure.walk").font(.headline)
                Text(navigation.destination?.name ?? "行き先を確認中").font(.title3.bold())
                if navigation.isPreparing { ProgressView("経路を確認中…") }
                if let route = navigation.route {
                    Map {
                        MapPolyline(route.polyline).stroke(.teal, lineWidth: 5)
                        if let coordinate = navigation.coordinate { Marker("現在地", systemImage: "location.fill", coordinate: coordinate).tint(.blue) }
                        if let target = navigation.destination { Marker(target.name ?? "目的地", coordinate: target.placemark.coordinate) }
                    }.frame(height: 240).clipShape(RoundedRectangle(cornerRadius: 16))
                    Text("経路 約\(Int(route.distance))m・目安\(max(1, Int(ceil(route.expectedTravelTime / 60))))分")
                        .font(.caption)
                    if navigation.isNavigating { Text("残り 約\(Int(navigation.remaining))m").font(.headline) }
                    Text(navigation.nextInstruction).font(.body.bold())
                    Toggle("曲がり角への接近を読み上げる", isOn: $navigation.voiceEnabled)
                    if !navigation.isNavigating && !navigation.needsRecalculation {
                        Button("徒歩ナビを開始") {
                            microphone.cancel(); companion.stop(); navigation.start()
                        }.buttonStyle(.borderedProminent)
                    }
                }
                Text(navigation.notice).font(.callout)
                if navigation.needsRecalculation || (!navigation.isPreparing && !navigation.isNavigating) {
                    Button("現在地から経路を取り直す") { navigation.recalculate() }
                }
                if navigation.isNavigating || navigation.isPreparing {
                    Button("案内を終了", role: .destructive) { navigation.stop() }.buttonStyle(.bordered)
                }
                Text("案内中だけ現在地を更新し、画面ロック中も継続します。音声は遅延の少ないiPhone標準音声です。GPSが不正確な時は音声案内を待機します。経路はApple提供で、道路状況は現地で確認してください。")
                    .font(.caption).foregroundStyle(.secondary)
            }.padding().background(Color.teal.opacity(0.07), in: RoundedRectangle(cornerRadius: 18))
        }
    }
}
