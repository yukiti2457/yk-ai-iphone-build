import Combine
import CoreLocation
import MapKit
import UserNotifications

@MainActor
final class NavigationStore: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published private(set) var route: MKRoute?
    @Published private(set) var destination: MKMapItem?
    @Published private(set) var isPreparing = false
    @Published private(set) var isNavigating = false
    @Published private(set) var needsRecalculation = false
    @Published private(set) var notice = "行き先の候補を選ぶと、徒歩経路を確認できます。"
    @Published private(set) var nextInstruction = ""
    @Published private(set) var remaining = 0.0
    @Published private(set) var coordinate: CLLocationCoordinate2D?
    @Published var voiceEnabled = true {
        didSet { if !voiceEnabled { audio?.stop() } }
    }
    private let locator = LocationService()
    private let manager = CLLocationManager()
    private weak var audio: AudioService?
    private var request: MKDirections?
    private var task: Task<Void, Never>?
    private var requestID = UUID()
    private var preparedAt: Date?
    private var projectionOrigin = MKMapPoint()
    private var metersPerPoint = 1.0
    private var progress: WalkProgress?
    private var cues: [(distance: Double, instruction: String)] = []
    private var cueIndex = 0

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.distanceFilter = 5
        manager.activityType = .fitness
        manager.pausesLocationUpdatesAutomatically = false
    }

    func attachAudio(_ sharedAudio: AudioService) { audio = sharedAudio }

    func prepare(to item: MKMapItem) {
        stop()
        route = nil
        destination = item
        isPreparing = true
        notice = "現在地からの徒歩経路を確認しています…"
        let id = UUID()
        requestID = id
        task = Task { [weak self] in
            guard let self else { return }
            defer { if self.requestID == id { self.isPreparing = false; self.task = nil; self.request = nil } }
            do {
                let location = try await self.locator.current()
                try Task.checkCancellation()
                guard location.horizontalAccuracy <= 50 else { throw PlaceError.unavailable }
                let query = MKDirections.Request()
                query.source = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))
                query.destination = item
                query.transportType = .walking
                query.requestsAlternateRoutes = false
                let request = MKDirections(request: query)
                self.request = request
                let response = try await request.calculate()
                try Task.checkCancellation()
                guard self.requestID == id, let route = response.routes.first,
                      route.polyline.pointCount > 1, route.distance > 0 else { throw PlaceError.unavailable }
                self.projectionOrigin = MKMapPoint(location.coordinate)
                self.metersPerPoint = MKMetersPerMapPointAtLatitude(location.coordinate.latitude)
                let points = (0..<route.polyline.pointCount).map { self.point(route.polyline.points()[$0]) }
                self.progress = WalkProgress(points: points)
                let scale = (self.progress?.length ?? route.distance) / route.distance
                var offset = 0.0
                self.cues = route.steps.compactMap { step in
                    defer { offset += step.distance * scale }
                    let instruction = step.instructions.trimmingCharacters(in: .whitespacesAndNewlines)
                    return instruction.isEmpty ? nil : (offset, instruction)
                }
                self.cueIndex = 0
                self.route = route
                self.coordinate = location.coordinate
                self.remaining = self.progress?.length ?? route.distance
                self.preparedAt = Date()
                self.nextInstruction = self.cues.first?.instruction ?? "地図の徒歩経路を確認してください。"
                self.notice = "徒歩経路を確認して、案内を開始してください。"
            } catch {
                guard self.requestID == id else { return }
                self.notice = (error as? PlaceError)?.localizedDescription ?? "徒歩経路を取得できませんでした。通信状況と行き先を確認してください。"
            }
        }
    }

    func start() {
        guard let route, progress != nil, !isNavigating, !isPreparing else { return }
        guard let preparedAt, Date().timeIntervalSince(preparedAt) < 120 else {
            needsRecalculation = true
            notice = "時間が経ったため、現在地から経路を取り直してください。"
            return
        }
        guard manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways else {
            notice = PlaceError.denied.localizedDescription
            return
        }
        isNavigating = true
        needsRecalculation = false
        manager.allowsBackgroundLocationUpdates = true
        manager.showsBackgroundLocationIndicator = true
        manager.startUpdatingLocation()
        notice = "徒歩案内中。周囲の標識・横断歩道を優先してください。"
        var greeting = "\(destination?.name ?? "目的地")まで、徒歩約\(max(1, Int(ceil(route.expectedTravelTime / 60))))分の案内を始めるね。"
        if let first = cues.first, first.distance <= 5 {
            greeting += first.instruction
            cueIndex = 1
        }
        say(greeting)
    }

    func stop() {
        requestID = UUID()
        task?.cancel(); task = nil
        request?.cancel(); request = nil
        isPreparing = false
        isNavigating = false
        needsRecalculation = false
        manager.stopUpdatingLocation()
        manager.allowsBackgroundLocationUpdates = false
        audio?.stop()
        preparedAt = nil
        notice = "案内を終了しました。位置情報の更新も停止しました。"
    }

    func recalculate() { if let destination { prepare(to: destination) } }

    private func point(_ p: MKMapPoint) -> WalkPoint {
        WalkPoint(x: (p.x - projectionOrigin.x) * metersPerPoint, y: (p.y - projectionOrigin.y) * metersPerPoint)
    }

    private func say(_ text: String) {
        guard voiceEnabled else { return }
        var preferences = Preferences()
        preferences.voiceEngine = "system"
        preferences.voiceSpeed = 1.0
        audio?.speak(text, preferences: preferences)
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard isNavigating, let location = locations.last, var tracker = progress else { return }
        guard location.horizontalAccuracy >= 0, location.horizontalAccuracy <= 25,
              abs(location.timestamp.timeIntervalSinceNow) <= 15 else {
            notice = "GPSの精度を確認中です。音声案内を待機しています。"
            return
        }
        coordinate = location.coordinate
        let updated = tracker.update(point(MKMapPoint(location.coordinate)), accuracy: location.horizontalAccuracy,
                                     age: location.timestamp.timeIntervalSinceNow)
        progress = tracker
        if tracker.paused {
            manager.stopUpdatingLocation()
            manager.allowsBackgroundLocationUpdates = false
            isNavigating = false
            needsRecalculation = true
            notice = "経路から離れた可能性があります。立ち止まれる場所で経路を確認してください。"
            say("経路から離れたみたい。安全な場所で経路を確認してね。")
            return
        }
        guard updated else {
            notice = "現在地と経路を照合中です。曲がり角の案内を待機しています。"
            return
        }
        remaining = max(0, tracker.length - tracker.progress)
        notice = "徒歩案内中。位置情報は案内を終了すると停止します。"
        if remaining <= 15, let end = tracker.points.last,
           point(MKMapPoint(location.coordinate)).distance(to: end) <= 25 {
            stop()
            remaining = 0
            nextInstruction = "目的地付近です"
            notice = "目的地付近に到着しました。入口を確認してください。案内を終了しました。"
            say("目的地の近くだよ。入口を確認してね。")
            return
        }
        // Announce each MapKit instruction once, just before its route position.
        // Skip already passed cues when more than one becomes due in one update.
        var due: String?
        while cueIndex < cues.count, cues[cueIndex].distance <= tracker.progress + 35 {
            due = cues[cueIndex].instruction
            cueIndex += 1
        }
        if let due {
            nextInstruction = due
            say("次の案内だよ。\(due)")
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if isNavigating && manager.authorizationStatus != .authorizedWhenInUse && manager.authorizationStatus != .authorizedAlways {
            stop()
            notice = PlaceError.denied.localizedDescription
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        guard isNavigating else { return }
        notice = "現在地を取得できません。音声案内を待機しています。"
    }
}

@MainActor
final class TrainReminderStore: NSObject, ObservableObject, UNUserNotificationCenterDelegate {
    @Published private(set) var status = ""
    @Published private(set) var hasReminder = false
    @Published private(set) var isSaving = false
    private let center = UNUserNotificationCenter.current()
    private let identifier = "yk.train.departure"

    override init() {
        super.init()
        center.delegate = self
    }

    func refresh() async {
        let pending = await center.pendingNotificationRequests()
        if let request = pending.first(where: { $0.identifier == identifier }) {
            hasReminder = true
            status = "発車2分前にお知らせを予約しています。\n" + request.content.body
        } else {
            hasReminder = false
            status = "予約中のお知らせはありません。"
        }
    }

    func schedule(_ plan: TrainReminder) async {
        guard !isSaving, plan.valid() else { status = "経路を確認し、2分以上先・7日以内の発車時刻を指定してください。"; return }
        isSaving = true
        defer { isSaving = false }
        do {
            guard try await center.requestAuthorization(options: [.alert, .sound]) else {
                status = "通知が許可されていません。iPhoneの設定 → 通知 → ゆきAIで変更できます。"
                return
            }
            guard plan.valid() else { status = "発車まで2分を切りました。時刻を確認してください。"; return }
            let content = UNMutableNotificationContent()
            content.title = "ゆきAI・登録した電車の発車2分前"
            content.body = plan.announcement
            content.sound = .default
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: plan.departure.timeIntervalSinceNow - 120, repeats: false)
            try await center.add(UNNotificationRequest(identifier: identifier, content: content, trigger: trigger))
            await refresh()
        } catch { status = "お知らせを予約できませんでした。通知の設定を確認してください。" }
    }

    func cancel() {
        center.removePendingNotificationRequests(withIdentifiers: [identifier])
        center.removeDeliveredNotifications(withIdentifiers: [identifier])
        hasReminder = false
        status = "発車前のお知らせを取り消しました。"
    }

    nonisolated func userNotificationCenter(_ center: UNUserNotificationCenter,
        willPresent notification: UNNotification,
        withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound])
    }
}
