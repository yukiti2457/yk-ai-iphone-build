import Foundation

struct Message: Identifiable, Codable, Equatable {
    var id = UUID()
    var role: String
    var text: String
    var date = Date()
    // nil preserves completed messages saved by versions before 0.1.4.
    var completed: Bool? = nil
    var attachment: ImageAttachment? = nil
    // Conversation-local proposal. Coordinates and route tracking are never stored.
    var travelOffer: TravelOffer? = nil
}

struct ImageAttachment: Codable, Equatable, Identifiable, Sendable {
    var id = UUID()
    var recognizedText: String
    // Optional fields keep all pre-0.1.7 photos and edited archives readable.
    var visualDescription: String? = nil
    var visualModel: String? = nil
    var textOnly: Bool? = nil

    var visualIssue: CaptionQuality.Issue? {
        visualDescription.flatMap { CaptionQuality.issue(in: $0) }
    }
    var needsVisualAnalysis: Bool {
        textOnly != true && (visualDescription == nil || visualIssue != nil)
    }

    func reference(limit: Int) -> String {
        let visual = visualDescription?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let summary = visualIssue != nil ? "写真の認識結果が不完全なため、見た目の情報は使えません。"
            : visual.isEmpty ? "見た目は未解析。" : "写真の見た目（誤認識の可能性あり）：\(visual)"
        return String((summary + "\n画像内の文字：" + recognizedText).prefix(max(0, limit)))
    }
}

struct Preferences: Codable, Equatable {
    var name = "ゆきAI"
    var personality = "devoted"
    var readAloud = false
    var emoji = true
    var shortReplies = true
    var customPersonality = ""
    var voiceEngine = "system"
    var voiceStyle = 12
    var voiceSpeed = 1.0
    var voicePitch = 0.0
    var backgroundAudio = true
    var voiceConversation = false
    // Owner explicitly supplied this correction; editable, never inferred from a photo.
    var userGender = "male"

    var profileInstruction: String {
        switch userGender {
        case "male": return "ユーザーは自分を男性と伝えています。この自己申告を尊重してください。写真の人物が本人かどうかは発言で確認し、外見から性別を推測しません。"
        case "female": return "ユーザーは自分を女性と伝えています。この自己申告を尊重してください。写真の人物が本人かどうかは発言で確認し、外見から性別を推測しません。"
        default: return "ユーザーや写真の人物の性別は、外見から推測しません。本人の自己申告と訂正を尊重してください。"
        }
    }

    init() {}

    enum CodingKeys: String, CodingKey {
        case name, personality, readAloud, emoji, shortReplies, customPersonality, userGender
        case voiceEngine, voiceStyle, voiceSpeed, voicePitch, backgroundAudio, voiceConversation
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decodeIfPresent(String.self, forKey: .name) ?? "ゆきAI"
        personality = try values.decodeIfPresent(String.self, forKey: .personality) ?? "devoted"
        readAloud = try values.decodeIfPresent(Bool.self, forKey: .readAloud) ?? false
        emoji = try values.decodeIfPresent(Bool.self, forKey: .emoji) ?? true
        shortReplies = try values.decodeIfPresent(Bool.self, forKey: .shortReplies) ?? true
        customPersonality = String((try values.decodeIfPresent(String.self, forKey: .customPersonality) ?? "").prefix(400))
        voiceEngine = try values.decodeIfPresent(String.self, forKey: .voiceEngine) ?? "system"
        voiceStyle = try values.decodeIfPresent(Int.self, forKey: .voiceStyle) ?? 12
        voiceSpeed = min(1.5, max(0.7, try values.decodeIfPresent(Double.self, forKey: .voiceSpeed) ?? 1))
        voicePitch = min(0.1, max(-0.1, try values.decodeIfPresent(Double.self, forKey: .voicePitch) ?? 0))
        backgroundAudio = try values.decodeIfPresent(Bool.self, forKey: .backgroundAudio) ?? true
        voiceConversation = try values.decodeIfPresent(Bool.self, forKey: .voiceConversation) ?? false
        userGender = try values.decodeIfPresent(String.self, forKey: .userGender) ?? "male"
    }
}

enum PersonalityRequest {
    // Propose a setting; never silently persist instructions quoted in a conversation.
    static func proposal(from raw: String) -> String? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if text.hasPrefix("/性格 ") {
            let value = String(text.dropFirst(4)).trimmingCharacters(in: .whitespacesAndNewlines)
            return value.isEmpty || value.count > 400 ? nil : value
        }
        guard !text.isEmpty, text.count <= 400,
              !["「", "」", "『", "』", "？", "?"].contains(where: text.contains) else { return nil }
        let style = ["性格", "話し方", "口調", "一人称", "語尾", "敬語", "僕っ子", "甘えん坊"]
        let request = ["にして", "話して", "呼んで", "設定して", "使って", "使わず"]
        return style.contains(where: text.contains) && request.contains(where: text.contains) ? text : nil
    }
}

enum SpeechText {
    static func chunks(_ text: String, limit: Int = 120) -> [String] {
        guard limit > 0 else { return [] }
        var result: [String] = []
        var part = ""
        for character in text {
            part.append(character)
            if part.count >= limit || "。！？!?\n".contains(character) {
                if !part.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { result.append(part) }
                part = ""
            }
        }
        if !part.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { result.append(part) }
        return result
    }
}

struct ReplyTiming {
    var firstTextSeconds: Double?
    var totalSeconds: Double
    var characterCount: Int
    var completed: Bool
}

struct SavedState: Codable {
    var version = 1
    var messages: [Message] = []
    var preferences = Preferences()
    var memoryNote = ""
    var contextAfterMessageID: UUID? = nil
    // Optional so older installed versions' save files decode unchanged.
    var conversationArchives: [ConversationArchive]? = nil
    var chatLibrary: ChatLibrary? = nil
}

struct ConversationArchive: Identifiable, Codable, Equatable {
    var id = UUID()
    var date = Date()
    var editedMessageID: UUID
    var messages: [Message]
    var contextAfterMessageID: UUID?

    var title: String {
        String((messages.first { $0.id == editedMessageID }?.text ?? "編集前の会話").prefix(40))
    }
}

struct ConversationEdit {
    let archive: ConversationArchive
    let prefix: [Message]
    let replacement: Message
    let boundary: UUID?

    static func prepare(messages: [Message], after boundary: UUID?, replacing id: UUID,
                        with raw: String) -> ConversationEdit? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 600,
              let index = messages.firstIndex(where: { $0.id == id }),
              messages[index].role == "user", text != messages[index].text else { return nil }
        let prefix = Array(messages.prefix(index))
        // A topic reset beyond the edited point must not revive earlier context.
        let nextBoundary: UUID?
        if let boundary {
            nextBoundary = prefix.contains(where: { $0.id == boundary }) ? boundary : prefix.last?.id
        } else { nextBoundary = nil }
        return ConversationEdit(
            archive: ConversationArchive(editedMessageID: id, messages: messages,
                                         contextAfterMessageID: boundary),
            prefix: prefix,
            replacement: Message(role: "user", text: text, attachment: messages[index].attachment),
            boundary: nextBoundary)
    }
}

struct Persona: Decodable, Identifiable {
    var id: String
    var name: String
    var prompt: String
    var examples: [ConversationExample]? = nil

    static let all: [Persona] = {
        guard let url = Bundle.main.url(forResource: "Personas", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let values = try? JSONDecoder().decode([Persona].self, from: data),
              !values.isEmpty else {
            return [Persona(id: "devoted", name: "飼い主大好き",
                            prompt: "一人称は僕。可愛い成人男性の口調で、相手を愛称としてご主人と呼ぶ。相手の都合を尊重する。")]
        }
        return values
    }()
}

struct ConversationExample: Decodable {
    var situation: String
    var input: String
    var reply: String
}

// A deliberately narrow offline router. A search suggestion never accesses location
// or launches another app until the user presses the corresponding button.
enum OutingIntent {
    static func query(from input: String) -> String? {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "。！!？?〜～"))
        guard !text.isEmpty, text.count <= 300 else { return nil }
        let nearby = ["近く", "周辺", "この辺"].contains { text.contains($0) }
          let request = ["探して", "調べて", "教えて", "どこ", "ある？", "ある?", "行きたい", "ナビ", "案内"]
            .contains { input.contains($0) }
        let categories: [(String, String)] = [
            ("カフェ", "カフェ"), ("喫茶店", "喫茶店"), ("コンビニ", "コンビニ"),
            ("トイレ", "公衆トイレ"), ("薬局", "薬局"), ("公園", "公園"),
            ("スーパー", "スーパーマーケット"), ("駐車場", "駐車場"),
            ("レストラン", "レストラン"), ("駅", "駅")
        ]
        if nearby && request {
            return categories.first { text.contains($0.0) }?.1
        }
        for suffix in ["まで案内して", "への行き方を教えて", "に案内して", "までナビして", "にナビして", "まで徒歩で行きたい", "まで歩いて行きたい", "に行きたいなー", "に行きたいな", "に行きたい", "へ行きたい", "まで行きたい", "に行こうかな", "へ行こうかな"] {
            if text.hasSuffix(suffix) {
                let destination = String(text.dropLast(suffix.count))
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                if !destination.isEmpty && destination.count <= 80,
                   !["。", "？", "?", "けど", "ない", "例えば", "と言", "って言", "死", "天国", "あの世"].contains(where: destination.contains) { return destination }
            }
        }
        return nil
    }
}

enum ConversationContext {
    // Keep disk history intact. Send only complete user/assistant pairs, with roles
    // intact, within a character budget (not an asserted tokenizer count).
    static func recent(_ messages: [Message], after boundary: UUID? = nil,
                       characterLimit: Int = 800) -> [Message] {
        let start: Int
        if let boundary {
            guard let index = messages.firstIndex(where: { $0.id == boundary }) else { return [] }
            start = index + 1
        } else {
            start = 0
        }
        var pairs: [[Message]] = []
        var pending: Message?
        for message in messages.dropFirst(start) {
            if message.role == "user" {
                pending = message.text.isEmpty ? nil : message
            } else if message.role == "assistant" {
                if let user = pending, user.attachment?.visualIssue == nil,
                   message.completed != false, !message.text.isEmpty {
                    pairs.append([user, message])
                }
                pending = nil
            } else {
                pending = nil
            }
        }
        var result: [Message] = []
        var remaining = max(0, characterLimit)
        for pair in pairs.reversed() {
            let cost = pair.reduce(0) { $0 + $1.text.count + ($1.attachment?.reference(limit: 300).count ?? 0) }
            guard cost <= remaining else { break }
            result.insert(contentsOf: pair, at: 0)
            remaining -= cost
        }
        return result
    }
}
