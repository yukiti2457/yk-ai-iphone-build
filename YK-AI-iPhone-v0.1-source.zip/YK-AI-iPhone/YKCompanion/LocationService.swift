import Combine
import CoreLocation
import Foundation
import MapKit

enum PlaceError: LocalizedError {
    case denied, timeout, unavailable, busy
    var errorDescription: String? {
        switch self {
        case .denied: return "位置情報が許可されていません。地名で検索するか、iPhoneの設定から許可してください。"
        case .timeout: return "現在地を取得できませんでした。電波状況を確認するか、地名で検索してください。"
        case .unavailable: return "現在地を取得できません。位置情報サービスを確認してください。"
        case .busy: return "現在地を確認中です。少し待ってください。"
        }
    }
}

@MainActor
final class LocationService: NSObject, CLLocationManagerDelegate {
    private let manager = CLLocationManager()
    private var pending: CheckedContinuation<CLLocation, Error>?
    private var requestID: UUID?
    private var timeoutTask: Task<Void, Never>?

    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyHundredMeters
    }

    func current() async throws -> CLLocation {
        guard pending == nil else { throw PlaceError.busy }
        let id = UUID()
        return try await withTaskCancellationHandler(operation: {
            try Task.checkCancellation()
            return try await withCheckedThrowingContinuation { continuation in
                pending = continuation
                requestID = id
                timeoutTask = Task { [weak self] in
                    try? await Task.sleep(for: .seconds(30))
                    guard !Task.isCancelled, self?.requestID == id else { return }
                    self?.finish(.failure(PlaceError.timeout))
                }
                startForAuthorization()
            }
        }, onCancel: { [weak self] in
            Task { @MainActor in
                if self?.requestID == id { self?.finish(.failure(CancellationError())) }
            }
        })
    }

    private func startForAuthorization() {
        guard pending != nil else { return }
        switch manager.authorizationStatus {
        case .notDetermined: manager.requestWhenInUseAuthorization()
        case .authorizedWhenInUse, .authorizedAlways: manager.requestLocation()
        case .denied, .restricted: finish(.failure(PlaceError.denied))
        @unknown default: finish(.failure(PlaceError.unavailable))
        }
    }

    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        startForAuthorization()
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last,
              location.horizontalAccuracy >= 0,
              abs(location.timestamp.timeIntervalSinceNow) < 60 else {
            finish(.failure(PlaceError.unavailable))
            return
        }
        finish(.success(location))
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        finish(.failure(PlaceError.unavailable))
    }

    private func finish(_ result: Result<CLLocation, Error>) {
        guard let continuation = pending else { return }
        pending = nil
        requestID = nil
        timeoutTask?.cancel()
        timeoutTask = nil
        manager.stopUpdatingLocation()
        continuation.resume(with: result)
    }
}

struct Place: Identifiable {
    let id = UUID()
    let item: MKMapItem
    let distance: CLLocationDistance?
}

@MainActor
final class PlacesStore: ObservableObject {
    @Published var transit = TransitRequest()
    @Published var query = "カフェ"
    @Published var places: [Place] = []
    @Published var isSearching = false
    @Published var notice: String?
    @Published var hasSearched = false
    @Published var searchID = UUID()
    @Published var region = MKCoordinateRegion()
    private let locator = LocationService()
    private var task: Task<Void, Never>?
    private var activeSearch: MKLocalSearch?

    func search(nearby: Bool) {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !term.isEmpty, term.count <= 100, !isSearching else { return }
        isSearching = true
        places = []
        notice = nil
        hasSearched = false
        task = Task { [weak self] in
            guard let self else { return }
            defer { self.isSearching = false; self.activeSearch = nil; self.task = nil }
            do {
                let location: CLLocation?
                if nearby {
                    location = try await self.locator.current()
                } else {
                    location = nil
                }
                try Task.checkCancellation()
                let request = MKLocalSearch.Request()
                request.naturalLanguageQuery = term
                request.resultTypes = [.address, .pointOfInterest]
                if let location {
                    request.region = MKCoordinateRegion(center: location.coordinate,
                        latitudinalMeters: 4000, longitudinalMeters: 4000)
                }
                let search = MKLocalSearch(request: request)
                self.activeSearch = search
                let response = try await search.start()
                try Task.checkCancellation()
                let results = response.mapItems.map { item in
                    Place(item: item, distance: location.flatMap { origin in
                        item.placemark.location.map { origin.distance(from: $0) }
                    })
                }
                self.places = Array(results.sorted {
                    ($0.distance ?? .greatestFiniteMagnitude) < ($1.distance ?? .greatestFiniteMagnitude)
                }.prefix(8))
                self.region = response.boundingRegion
                self.searchID = UUID()
                self.hasSearched = true
                if self.places.isEmpty { self.notice = "候補が見つかりませんでした。別の言葉で探してみてください。" }
            } catch {
                if Task.isCancelled || error is CancellationError {
                    self.notice = "検索を停止しました。"
                } else if let known = error as? PlaceError {
                    self.notice = known.localizedDescription
                } else {
                    self.notice = "場所を検索できませんでした。通信状況を確認するか、別の地名・施設名で試してください。"
                }
            }
        }
    }

    func stop() {
        task?.cancel()
        activeSearch?.cancel()
    }

    func navigate(to place: Place, walking: Bool) {
        let opened = place.item.openInMaps(launchOptions: [
            MKLaunchOptionsDirectionsModeKey: walking
                ? MKLaunchOptionsDirectionsModeWalking : MKLaunchOptionsDirectionsModeDriving
        ])
        if !opened { notice = "マップを開けませんでした。Appleのマップアプリが利用できるか確認してください。" }
    }

    func navigateTransit(to place: Place) {
        if !place.item.openInMaps(launchOptions: [MKLaunchOptionsDirectionsModeKey: MKLaunchOptionsDirectionsModeTransit]) {
            notice = "マップを開けませんでした。"
        }
    }
}
