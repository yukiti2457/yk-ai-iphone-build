import MapKit
import PhotosUI
import SwiftUI

struct CompanionView: View {
    @State private var tab = 0

    var body: some View {
        TabView(selection: $tab) {
            ChatView(openPlaces: { tab = 1 })
                .tabItem { Label("会話", systemImage: "bubble.left.and.bubble.right") }.tag(0)
            OutingView()
                .tabItem { Label("おでかけ", systemImage: "map") }.tag(1)
            PreferencesView()
                .tabItem { Label("設定", systemImage: "slider.horizontal.3") }.tag(2)
        }
    }
}

struct ChatView: View {
    @EnvironmentObject private var navigation: NavigationStore
    @EnvironmentObject private var store: CompanionStore
    @EnvironmentObject private var places: PlacesStore
    @EnvironmentObject private var audio: AudioService
    @EnvironmentObject private var microphone: MicrophoneService
    @EnvironmentObject private var attachments: AttachmentStore
    @State private var pickedPhoto: PhotosPickerItem?
    @State private var showChats = false
    @State private var editingMessage: Message?
    @State private var showEditHistory = false
    @FocusState private var inputFocused: Bool
    var openPlaces: () -> Void

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack(spacing: 7) {
                    Circle().fill(store.modelAvailable && store.lastAIErrorDetails == nil
                        ? Color.teal : Color.orange).frame(width: 7, height: 7)
                    Text(store.modelStatus).font(.caption).foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(.horizontal).padding(.vertical, 8)
                HStack {
                    Text("性格：\(store.selectedPersona.name)").font(.caption).foregroundStyle(.teal)
                    Spacer()
                    if !store.conversationArchives.isEmpty {
                        Button { inputFocused = false; showEditHistory = true } label: {
                            Image(systemName: "clock.arrow.circlepath")
                        }.accessibilityLabel("編集前の会話")
                    }
                    Button { microphone.cancel(); inputFocused = false; store.newChat() } label: {
                        Label("新しいチャット", systemImage: "square.and.pencil")
                    }.font(.caption)
                        .disabled(store.isReplying || attachments.isLoading || attachments.draft != nil)
                        .accessibilityIdentifier("new-chat")
                }.padding(.horizontal).padding(.bottom, 8)
                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 16) {
                            if store.messages.isEmpty {
                                VStack(alignment: .leading, spacing: 12) {
                                    Image(systemName: "snowflake").font(.system(size: 36)).foregroundStyle(.teal)
                                    Text("何から話そう？").font(.title2.bold())
                                    Text("おしゃべりも、近くの場所探しも。\n僕が一緒に考えるよ。")
                                        .foregroundStyle(.secondary)
                                    Button("近くのカフェを探して") {
                                        store.send("近くのカフェを探して")
                                    }.buttonStyle(.bordered)
                                }.padding(.vertical, 35)
                                    .simultaneousGesture(TapGesture().onEnded { inputFocused = false })
                            }
                            ForEach(store.messages) { message in
                                HStack(alignment: .top) {
                                    if message.role == "user" { Spacer(minLength: 32) }
                                    VStack(alignment: .leading, spacing: 8) {
                                        Text(message.role == "user" ? "あなた" : store.preferences.name)
                                            .font(.caption).foregroundStyle(.secondary)
                                        if let attachment = message.attachment { MessageImageView(attachment: attachment) }
                                        if message.text.isEmpty {
                                            ProgressView(store.replyStage).font(.caption)
                                        } else {
                                            Text(message.text).textSelection(.enabled)
                                                .accessibilityIdentifier("message-\(message.id)")
                                            if message.role == "user" {
                                                Button {
                                                    inputFocused = false
                                                    microphone.cancel()
                                                    store.stop()
                                                    editingMessage = message
                                                } label: {
                                                    Label("編集", systemImage: "pencil").font(.caption)
                                                }.accessibilityIdentifier("edit-\(message.id)")
                                            }
                                            if message.role == "assistant" && !store.isReplying {
                                                Button { microphone.cancel(); store.speak(message.text) } label: {
                                                    Label("読み上げ", systemImage: "speaker.wave.2")
                                                        .font(.caption)
                                                }
                                            }
                                        }
                                    }
                                    .padding(14)
                                    .background(message.role == "user" ? Color.teal.opacity(0.13) : Color(.secondarySystemBackground))
                                    .clipShape(RoundedRectangle(cornerRadius: 18))
                                    if message.role != "user" { Spacer(minLength: 24) }
                                }
                                .contentShape(Rectangle())
                                .simultaneousGesture(TapGesture().onEnded { inputFocused = false })
                                .id(message.id)
                                if message.id == store.contextAfterMessageID {
                                    HStack {
                                        Rectangle().frame(height: 1)
                                        Text("ここから新しい話題").font(.caption).fixedSize()
                                        Rectangle().frame(height: 1)
                                    }.foregroundStyle(.secondary).padding(.vertical, 4)
                                }
                            }
                            if let message = store.activeTravelMessage, let offer = message.travelOffer {
                                ChatTravelView(messageID: message.id, offer: offer)
                                    .id(message.id.uuidString + "-travel")
                            }
                            WalkingNavigationView().id("chat-walking-navigation")
                            if store.pendingPersonality != nil { PersonalityProposalView() }
                            if let notice = store.notice { Text(notice).font(.footnote).foregroundStyle(.secondary) }
                            if let notice = store.storageNotice { Text(notice).font(.footnote).foregroundStyle(.orange) }
                            Color.clear.frame(height: 1).id("bottom")
                        }.padding()
                            .frame(maxWidth: .infinity, minHeight: 180, alignment: .topLeading)
                            .background {
                                Color.clear.contentShape(Rectangle())
                                    .onTapGesture { inputFocused = false }
                            }
                    }
                    .id(store.activeChatID)
                    .onChange(of: store.activeChatID) { _, _ in proxy.scrollTo("bottom", anchor: .bottom) }
                    .accessibilityIdentifier("chat-scroll")
                    .onChange(of: navigation.isPreparing) { _, preparing in
                        if preparing { inputFocused = false; withAnimation { proxy.scrollTo("chat-walking-navigation", anchor: .top) } }
                    }
                    .scrollDismissesKeyboard(.interactively)
                    .simultaneousGesture(DragGesture(minimumDistance: 20).onEnded { value in
                        // Also dismiss when a short transcript can't scroll into the keyboard.
                        if value.translation.height > 45 && value.translation.height > abs(value.translation.width) {
                            inputFocused = false
                        }
                    })
                    .onChange(of: store.messages.last?.text) { _, _ in
                        proxy.scrollTo("bottom", anchor: .bottom)
                    }
                    .onChange(of: store.messages.count) { _, _ in
                        withAnimation { proxy.scrollTo("bottom", anchor: .bottom) }
                    }
                    .onChange(of: store.notice) { _, _ in
                        proxy.scrollTo("bottom", anchor: .bottom)
                    }
                }
                HStack {
                    Toggle("音声会話", isOn: $store.preferences.voiceConversation)
                        .font(.caption).fixedSize()
                    Spacer()
                    if audio.isBusy {
                        Button("読み上げ停止") { audio.stop() }.font(.caption)
                    }
                    if inputFocused {
                        Button { inputFocused = false } label: {
                            Label("閉じる", systemImage: "keyboard.chevron.compact.down")
                                .font(.caption).frame(minHeight: 32)
                        }
                        .buttonStyle(.bordered)
                        .accessibilityLabel("キーボードを閉じる")
                        .accessibilityIdentifier("dismiss-chat-keyboard")
                    }
                }.padding(.horizontal)
                AttachmentDraftView(openPlaces: openPlaces)
                if microphone.isListening {
                    Text("聞いています · マイクを押して確定")
                        .font(.caption).foregroundStyle(.red).padding(.top, 5)
                } else if let notice = microphone.notice {
                    Text(notice).font(.caption).foregroundStyle(.secondary).padding(.horizontal)
                }
                if !audio.status.isEmpty {
                    Text(audio.status).font(.caption).foregroundStyle(.secondary).padding(.horizontal)
                }
                HStack(alignment: .bottom) {
                    PhotosPicker(selection: $pickedPhoto, matching: .images, preferredItemEncoding: .current) {
                        Image(systemName: "photo.badge.plus").font(.title2).padding(.vertical, 8)
                    }.disabled(store.isReplying || microphone.isListening)
                        .accessibilityLabel("写真・スクショを添付")
                    Button {
                        inputFocused = false
                        if microphone.isListening { microphone.finish() }
                        else {
                            audio.stop()
                            microphone.start { value in
                                store.draft = value
                                if store.preferences.voiceConversation {
                                    if store.send(value, image: attachments.draft) { store.draft = ""; attachments.clear() }
                                }
                            }
                        }
                    } label: {
                        Image(systemName: microphone.isListening ? "stop.circle.fill" : "mic.fill")
                            .font(.title2).foregroundStyle(microphone.isListening ? .red : .teal)
                            .padding(.vertical, 8)
                    }.disabled(store.isReplying || attachments.isLoading)
                        .accessibilityLabel(microphone.isListening ? "音声入力を確定" : "マイクで話す")
                    TextField("ゆきAIに話しかける", text: $store.draft, axis: .vertical)
                        .lineLimit(1...5).padding(12)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 18))
                        .focused($inputFocused)
                        .accessibilityIdentifier("chat-input")
                        .onChange(of: store.draft) { _, value in
                            if value.count > 600 { store.draft = String(value.prefix(600)) }
                        }
                    if store.isReplying {
                        Button { store.stop() } label: {
                            Image(systemName: "stop.fill").padding(12)
                        }.accessibilityLabel("返信を止める")
                    } else {
                        Button {
                            microphone.cancel()
                            let value = store.draft
                            // Keep unsent text if Apple Intelligence is unavailable.
                            if store.send(value, image: attachments.draft) {
                                store.draft = ""; inputFocused = false; attachments.clear()
                            }
                        } label: {
                            Image(systemName: "arrow.up.circle.fill").font(.system(size: 34))
                                .frame(width: 44, height: 44)
                        }
                        .disabled(attachments.isLoading || (store.draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && attachments.draft == nil))
                        .accessibilityLabel("送信")
                        .accessibilityIdentifier("send-message")
                    }
                }.padding(.horizontal).padding(.vertical, 10)
            }
            .navigationTitle(store.preferences.name.isEmpty ? "ゆきAI" : store.preferences.name)
            .navigationBarTitleDisplayMode(.inline)
            .onChange(of: microphone.transcript) { _, value in
                if microphone.isListening { store.draft = value }
            }
            .onChange(of: pickedPhoto) { _, item in
                if let item { attachments.load(item); pickedPhoto = nil }
            }
            .onDisappear { microphone.cancel() }
            .sheet(item: $editingMessage) { message in
                MessageEditorSheet(message: message)
            }
            .sheet(isPresented: $showEditHistory) { ConversationArchivesView() }
            .sheet(isPresented: $showChats) { ChatListView() }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Button { inputFocused = false } label: {
                        VStack(spacing: 2) {
                            Text(store.preferences.name.isEmpty ? "ゆきAI" : store.preferences.name)
                                .font(.headline)
                            Text(store.chatTitle).font(.caption2).lineLimit(1)
                        }.foregroundStyle(.primary)
                    }.accessibilityLabel("会話タイトル・キーボードを閉じる")
                        .accessibilityIdentifier("chat-title")
                }
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        inputFocused = false
                        microphone.cancel()
                        audio.stop()
                        showChats = true
                    } label: { Image(systemName: "line.3.horizontal") }
                        .accessibilityLabel("チャット一覧")
                        .accessibilityIdentifier("open-chats")
                        .disabled(store.isReplying || attachments.isLoading || attachments.draft != nil)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { microphone.cancel(); store.stop() } label: { Image(systemName: "speaker.slash") }
                        .accessibilityLabel("読み上げと返信を停止")
                }
            }
        }
    }
}

struct OutingView: View {
    @EnvironmentObject private var places: PlacesStore
    @EnvironmentObject private var navigation: NavigationStore

    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    WalkingNavigationView().id("walking-navigation")
                    TransitSearchView()
                    Text("一緒に、行き先を探そう。").font(.title2.bold())
                    TextField("カフェ・駅・地名・施設名", text: $places.query)
                        .textFieldStyle(.roundedBorder)
                        .onChange(of: places.query) { _, value in
                            if value.count > 100 { places.query = String(value.prefix(100)) }
                        }
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack {
                            ForEach(["カフェ", "コンビニ", "公衆トイレ", "駅", "公園"], id: \.self) { term in
                                Button(term) { places.query = term }.buttonStyle(.bordered)
                            }
                        }
                    }
                    VStack(alignment: .leading, spacing: 10) {
                        Button { places.search(nearby: true) } label: {
                            Label("現在地の周辺を探す", systemImage: "location")
                                .frame(maxWidth: .infinity)
                        }.buttonStyle(.borderedProminent)
                        Button("地名・施設名で検索") { places.search(nearby: false) }
                            .buttonStyle(.bordered)
                        Text("周辺検索では現在地と検索語をAppleの地図サービスへ送信します。地名検索は端末の現在地を取得しません。検索には通信が必要です。")
                            .font(.caption).foregroundStyle(.secondary)
                    }.disabled(places.isSearching || places.query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    if places.isSearching {
                        HStack {
                            ProgressView()
                            Text("探しています…")
                            Spacer()
                            Button("停止") { places.stop() }
                        }
                    }
                    if let notice = places.notice {
                        Text(notice).font(.callout).foregroundStyle(.secondary)
                    }
                    if !places.places.isEmpty {
                        Map(initialPosition: .region(places.region)) {
                            ForEach(places.places) { place in
                                Marker(place.item.name ?? "候補", coordinate: place.item.placemark.coordinate)
                            }
                        }
                        .id(places.searchID)
                        .frame(height: 220)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        Text("候補を選んで、徒歩ナビへ")
                            .font(.headline)
                        Text("距離は直線距離です。営業時間や経路はマップで確認してください。")
                            .font(.caption).foregroundStyle(.secondary)
                        ForEach(places.places) { place in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(place.item.name ?? "名前のない場所").font(.headline)
                                if let address = place.item.placemark.title {
                                    Text(address).font(.caption).foregroundStyle(.secondary)
                                }
                                if let distance = place.distance {
                                    Text(distance < 1000
                                         ? "直線 約\(Int(distance))m"
                                         : String(format: "直線 約%.1fkm", distance / 1000))
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                HStack {
                                    Button { navigation.prepare(to: place.item) } label: {
                                        Label("ゆきAIで徒歩ナビ", systemImage: "figure.walk")
                                    }.buttonStyle(.borderedProminent)
                                        .disabled(navigation.isNavigating || navigation.isPreparing)
                                    Button { places.navigate(to: place, walking: false) } label: {
                                        Label("車で案内", systemImage: "car")
                                    }.buttonStyle(.bordered)
                                }
                                if let url = TravelLinks.google(destination: "\(place.item.placemark.coordinate.latitude),\(place.item.placemark.coordinate.longitude)") {
                                    Link("Googleマップで徒歩案内", destination: url)
                                }
                                Button("乗換案内の目的地にする") { places.transit.destination = place.item.name ?? "" }
                                if places.query.contains("駅") {
                                    Button("この駅を出発駅にする") { places.transit.origin = place.item.name ?? "" }
                                }
                            }
                            .padding().frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 18))
                        }
                    }
                    Text("徒歩ナビを開始した間だけ、画面ロック中も現在地を使います。終了すると位置更新を停止し、移動履歴は保存しません。経路検索には通信が必要です。Googleマップを開くと選んだ目的地をGoogleへ渡します。")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding()
            }.navigationTitle("おでかけ")
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: navigation.isPreparing) { _, value in
                    if value { withAnimation { proxy.scrollTo("walking-navigation", anchor: .top) } }
                }
            }
        }
    }
}

struct PreferencesView: View {
    @EnvironmentObject private var store: CompanionStore
    @State private var confirmClear = false

    var body: some View {
        NavigationStack {
            Form {
                Section("ゆきAIの話し方") {
                    TextField("AIの名前", text: $store.preferences.name)
                        .onChange(of: store.preferences.name) { _, name in
                            if name.count > 30 { store.preferences.name = String(name.prefix(30)) }
                        }
                    Picker("性格", selection: $store.preferences.personality) {
                        ForEach(Persona.all) { persona in Text(persona.name).tag(persona.id) }
                        Text("自分の話し方").tag("custom")
                    }
                    if store.preferences.personality == "custom" {
                        TextEditor(text: $store.preferences.customPersonality).frame(minHeight: 100)
                            .onChange(of: store.preferences.customPersonality) { _, value in
                                if value.count > 400 { store.preferences.customPersonality = String(value.prefix(400)) }
                            }
                        Text("\(store.preferences.customPersonality.count) / 400文字").font(.caption)
                    }
                    Toggle("絵文字", isOn: $store.preferences.emoji)
                    Toggle("短いリアクション中心", isOn: $store.preferences.shortReplies)
                    Text("会話で「一人称は僕、甘えん坊で話して」と伝えても設定できます。確実に設定カードを出すには「/性格 」に続けて入力してください。Appleの安全判定は、話し方を変えても適用されます。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                VoicePreferencesSection()
                VisualModelSection()
                Section("あなたについて（全チャット共通）") {
                    Picker("あなたの性別", selection: $store.preferences.userGender) {
                        Text("男性").tag("male")
                        Text("女性").tag("female")
                        Text("指定しない").tag("unspecified")
                    }
                    Text("本人が伝えた情報として会話に使います。写真から性別を推測しません。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section(header: Text("覚えておいてほしいこと"),
                        footer: Text("好みや呼び名を自分で編集できます。すべてのチャットで共有するメモです。会話から自動収集はしません。")) {
                    TextEditor(text: $store.memoryNote).frame(minHeight: 110)
                        .onChange(of: store.memoryNote) { _, value in
                            if value.count > 400 { store.memoryNote = String(value.prefix(400)) }
                        }
                    Text("\(store.memoryNote.count) / 400文字").font(.caption).foregroundStyle(.secondary)
                }
                Section("端末内AI") {
                    Text(store.modelStatus)
                    Button("準備状況を再確認") { store.refreshAvailability() }
                    Button("AI動作テスト") { store.testAI() }
                        .disabled(store.isReplying)
                    if store.isReplying {
                        Button("生成・テストを停止") { store.stop() }
                    }
                    Text("短い挨拶を生成します。性格・メモ・履歴は使わず、会話の記録も変更しません。")
                        .font(.caption).foregroundStyle(.secondary)
                    if let result = store.aiTestResult {
                        Text(result).font(.footnote).textSelection(.enabled)
                    }
                    Button("写真への感想を試す") { store.testPhotoReaction() }
                        .disabled(store.isReplying)
                        .accessibilityIdentifier("test-photo-reaction")
                    Text("選んだ性格で、サンプルの写真説明への返事を作ります。実際の写真・会話・メモは使わず、結果は保存しません。")
                        .font(.caption).foregroundStyle(.secondary)
                    if let result = store.photoReactionTestResult {
                        Text(result).font(.footnote).textSelection(.enabled)
                    }
                    if let details = store.lastAIErrorDetails {
                        DisclosureGroup("技術情報（端末内のみ）") {
                            Text(details).font(.caption.monospaced()).textSelection(.enabled)
                        }
                    }
                    Text("iOS 26以降と、Apple Intelligenceが利用可能な設定・端末内モデルが必要です。Windows版のQwenとは異なるモデルです。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("直前の返信時間") {
                    if let timing = store.lastReplyTiming {
                        if let first = timing.firstTextSeconds {
                            LabeledContent("最初の文字まで", value: String(format: "%.2f秒", first))
                        } else {
                            Text("文字を生成する前に終了しました")
                        }
                        LabeledContent(timing.completed ? "返答完了まで" : "中断まで",
                                       value: String(format: "%.2f秒", timing.totalSeconds))
                        LabeledContent("返答の長さ", value: "\(timing.characterCount)文字")
                    } else {
                        Text("会話すると、このiPhoneでの実測時間を表示します。")
                    }
                    Text("読み上げの再生時間や場所検索は含みません。初回、質問の長さ、端末の状態で変わります。計測値は外部送信しません。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("保存とプライバシー") {
                    Text("会話とメモはこのiPhoneのアプリ内に保存します。アプリ側のクラウド同期はありません。保存先は端末バックアップの対象外です。アプリを削除するとデータも失われます。")
                        .font(.footnote)
                    if let notice = store.storageNotice { Text(notice).foregroundStyle(.orange) }
                    Button("会話とメモをすべて削除", role: .destructive) { confirmClear = true }
                        .disabled(store.isReplying)
                }
                Section {
                    Text("YK AI iPhone · \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "不明") 試作").font(.footnote)
                    Text("徒歩経路はAppleの地図、電車検索はYahoo!乗換案内を使います。APIキーは不要です。徒歩ナビ中の位置更新と登録した電車の通知に対応しています。常時見守り・Web検索・画像生成は未実装です。")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("設定")
            .confirmationDialog("会話・編集前の記録・添付画像・メモをすべて削除しますか？", isPresented: $confirmClear,
                                titleVisibility: .visible) {
                Button("すべて削除", role: .destructive) { store.clearHistoryAndMemory() }
                Button("キャンセル", role: .cancel) {}
            }
        }
    }
}
