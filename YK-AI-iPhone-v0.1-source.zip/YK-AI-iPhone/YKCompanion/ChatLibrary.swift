import Foundation

struct SavedChatSession: Identifiable, Codable, Equatable {
    var id = UUID()
    var createdAt = Date()
    var updatedAt = Date()
    var customTitle: String? = nil
    var messages: [Message] = []
    var contextAfterMessageID: UUID? = nil
    var archives: [ConversationArchive] = []
    var draft = ""

    var title: String {
        if let customTitle, !customTitle.isEmpty { return customTitle }
        let first = messages.first { $0.role == "user" }?.text ?? "新しいチャット"
        return String(first.replacingOccurrences(of: "\n", with: " ").prefix(32))
    }
    var allMessages: [Message] { messages + archives.flatMap(\.messages) }
}

// The selected session is the only source of conversation context. Settings and
// the explicit profile/memo are shared; other chats are never fed to the model.
struct ChatLibrary: Codable, Equatable {
    var chats: [SavedChatSession]
    var selectedID: UUID

    init() {
        let first = SavedChatSession()
        chats = [first]
        selectedID = first.id
    }
    init(migrating saved: SavedState) throws {
        guard (1...2).contains(saved.version) else { throw CocoaError(.coderReadCorrupt) }
        if let library = saved.chatLibrary {
            guard !library.chats.isEmpty,
                  Set(library.chats.map(\.id)).count == library.chats.count,
                  library.chats.contains(where: { $0.id == library.selectedID }) else {
                throw CocoaError(.coderReadCorrupt)
            }
            self = library
        } else {
            guard saved.version == 1 else { throw CocoaError(.coderReadCorrupt) }
            let first = SavedChatSession(customTitle: saved.messages.isEmpty ? nil : "これまでの会話",
                messages: saved.messages, contextAfterMessageID: saved.contextAfterMessageID,
                archives: saved.conversationArchives ?? [])
            chats = [first]
            selectedID = first.id
        }
    }
    var selected: SavedChatSession { chats.first { $0.id == selectedID }! }
    var sorted: [SavedChatSession] { chats.sorted { $0.updatedAt > $1.updatedAt } }

    mutating func update(messages: [Message], boundary: UUID?, archives: [ConversationArchive], draft: String) {
        guard let index = chats.firstIndex(where: { $0.id == selectedID }) else { return }
        let clean = messages.filter { !$0.text.isEmpty }
        if chats[index].messages != clean { chats[index].updatedAt = Date() }
        chats[index].messages = clean
        chats[index].contextAfterMessageID = boundary
        chats[index].archives = archives
        chats[index].draft = draft
    }
    mutating func create() {
        let chat = SavedChatSession()
        chats.append(chat)
        selectedID = chat.id
    }
    @discardableResult mutating func select(_ id: UUID) -> Bool {
        guard chats.contains(where: { $0.id == id }) else { return false }
        selectedID = id
        return true
    }
    mutating func rename(_ id: UUID, to raw: String) {
        guard let index = chats.firstIndex(where: { $0.id == id }) else { return }
        let title = String(raw.trimmingCharacters(in: .whitespacesAndNewlines).prefix(60))
        chats[index].customTitle = title.isEmpty ? nil : title
    }
    // Return only images no remaining chat or edit archive still references.
    mutating func remove(_ id: UUID) -> Set<UUID> {
        guard let chat = chats.first(where: { $0.id == id }) else { return [] }
        let candidates = Set(chat.allMessages.compactMap { $0.attachment?.id })
        chats.removeAll { $0.id == id }
        if chats.isEmpty { create() }
        if selectedID == id { selectedID = sorted[0].id }
        let retained = Set(chats.flatMap(\.allMessages).compactMap { $0.attachment?.id })
        return candidates.subtracting(retained)
    }
}
