import MapKit
import SwiftUI

// Each proposal owns its search state. Switching chat cancels its pending search;
// no GPS or network lookup happens just because the card appears.
struct ChatTravelView: View {
    @EnvironmentObject private var companion: CompanionStore
    @EnvironmentObject private var navigation: NavigationStore
    @StateObject private var search = PlacesStore()
    @State private var initialized = false
    @FocusState private var editing: Bool
    let messageID: UUID
    let offer: TravelOffer

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("ここで案内する？", systemImage: "map").font(.headline)
                Spacer()
                Button("今はいい") { companion.chooseTravel(.dismissed, messageID: messageID) }
                    .font(.caption).accessibilityIdentifier("dismiss-travel-offer")
            }
            HStack {
                Button { choose(.walking) } label: { Label("徒歩", systemImage: "figure.walk") }
                    .buttonStyle(.bordered).accessibilityIdentifier("chat-travel-walking")
                Button { choose(.transit) } label: { Label("電車", systemImage: "tram.fill") }
                    .buttonStyle(.bordered).accessibilityIdentifier("chat-travel-transit")
            }
            if offer.mode == .walking {
                TextField("行き先", text: $search.query)
                    .focused($editing).textFieldStyle(.roundedBorder)
                    .submitLabel(.search).onSubmit { find(nearby: offer.nearby) }
                    .accessibilityIdentifier("chat-walking-destination")
                    .onChange(of: search.query) { _, text in search.query = String(text.prefix(100)) }
                Button(offer.nearby ? "現在地の周辺で候補を探す" : "この行き先を探す") { find(nearby: offer.nearby) }
                    .buttonStyle(.borderedProminent).disabled(search.isSearching || search.query.isEmpty)
                    .accessibilityIdentifier("chat-find-destination")
                Text(offer.nearby ? "押すと現在地を使って候補を探します。" : "候補を選ぶと、現在地からの徒歩ルートをこの会話に出します。")
                    .font(.caption).foregroundStyle(.secondary)
            } else if offer.mode == .transit {
                TransitSearchView().environmentObject(search)
            }
            if offer.mode != .choice {
                if search.isSearching {
                    HStack { ProgressView("探しているよ…"); Button("停止") { search.stop() } }
                }
                if let notice = search.notice { Text(notice).font(.callout).foregroundStyle(.secondary) }
                if !search.places.isEmpty {
                    Map(initialPosition: .region(search.region)) {
                        ForEach(search.places) { place in
                            Marker(place.item.name ?? "候補", coordinate: place.item.placemark.coordinate)
                        }
                    }.id(search.searchID).frame(height: 180).clipShape(RoundedRectangle(cornerRadius: 14))
                    Text("どの場所にする？").font(.headline)
                    ForEach(search.places) { place in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(place.item.name ?? "場所の候補").font(.headline)
                            Text(place.item.placemark.title ?? "").font(.caption).foregroundStyle(.secondary)
                            if offer.mode == .transit {
                                Button("この駅から乗る") { search.transit.origin = place.item.name ?? "" }
                            } else {
                                Button("ここへの徒歩ルートを見る") { editing = false; navigation.prepare(to: place.item) }
                                    .disabled(navigation.isNavigating || navigation.isPreparing)
                            }
                        }.padding(.vertical, 4)
                    }
                }
            }
        }
        .padding().frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.teal.opacity(0.06), in: RoundedRectangle(cornerRadius: 18))
        .onAppear {
            if !initialized {
                search.query = offer.request.destination; search.transit = offer.request
                initialized = true
            }
        }
        .onChange(of: offer.mode) { _, _ in
            search.stop(); search.places = []; search.notice = nil
            search.query = offer.request.destination
        }
        .onChange(of: search.transit) { _, request in
            companion.updateTravelRequest(request, messageID: messageID)
        }
        .onDisappear { search.stop() }
    }
    private func choose(_ mode: TravelMode) {
        editing = false
        search.stop()
        companion.chooseTravel(mode, messageID: messageID)
    }
    private func find(nearby: Bool) {
        editing = false
        guard !search.query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        search.search(nearby: nearby)
    }
}
