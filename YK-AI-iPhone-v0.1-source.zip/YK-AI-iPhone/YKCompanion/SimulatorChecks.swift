#if targetEnvironment(simulator)
import Foundation
import UIKit

enum SimulatorChecks {
    @MainActor static func runIfRequested() async {
        guard ProcessInfo.processInfo.environment["YK_VOICE_SMOKE_TEST"] == "1" else { return }
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        do {
            let tokenizer = try await LocalPhotoTokenizerLoader().load(from: directory.appendingPathComponent("TokenizerFixture"))
            let sample = "こんにちは。写真を見せるね。"
            let tokens = tokenizer.encode(text: sample, addSpecialTokens: false)
            guard tokenizer.decode(tokenIds: tokens, skipSpecialTokens: true) == sample,
                  try !tokenizer.applyChatTemplate(messages: [["role": "user", "content": sample]],
                      tools: nil, additionalContext: nil).isEmpty else {
                throw VoicevoxEngine.Failure(message: "Local photo tokenizer regression")
            }
            let engine = VoicevoxEngine()
            for style in VoiceCatalog.shared.characters.flatMap({ $0.styles.map(\.id) }) {
                let data = try await engine.synthesize("こんにちは。僕はゆきAIだよ。", style: style, speed: 1.1, pitch: 0.02)
                try data.write(to: directory.appendingPathComponent("voice-\(style).wav"))
            }
            // Return from the last group to zundamon before a photo-style unload.
            let switched = try await engine.synthesize("切り替えても話せるのだ。", style: 3, speed: 1.0, pitch: 0)
            try switched.write(to: directory.appendingPathComponent("voice-switched.wav"))
            await engine.releaseResources()
            // A photo temporarily unloads VOICEVOX. The next reply must be able
            // to load it again and produce valid, non-silent audio.
            let reloaded = try await engine.synthesize("写真のあとも話せるよ。", style: 12, speed: 1.1, pitch: 0.02)
            try reloaded.write(to: directory.appendingPathComponent("voice-reloaded.wav"))
            await engine.releaseResources()
            let renderer = UIGraphicsImageRenderer(size: CGSize(width: 1000, height: 200))
            let image = renderer.image { context in
                UIColor.white.setFill()
                context.fill(CGRect(x: 0, y: 0, width: 1000, height: 200))
                ("Tokyo Station" as NSString).draw(at: CGPoint(x: 30, y: 50), withAttributes: [
                    .font: UIFont.systemFont(ofSize: 65), .foregroundColor: UIColor.black])
            }
            let analysis = try await ImageAnalyzer().analyze(image.pngData()!)
            guard analysis.attachment.recognizedText.contains("Tokyo"),
                  analysis.latitude == nil, analysis.longitude == nil else {
                throw VoicevoxEngine.Failure(message: "OCR fixture was not recognized")
            }
            try ImageFiles.save(analysis)
            guard FileManager.default.fileExists(atPath: ImageFiles.url(analysis.attachment.id).path) else {
                throw VoicevoxEngine.Failure(message: "Image storage failed")
            }
            ImageFiles.remove(analysis.attachment.id)
            try Data("Local photo tokenizer, VOICEVOX group switch/unload/reload, 25 styles and OCR/image storage passed".utf8)
                .write(to: directory.appendingPathComponent("smoke-success.txt"))
        } catch {
            try? Data(String(reflecting: error).utf8).write(to: directory.appendingPathComponent("smoke-error.txt"))
        }
    }
}
#endif
