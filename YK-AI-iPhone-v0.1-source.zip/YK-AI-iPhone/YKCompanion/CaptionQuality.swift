import Foundation

// Detect broken generation, not factual correctness. A fluent caption can still
// misidentify an object. Never "repair" a loop by inventing or clipping facts.
enum CaptionQuality {
    enum Issue: Error, Equatable { case empty, repetition, incomplete, tooLong }

    static func issue(in raw: String, completed: Bool = true) -> Issue? {
        let text = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return .empty }
        guard text.count <= 900 else { return .tooLong }
        let normalized = Array(text.lowercased().filter { $0.isLetter || $0.isNumber })
        // Three adjacent copies of a short phrase (including Japanese with no spaces).
        if normalized.count >= 12 {
            for width in 1...min(40, normalized.count / 3) {
                let copies = max(3, (12 + width - 1) / width)
                let length = width * copies
                guard normalized.count >= length else { continue }
                for start in 0...(normalized.count - length) {
                    let pattern = normalized[start..<(start + width)]
                    if (1..<copies).allSatisfy({ copy in
                        pattern.elementsEqual(normalized[(start + copy * width)..<(start + (copy + 1) * width)])
                    }) { return .repetition }
                }
            }
            // Repeated complete sentences, even when the final one is unfinished.
            var sentences = Set<String>()
            for sentence in text.components(separatedBy: CharacterSet(charactersIn: "。.!！?？\n")) {
                let key = sentence.lowercased().filter { $0.isLetter || $0.isNumber }
                if key.count >= 12 && !sentences.insert(key).inserted { return .repetition }
            }
        }
        if !completed || text.last.map({ "、,：:".contains($0) }) == true { return .incomplete }
        return nil
    }
}
