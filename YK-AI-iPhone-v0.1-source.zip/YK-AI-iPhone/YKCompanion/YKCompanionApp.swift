import SwiftUI

@main
struct YKCompanionApp: App {
    @StateObject private var companion = CompanionStore()
    @StateObject private var places = PlacesStore()
    @StateObject private var microphone = MicrophoneService()
    @StateObject private var attachments = AttachmentStore()
    @StateObject private var navigation = NavigationStore()
    @StateObject private var reminders = TrainReminderStore()
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            CompanionView()
                .environmentObject(companion)
                .environmentObject(places)
                .environmentObject(companion.audio)
                .environmentObject(microphone)
                .environmentObject(attachments)
                .environmentObject(navigation)
                .environmentObject(reminders)
                .tint(.teal)
                .task {
                    navigation.attachAudio(companion.audio)
                    #if targetEnvironment(simulator)
                    await SimulatorChecks.runIfRequested()
                    #endif
                }
                .onChange(of: scenePhase) { _, phase in
                    if phase == .active {
                        companion.refreshAvailability()
                        Task { await reminders.refresh() }
                    }
                    if phase == .background {
                        VisualModelStore.shared.cancel()
                        microphone.cancel()
                        companion.enterBackground(preserveNavigationAudio: navigation.isNavigating && navigation.voiceEnabled)
                        places.stop()
                    }
                }
        }
    }
}
