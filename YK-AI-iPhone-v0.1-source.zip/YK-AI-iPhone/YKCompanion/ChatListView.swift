import SwiftUI

struct ChatListView: View {
    @EnvironmentObject private var store: CompanionStore
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var renaming: SavedChatSession?
    @State private var showingRename = false
    @State private var title = ""
    @State private var deleting: SavedChatSession?

    private var chats: [SavedChatSession] {
        store.library.sorted.filter { query.isEmpty || $0.title.localizedCaseInsensitiveContains(query) }
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button {
                        if store.newChat() { dismiss() }
                    } label: { Label("新しいチャット", systemImage: "square.and.pencil") }
                        .accessibilityIdentifier("list-new-chat")
                }
                Section("チャット履歴") {
                    ForEach(chats) { chat in
                        HStack(spacing: 12) {
                            Button {
                                if store.selectChat(chat.id) { dismiss() }
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 5) {
                                        Text(chat.title).lineLimit(2).foregroundStyle(.primary)
                                        Text(chat.updatedAt, style: .date)
                                            .font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if chat.id == store.activeChatID {
                                        Image(systemName: "checkmark").foregroundStyle(.teal)
                                    }
                                }.contentShape(Rectangle())
                            }.buttonStyle(.plain)
                                .accessibilityIdentifier("select-chat-\(chat.id)")
                            Menu {
                                Button("名前を変更", systemImage: "pencil") {
                                    title = chat.title; renaming = chat; showingRename = true
                                }
                                Button("削除", systemImage: "trash", role: .destructive) { deleting = chat }
                            } label: {
                                Image(systemName: "ellipsis").frame(width: 40, height: 44)
                            }.accessibilityLabel("\(chat.title)の操作")
                                .accessibilityIdentifier("chat-menu-\(chat.id)")
                        }
                    }
                    if chats.isEmpty { Text("一致するチャットはありません").foregroundStyle(.secondary) }
                }
                Section {
                    Text("チャットごとに会話・写真・編集履歴・入力途中の文章を保存します。性格と「あなたについて」、共通メモはすべてのチャットで使います。")
                        .font(.caption).foregroundStyle(.secondary)
                }
                if let notice = store.storageNotice { Text(notice).foregroundStyle(.orange) }
            }
            .disabled(store.isReplying)
            .searchable(text: $query, prompt: "チャット名を検索")
            .navigationTitle("チャット")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("閉じる") { dismiss() } } }
            // Alert dismissal must not clear the target before the Save action runs.
            .alert("チャット名を変更", isPresented: $showingRename) {
                TextField("チャット名", text: $title)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                    .accessibilityIdentifier("rename-chat-input")
                Button("保存") {
                    if let chat = renaming { store.renameChat(chat.id, to: title) }
                    renaming = nil
                }
                Button("キャンセル", role: .cancel) { renaming = nil }
            }
            .alert("このチャットを削除しますか？", isPresented: Binding(
                get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
                Button("削除", role: .destructive) {
                    if let chat = deleting { store.deleteChat(chat.id) }
                    deleting = nil
                }
                Button("キャンセル", role: .cancel) { deleting = nil }
            } message: {
                Text("このチャットと編集前の履歴を端末から削除します。他のチャットと共通設定は残ります。")
            }
        }
    }
}
