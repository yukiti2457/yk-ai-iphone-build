import Foundation

struct VoiceStyle: Codable, Identifiable {
    let id: Int
    let name: String
    let model: String
}

struct VoiceCharacter: Codable, Identifiable {
    let id: String
    let name: String
    let termsURL: URL
    let styles: [VoiceStyle]
    var credit: String { "VOICEVOX:\(name)" }
}

struct VoiceModelAsset: Codable {
    let name: String
    let sha256: String
}

struct VoiceCatalog: Codable {
    let version: String
    let models: [VoiceModelAsset]
    let characters: [VoiceCharacter]

    static let shared: VoiceCatalog = {
        guard let url = Bundle.main.url(forResource: "VoiceCatalog", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let value = try? JSONDecoder().decode(VoiceCatalog.self, from: data) else {
            // The engine reports unavailable metadata; never substitute a different voice.
            return VoiceCatalog(version: "", models: [], characters: [])
        }
        return value
    }()

    func character(for style: Int) -> VoiceCharacter? {
        characters.first { $0.styles.contains { $0.id == style } }
    }

    func style(_ id: Int) -> VoiceStyle? {
        character(for: id)?.styles.first { $0.id == id }
    }
}
