import SwiftUI

struct PersonalityProposalView: View {
    @EnvironmentObject private var store: CompanionStore
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("この話し方で覚える？", systemImage: "slider.horizontal.3").font(.headline)
            TextEditor(text: Binding(get: { store.pendingPersonality ?? "" },
                                    set: { store.pendingPersonality = String($0.prefix(400)) }))
                .frame(minHeight: 95)
            Button("この話し方を使う") { store.applyPersonality(store.pendingPersonality ?? "") }
                .buttonStyle(.borderedProminent)
                .disabled((store.pendingPersonality ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            HStack {
                Button("会話として送る") { store.send(store.pendingPersonality ?? "", detectSettings: false) }
                Spacer()
                Button("閉じる") { store.pendingPersonality = nil }
            }.font(.caption)
            Text("次の返答から使い、iPhone内に保存します。いつでも設定から編集できます。")
                .font(.caption).foregroundStyle(.secondary)
        }.padding().background(Color.teal.opacity(0.08), in: RoundedRectangle(cornerRadius: 16))
    }
}

struct VoicePreferencesSection: View {
    @EnvironmentObject private var store: CompanionStore
    @EnvironmentObject private var audio: AudioService
    @EnvironmentObject private var microphone: MicrophoneService
    private var selectedCharacter: VoiceCharacter? {
        VoiceCatalog.shared.character(for: store.preferences.voiceStyle)
    }
    private var characterSelection: Binding<String> {
        Binding(get: { selectedCharacter?.id ?? "" }, set: { id in
            guard let character = VoiceCatalog.shared.characters.first(where: { $0.id == id }),
                  let style = character.styles.first else { return }
            audio.stop()
            store.preferences.voiceStyle = style.id
        })
    }
    var body: some View {
        Section("声・マイク") {
            Picker("読み上げる声", selection: $store.preferences.voiceEngine) {
                Text("iPhone標準音声").tag("system")
                Text("VOICEVOX（キャラクター音声）").tag("voicevox")
            }.pickerStyle(.menu).accessibilityIdentifier("voice-engine")
            if store.preferences.voiceEngine == "voicevox" {
                Picker("音声キャラクター", selection: characterSelection) {
                    ForEach(VoiceCatalog.shared.characters) { character in
                        Text(character.name).tag(character.id)
                    }
                }.pickerStyle(.menu).accessibilityIdentifier("voice-character")
                    .accessibilityValue(selectedCharacter?.name ?? "未選択")
                if let character = selectedCharacter {
                    Picker("声の表情", selection: $store.preferences.voiceStyle) {
                        ForEach(character.styles) { style in Text(style.name).tag(style.id) }
                    }.pickerStyle(.menu).accessibilityIdentifier("voice-style")
                        .accessibilityValue(VoiceCatalog.shared.style(store.preferences.voiceStyle)?.name ?? "未選択")
                    Text("\(character.credit) · PCなしで端末内合成。初回や声の切り替え直後は準備に時間がかかります。")
                        .font(.caption).foregroundStyle(.secondary)
                } else {
                    Text("音声キャラクターを選び直してください。候補がない場合はアプリの更新が必要です。")
                        .font(.caption).foregroundStyle(.orange)
                }
            }
            LabeledContent("話す速さ", value: String(format: "%.2f倍", store.preferences.voiceSpeed))
            Slider(value: $store.preferences.voiceSpeed, in: 0.7...1.5, step: 0.05)
            LabeledContent("声の高さ", value: String(format: "%+.2f", store.preferences.voicePitch))
            Slider(value: $store.preferences.voicePitch, in: -0.1...0.1, step: 0.01)
            Toggle("返信を自動で読み上げる", isOn: $store.preferences.readAloud)
            Toggle("音声会話（マイク確定後に送信・返答を読む）", isOn: $store.preferences.voiceConversation)
            Toggle("ロック中も読み上げを続ける", isOn: $store.preferences.backgroundAudio)
            Button("この声で試す") {
                microphone.cancel()
                store.speak("こんにちは、僕はゆきAIだよ。ねえ、今日は何を話そっか？")
            }.disabled(store.isReplying)
            if audio.isBusy { Button("読み上げを停止") { audio.stop() } }
            if !audio.status.isEmpty { Text(audio.status).font(.caption) }
            Text("マイクは会話画面で押したときだけ動きます。端末内で日本語を文字にし、音声は保存しません。画面ロック時はマイクとAIの返答生成を止め、読み上げを続けます。通話・VCアプリへの音声送信には未対応です。")
                .font(.caption).foregroundStyle(.secondary)
            NavigationLink("VOICEVOX・音声ライブラリのクレジット") { VoiceCreditsView() }
        }
    }
}

struct VoiceCreditsView: View {
    var body: some View {
        List {
            ForEach(VoiceCatalog.shared.characters) { character in
                Section(character.credit) {
                    Link("\(character.name)の音声利用規約", destination: character.termsURL)
                }
            }
            Text("声の調整は既存音声の速さ・高さの変更です。独自に学習した声や、本人の声の複製ではありません。")
            Text("生成した音声を公開する場合は、使用した声のクレジットを記載し、各音声ライブラリの利用規約に従ってください。")
            ForEach(["VOICEVOX-Model-Terms", "VOICEVOX-Core-LICENSE", "ONNXRuntime-LICENSE", "ONNXRuntime-ThirdPartyNotices", "OpenJTalk-Dictionary-COPYING"], id: \.self) { name in
                NavigationLink(name) {
                    ScrollView {
                        Text(license(name)).font(.caption).textSelection(.enabled).padding()
                    }.navigationTitle(name)
                }
            }
        }.navigationTitle("音声のクレジット")
    }

    private func license(_ name: String) -> String {
        guard let url = Bundle.main.resourceURL?.appendingPathComponent("VoicevoxAssets/Licenses/\(name).txt"),
              let text = try? String(contentsOf: url, encoding: .utf8) else { return "ライセンス文書を読み込めませんでした。" }
        return text
    }
}
