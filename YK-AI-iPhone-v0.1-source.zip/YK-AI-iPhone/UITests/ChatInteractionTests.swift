import XCTest

final class ChatInteractionTests: XCTestCase {
    @MainActor
    func testChatOffersGuidanceWithoutLeavingConversation() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchEnvironment["YK_UI_TEST"] = "1"
        app.launchEnvironment["YK_UI_TEST_TRAVEL"] = "1"
        app.launchArguments = ["-AppleLanguages", "(ja)", "-AppleLocale", "ja_JP"]
        app.launch()
        let walking = app.buttons["chat-travel-walking"]
        let transit = app.buttons["chat-travel-transit"]
        let walkingExists = walking.waitForExistence(timeout: 15)
        if !walkingExists { print("TRAVEL_UI_DIAGNOSTIC: \(app.debugDescription)") }
        XCTAssertTrue(walkingExists)
        XCTAssertTrue(transit.exists && app.tabBars.buttons["会話"].isSelected)
        XCTAssertFalse(app.alerts.firstMatch.exists, "A proposal must not request location")
        let proposal = XCTAttachment(screenshot: app.screenshot())
        proposal.name = "Short chat reaction and inline guidance proposal"
        proposal.lifetime = .keepAlways
        add(proposal)
        walking.tap()
        let field = app.textFields["chat-walking-destination"]
        XCTAssertTrue(field.waitForExistence(timeout: 5))
        XCTAssertEqual(field.value as? String, "秋葉原")
        XCTAssertTrue(app.buttons["chat-find-destination"].exists)
        XCTAssertTrue(app.tabBars.buttons["会話"].isSelected)
        XCTAssertFalse(app.alerts.firstMatch.exists)
        // Only open the form; no GPS/network or fabricated routes in this test.
        for _ in 0..<4 { if transit.isHittable { break }; app.scrollViews["chat-scroll"].swipeDown() }
        transit.tap()
        let origin = app.textFields["transit-origin"]
        for _ in 0..<5 {
            if origin.isHittable { break }
            let scroll = app.scrollViews["chat-scroll"]
            if origin.exists && origin.frame.midY < scroll.frame.midY { scroll.swipeDown() }
            else { scroll.swipeUp() }
        }
        XCTAssertTrue(origin.isHittable)
        XCTAssertEqual(app.textFields["transit-destination"].value as? String, "秋葉原")
        origin.tap(); origin.typeText("Shinjuku\n")
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "open-yahoo-transit").firstMatch.exists)
        XCTAssertTrue(app.tabBars.buttons["会話"].isSelected)
        app.buttons["new-chat"].tap()
        XCTAssertTrue(app.staticTexts["何から話そう？"].waitForExistence(timeout: 5))
        XCTAssertFalse(walking.exists)
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.exists)
        app.buttons["open-chats"].tap()
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'select-chat-'"))
        XCTAssertEqual(rows.count, 2)
        rows.element(boundBy: 1).tap()
        XCTAssertTrue(app.textFields["transit-destination"].waitForExistence(timeout: 5))
        app.terminate()
        app.launchEnvironment.removeValue(forKey: "YK_UI_TEST_TRAVEL")
        app.launch()
        XCTAssertTrue(app.textFields["transit-destination"].waitForExistence(timeout: 10))
        XCTAssertEqual(app.textFields["transit-destination"].value as? String, "秋葉原")
    }

    @MainActor
    func testTransitSearchAndReminderRequireConfirmedData() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchEnvironment["YK_UI_TEST"] = "1"
        app.launchArguments = ["-AppleLanguages", "(ja)", "-AppleLocale", "ja_JP"]
        app.launch()
        XCTAssertTrue(app.tabBars.buttons["おでかけ"].waitForExistence(timeout: 15))
        app.tabBars.buttons["おでかけ"].tap()
        XCTAssertFalse(app.links["open-yahoo-transit"].exists)
        let origin = app.textFields["transit-origin"]
        XCTAssertTrue(origin.waitForExistence(timeout: 5))
        origin.tap(); origin.typeText("Shinjuku\n")
        let destination = app.textFields["transit-destination"]
        destination.tap(); destination.typeText("Tokyo\n")
        app.buttons["transit-time-mode"].tap()
        app.buttons["到着時刻"].tap()
        XCTAssertTrue(app.datePickers.firstMatch.exists)
        let yahoo = app.descendants(matching: .any).matching(identifier: "open-yahoo-transit").firstMatch
        XCTAssertTrue(yahoo.exists && yahoo.isEnabled)
        let shot = XCTAttachment(screenshot: app.screenshot())
        shot.name = "Yahoo transit arrival search form"
        shot.lifetime = .keepAlways
        add(shot)
        let reminder = app.buttons["train-reminder"]
        for _ in 0..<4 { if reminder.isHittable { break }; app.swipeUp() }
        XCTAssertTrue(reminder.isHittable)
        reminder.tap()
        XCTAssertTrue(app.navigationBars["発車前のお知らせ"].waitForExistence(timeout: 5))
        let schedule = app.buttons["schedule-train-reminder"]
        // Disabled controls have no activation point on iOS 26. Check their
        // accessibility state, not hittability, after revealing the section.
        app.swipeUp()
        XCTAssertTrue(schedule.waitForExistence(timeout: 5))
        XCTAssertFalse(schedule.isEnabled, "No fabricated train plan or notification without confirmation")
        app.buttons["閉じる"].tap()
        // Never open a remote route, request GPS, read clipboard, or grant notifications in this test.
    }

    @MainActor
    func testSeparateChatsPersistAndRename() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchEnvironment["YK_UI_TEST"] = "1"
        app.launchEnvironment["YK_UI_TEST_SEED"] = "1"
        app.launchArguments = ["-AppleLanguages", "(ja)", "-AppleLocale", "ja_JP"]
        app.launch()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 15))
        input.tap(); input.typeText("first draft")
        app.buttons["chat-title"].tap()
        app.buttons["new-chat"].tap()
        XCTAssertTrue(app.staticTexts["何から話そう？"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["近くの公園を探して"].exists)
        XCTAssertNotEqual(input.value as? String, "first draft")
        // Both conversations work through real offline routing, no mocked AI.
        app.buttons["近くのカフェを探して"].tap()
        input.tap(); input.typeText("second draft")
        app.buttons["chat-title"].tap()
        app.buttons["open-chats"].tap()
        let rows = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'select-chat-'"))
        XCTAssertTrue(rows.firstMatch.waitForExistence(timeout: 5))
        XCTAssertEqual(rows.count, 2)
        let newerID = rows.element(boundBy: 0).identifier
        let olderID = rows.element(boundBy: 1).identifier
        let menuID = newerID.replacingOccurrences(of: "select-chat-", with: "chat-menu-")
        app.buttons[menuID].tap()
        app.buttons["名前を変更"].tap()
        let title = app.alerts.textFields.firstMatch
        XCTAssertTrue(title.waitForExistence(timeout: 5))
        title.tap()
        let previous = title.value as? String ?? ""
        title.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: previous.count) + "Cafe")
        XCTAssertEqual(title.value as? String, "Cafe", "Rename field must contain exactly the requested title")
        app.alerts.buttons["保存"].tap()
        let renamed = app.staticTexts["Cafe"].waitForExistence(timeout: 5)
        if !renamed { print("RENAME_UI_DIAGNOSTIC: \(app.debugDescription)") }
        XCTAssertTrue(renamed)
        let shot = XCTAttachment(screenshot: app.screenshot())
        shot.name = "Independent chats and saved titles"
        shot.lifetime = .keepAlways
        add(shot)
        app.buttons[olderID].tap()
        XCTAssertTrue(app.staticTexts["近くの公園を探して"].waitForExistence(timeout: 5))
        XCTAssertEqual(input.value as? String, "first draft")
        app.buttons["open-chats"].tap()
        app.buttons[newerID].tap()
        XCTAssertTrue(app.buttons["chat-title"].waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["近くの公園を探して"].exists)
        XCTAssertEqual(input.value as? String, "second draft")
        app.terminate()
        app.launchEnvironment.removeValue(forKey: "YK_UI_TEST_SEED")
        app.launch()
        XCTAssertTrue(input.waitForExistence(timeout: 10))
        XCTAssertEqual(input.value as? String, "second draft")
        app.buttons["open-chats"].tap()
        XCTAssertTrue(app.staticTexts["Cafe"].waitForExistence(timeout: 5))
        XCTAssertEqual(rows.count, 2)
        app.buttons[olderID].tap()
        XCTAssertTrue(app.staticTexts["近くの公園を探して"].waitForExistence(timeout: 5))
        XCTAssertEqual(input.value as? String, "first draft")
    }

    @MainActor
    func testVoiceCharacterAndExpressionPersist() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchEnvironment["YK_UI_TEST"] = "1"
        app.launchArguments = ["-AppleLanguages", "(ja)", "-AppleLocale", "ja_JP"]
        app.launch()
        func openVoiceSettings() {
            XCTAssertTrue(app.tabBars.buttons["設定"].waitForExistence(timeout: 15))
            app.tabBars.buttons["設定"].tap()
            for _ in 0..<8 {
                if app.buttons["voice-engine"].isHittable { break }
                app.swipeUp()
            }
        }
        openVoiceSettings()
        app.buttons["voice-engine"].tap()
        app.buttons["VOICEVOX（キャラクター音声）"].tap()
        let character = app.buttons["voice-character"]
        for _ in 0..<4 {
            if character.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(character.isHittable)
        character.tap()
        for name in ["ずんだもん", "四国めたん", "春日部つむぎ", "雨晴はう", "玄野武宏", "青山龍星", "白上虎太郎"] {
            XCTAssertTrue(app.buttons[name].exists)
        }
        let menuShot = XCTAttachment(screenshot: app.screenshot())
        menuShot.name = "Seven voice characters available"
        menuShot.lifetime = .keepAlways
        add(menuShot)
        app.buttons["ずんだもん"].tap()
        app.buttons["voice-style"].tap()
        app.buttons["あまあま"].tap()
        XCTAssertEqual(character.value as? String, "ずんだもん", character.debugDescription)
        XCTAssertEqual(app.buttons["voice-style"].value as? String, "あまあま", app.buttons["voice-style"].debugDescription)
        app.terminate()
        app.launch()
        openVoiceSettings()
        XCTAssertEqual(character.value as? String, "ずんだもん", character.debugDescription)
        XCTAssertEqual(app.buttons["voice-style"].value as? String, "あまあま", app.buttons["voice-style"].debugDescription)
    }

    @MainActor
    func testPhotoModelSetupIsExplicit() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchEnvironment["YK_UI_TEST"] = "1"
        app.launchArguments = ["-AppleLanguages", "(ja)", "-AppleLocale", "ja_JP"]
        app.launch()
        let settings = app.tabBars.buttons["設定"]
        XCTAssertTrue(settings.waitForExistence(timeout: 15))
        settings.tap()
        let download = app.buttons["downloadVisualModel"]
        for _ in 0..<6 {
            if download.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(download.isHittable)
        XCTAssertTrue(download.isEnabled)
        XCTAssertTrue(download.label.contains("1.8GB"))
        XCTAssertFalse(app.buttons["写真AIのデータを削除"].exists)
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Photo AI setup requires explicit Wi-Fi download"
        screenshot.lifetime = .keepAlways
        add(screenshot)
        // Do not download weights or simulate image understanding in UI tests.
    }

    @MainActor
    func testKeyboardAndMessageEditing() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launchEnvironment["YK_UI_TEST"] = "1"
        app.launchEnvironment["YK_UI_TEST_SEED"] = "1"
        app.launchArguments = ["-AppleLanguages", "(ja)", "-AppleLocale", "ja_JP"]
        app.launch()
        let input = app.descendants(matching: .any).matching(identifier: "chat-input").firstMatch
        XCTAssertTrue(input.waitForExistence(timeout: 15))
        input.tap()
        input.typeText("draft")
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        let dismissKeyboard = app.buttons["dismiss-chat-keyboard"]
        let send = app.buttons["send-message"]
        XCTAssertTrue(dismissKeyboard.waitForExistence(timeout: 5))
        XCTAssertTrue(dismissKeyboard.isHittable && send.isHittable && send.isEnabled)
        XCTAssertFalse(dismissKeyboard.frame.intersects(send.frame), "Close keyboard must never cover send")
        XCTAssertLessThanOrEqual(dismissKeyboard.frame.maxY, input.frame.minY,
                                 "Close keyboard belongs above the composer")
        XCTAssertLessThanOrEqual(send.frame.maxY, app.keyboards.firstMatch.frame.minY,
                                 "Send stays above the keyboard")
        let composerShot = XCTAttachment(screenshot: app.screenshot())
        composerShot.name = "Keyboard close and send have separate hit areas"
        composerShot.lifetime = .keepAlways
        add(composerShot)
        dismissKeyboard.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForNonExistence(timeout: 5))
        XCTAssertEqual(input.value as? String, "draft")

        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        app.buttons["chat-title"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForNonExistence(timeout: 5))

        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        let scroll = app.scrollViews["chat-scroll"]
        scroll.swipeDown()
        XCTAssertTrue(app.keyboards.firstMatch.waitForNonExistence(timeout: 5))
        input.tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForExistence(timeout: 5))
        app.staticTexts["近くの公園を探して"].tap()
        XCTAssertTrue(app.keyboards.firstMatch.waitForNonExistence(timeout: 5))

        // Open the oldest user message, then cancel: history and composer stay intact.
        scroll.swipeDown()
        let editButtons = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'edit-'"))
        editButtons.firstMatch.tap()
        XCTAssertTrue(app.navigationBars["文章を編集"].waitForExistence(timeout: 5))
        app.buttons["キャンセル"].tap()
        XCTAssertEqual(input.value as? String, "draft")
        XCTAssertFalse(app.buttons["編集前の会話"].exists)

        editButtons.firstMatch.tap()
        let editor = app.textViews["message-editor"]
        XCTAssertTrue(editor.waitForExistence(timeout: 5))
        editor.coordinate(withNormalizedOffset: CGVector(dx: 0.9, dy: 0.9)).tap()
        // Append ASCII so the test doesn't depend on a particular Japanese keyboard.
        editor.typeText(" please")
        app.buttons["編集キーボードを閉じる"].tap()
        let changed = editor.value as! String
        app.buttons["save-edited-message"].tap()
        XCTAssertTrue(app.staticTexts[changed].waitForExistence(timeout: 5))
        XCTAssertFalse(app.staticTexts["近くの公園を探して"].exists)
        XCTAssertEqual(input.value as? String, "draft")

        app.buttons["編集前の会話"].tap()
        let archive = app.buttons.matching(NSPredicate(format: "identifier BEGINSWITH 'archive-'" )).firstMatch
        XCTAssertTrue(archive.waitForExistence(timeout: 5))
        archive.tap()
        XCTAssertTrue(app.staticTexts["近くのカフェを探して"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["近くの公園を探して"].exists)
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = "Preserved conversation before editing"
        screenshot.lifetime = .keepAlways
        add(screenshot)

        app.terminate()
        app.launchEnvironment.removeValue(forKey: "YK_UI_TEST_SEED")
        app.launch()
        XCTAssertTrue(app.staticTexts[changed].waitForExistence(timeout: 10))
        XCTAssertTrue(app.buttons["編集前の会話"].exists)
        XCTAssertFalse(app.staticTexts["近くの公園を探して"].exists)
    }
}
