#!/bin/bash
set -euo pipefail
task_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$task_root"
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "このチェックはMacのXcode環境で実行してください。"
  exit 1
fi
xcodebuild -version
task_tmp="$(mktemp -d "${TMPDIR:-/tmp}/yk-companion-check.XXXXXX")"
trap 'rm -f "$task_tmp/core-check"; rmdir "$task_tmp" 2>/dev/null || true' EXIT
xcrun swiftc YKCompanion/VoiceCatalog.swift YKCompanion/CaptionQuality.swift YKCompanion/Models.swift YKCompanion/TravelModels.swift YKCompanion/ChatTravel.swift YKCompanion/ChatLibrary.swift YKCompanion/ConversationPrompt.swift YKCompanion/PhotoReaction.swift Tests/main.swift -o "$task_tmp/core-check"
"$task_tmp/core-check"
python3 scripts/prepare-voicevox.py
xcodebuild -project YKCompanion.xcodeproj -scheme YKCompanion \
  -configuration Debug -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath .build-simulator CODE_SIGNING_ALLOWED=NO build
echo "シミュレーター向けビルドまで完了。位置情報・端末内AI・音声・署名は実機で確認してください。"
