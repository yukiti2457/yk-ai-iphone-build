#!/bin/bash
set -euo pipefail
task_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$task_root"
task_build="$1"
# MLX is an Apple Silicon runtime. Keep simulator app and UI tests on arm64
# instead of letting Xcode additionally select the Intel simulator variant.
test "$(uname -m)" = "arm64"
xcodebuild -project YKCompanion.xcodeproj -scheme YKCompanion \
  -configuration Debug -sdk iphonesimulator -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath "$task_build/Simulator" ARCHS=arm64 ONLY_ACTIVE_ARCH=YES CODE_SIGNING_ALLOWED=NO build
device_id="$(xcrun simctl list devices available -j | python3 -c 'import json,sys; devices=json.load(sys.stdin)["devices"]; print(next(d["udid"] for group in devices.values() for d in group if d.get("isAvailable") and d["name"].startswith("iPhone")))')"
xcrun simctl boot "$device_id" || true
xcrun simctl bootstatus "$device_id" -b
xcrun simctl install "$device_id" "$task_build/Simulator/Build/Products/Debug-iphonesimulator/YKCompanion.app"
container="$(xcrun simctl get_app_container "$device_id" local.yukai.companion data)"
python3 - "$container/Documents/TokenizerFixture" <<'PY'
import hashlib,json,pathlib,sys,urllib.request
target=pathlib.Path(sys.argv[1]); target.mkdir(parents=True,exist_ok=True)
manifest=json.loads(pathlib.Path('YKCompanion/VisualModel.json').read_text())
for item in manifest['files']:
    if item['name'] not in ('config.json','tokenizer.json','tokenizer_config.json','chat_template.jinja','chat_template.json'): continue
    data=urllib.request.urlopen(f"https://huggingface.co/{manifest['repository']}/resolve/{manifest['revision']}/{item['name']}",timeout=60).read()
    assert len(data)==item['size'] and hashlib.sha256(data).hexdigest()==item['sha256']
    (target/item['name']).write_bytes(data)
PY
SIMCTL_CHILD_YK_VOICE_SMOKE_TEST=1 xcrun simctl launch "$device_id" local.yukai.companion
for i in $(seq 1 120); do
  if [[ -f "$container/Documents/smoke-success.txt" ]]; then break; fi
  if [[ -f "$container/Documents/smoke-error.txt" ]]; then cat "$container/Documents/smoke-error.txt"; exit 1; fi
  sleep 2
done
test -f "$container/Documents/smoke-success.txt"
cat "$container/Documents/smoke-success.txt"
python3 - "$container/Documents" <<'PY'
import array,json,math,pathlib,sys,wave
p=pathlib.Path(sys.argv[1]); report=[]
catalog=json.loads(pathlib.Path('YKCompanion/VoiceCatalog.json').read_text())
for style in [s['id'] for c in catalog['characters'] for s in c['styles']]+['switched','reloaded']:
    with wave.open(str(p/f'voice-{style}.wav'),'rb') as w:
        assert w.getsampwidth()==2 and w.getnframes()>w.getframerate()/2
        samples=array.array('h',w.readframes(w.getnframes()))
        rms=math.sqrt(sum(v*v for v in samples)/len(samples))
        assert rms>10, f'silent output for {style}'
        report.append({'style':style,'seconds':w.getnframes()/w.getframerate(),'rms':round(rms,2)})
pathlib.Path('dist/SIMULATOR-CHECKS.json').write_text(json.dumps({'voicevox':report,'local_photo_tokenizer':'passed','ocr_and_storage':'passed','physical_iPhone':'not tested','visual_model_inference':'not tested in simulator'},indent=2))
print('PASS: 25 non-silent VOICEVOX styles, group switch, unload/reload synthesis and OCR/image storage')
PY
xcrun simctl io "$device_id" screenshot dist/SIMULATOR-CHAT.png
xcrun simctl terminate "$device_id" local.yukai.companion
xcodebuild -project YKCompanion.xcodeproj -scheme YKCompanion \
  -configuration Debug -sdk iphonesimulator -destination "platform=iOS Simulator,id=$device_id,arch=arm64" \
  -derivedDataPath "$task_build/Simulator" -resultBundlePath "$task_build/ChatInteractions.xcresult" \
  -parallel-testing-enabled NO ARCHS=arm64 ONLY_ACTIVE_ARCH=YES CODE_SIGNING_ALLOWED=NO test
xcrun xcresulttool get test-results summary --path "$task_build/ChatInteractions.xcresult" \
  > dist/UI-TESTS.json
container="$(xcrun simctl get_app_container "$device_id" local.yukai.companion data)"
python3 - "$container/Library/Application Support/YKCompanion/UITestState/state.json" <<'PY'
import json,pathlib,sys
state=json.loads(pathlib.Path(sys.argv[1]).read_text())
assert state['preferences']['voiceEngine']=='voicevox'
assert state['preferences']['voiceStyle']==1
print('PASS: selected zundamon sweet style is saved in the app state')
PY
xcrun xcresulttool export attachments --path "$task_build/ChatInteractions.xcresult" \
  --output-path "$task_build/UIAttachments"
python3 - "$task_build/UIAttachments" <<'PY'
import json,pathlib,shutil,sys
root=pathlib.Path(sys.argv[1])
manifest=json.loads((root/'manifest.json').read_text())
for test in manifest:
    for attachment in test.get('attachments',[]):
        if 'Keyboard close and send have separate hit areas' in attachment.get('suggestedHumanReadableName',''):
            source=(root/attachment['exportedFileName']).resolve()
            assert source.is_relative_to(root.resolve())
            shutil.copyfile(source,'dist/SIMULATOR-COMPOSER.png')
        if 'Seven voice characters available' in attachment.get('suggestedHumanReadableName',''):
            source=(root/attachment['exportedFileName']).resolve()
            assert source.is_relative_to(root.resolve())
            shutil.copyfile(source,'dist/SIMULATOR-VOICES.png')
        if 'Independent chats and saved titles' in attachment.get('suggestedHumanReadableName',''):
            source=(root/attachment['exportedFileName']).resolve()
            assert source.is_relative_to(root.resolve())
            shutil.copyfile(source,'dist/SIMULATOR-SESSIONS.png')
        if 'Short chat reaction and inline guidance proposal' in attachment.get('suggestedHumanReadableName',''):
            source=(root/attachment['exportedFileName']).resolve()
            assert source.is_relative_to(root.resolve())
            shutil.copyfile(source,'dist/SIMULATOR-CHAT-TRAVEL.png')
        if 'Yahoo transit arrival search form' in attachment.get('suggestedHumanReadableName',''):
            source=(root/attachment['exportedFileName']).resolve()
            assert source.is_relative_to(root.resolve())
            shutil.copyfile(source,'dist/SIMULATOR-TRAVEL.png')
assert pathlib.Path('dist/SIMULATOR-CHAT-TRAVEL.png').is_file(), 'Missing chat guidance screenshot'
assert pathlib.Path('dist/SIMULATOR-TRAVEL.png').is_file(), 'Missing transit verification screenshot'
assert pathlib.Path('dist/SIMULATOR-COMPOSER.png').is_file(), 'Missing composer verification screenshot'
assert pathlib.Path('dist/SIMULATOR-VOICES.png').is_file(), 'Missing voice selection screenshot'
assert pathlib.Path('dist/SIMULATOR-SESSIONS.png').is_file(), 'Missing chat sessions verification screenshot'
PY
SIMCTL_CHILD_YK_UI_TEST=1 xcrun simctl launch "$device_id" local.yukai.companion
xcrun simctl io "$device_id" screenshot dist/SIMULATOR-EDIT.png
xcrun simctl terminate "$device_id" local.yukai.companion
