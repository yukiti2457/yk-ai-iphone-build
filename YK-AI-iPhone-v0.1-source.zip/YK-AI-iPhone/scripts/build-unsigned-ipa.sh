#!/bin/bash
set -euo pipefail
task_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$task_root"
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "macOS + Xcode is required. Run this on the GitHub macos-26 runner."
  exit 1
fi
xcodebuild -version
sdk_version="$(xcrun --sdk iphoneos --show-sdk-version)"
if [[ "${sdk_version%%.*}" -lt 26 ]]; then
  echo "An iOS 26+ SDK is required; selected SDK is $sdk_version"
  exit 1
fi
task_build="$(mktemp -d "${RUNNER_TEMP:-${TMPDIR:-/tmp}}/yk-iphone-build.XXXXXX")"
xcrun swiftc YKCompanion/VoiceCatalog.swift YKCompanion/CaptionQuality.swift YKCompanion/Models.swift YKCompanion/TravelModels.swift YKCompanion/ChatTravel.swift YKCompanion/ChatLibrary.swift YKCompanion/ConversationPrompt.swift YKCompanion/PhotoReaction.swift Tests/main.swift -o "$task_build/core-check"
"$task_build/core-check" | tee "$task_build/core-checks.txt"
python3 scripts/prepare-voicevox.py
# MLX compiles Metal kernels as part of the app package.
xcodebuild -downloadComponent MetalToolchain
xcodebuild -project YKCompanion.xcodeproj -scheme YKCompanion \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath "$task_build/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY= \
  build
app_path="$task_build/DerivedData/Build/Products/Release-iphoneos/YKCompanion.app"
test -d "$app_path"
test -f "$app_path/YKCompanion"
test -f "$app_path/Personas.json"
test -f "$app_path/VisualModel.json"
test -f "$app_path/VisualModel-LICENSES.txt"
find "$app_path" -name '*.metallib' | tee "$task_build/metal-libraries.txt"
test -s "$task_build/metal-libraries.txt"
test -f "$app_path/VoiceCatalog.json"
for voice_model in 0 4 9 15; do test -f "$app_path/VoicevoxAssets/$voice_model.vvm"; done
test -f "$app_path/VoicevoxAssets/Licenses/VOICEVOX-Model-Terms.txt"
test -f "$app_path/Frameworks/voicevox_core.framework/voicevox_core"
test -f "$app_path/Frameworks/voicevox_onnxruntime.framework/voicevox_onnxruntime"
mkdir -p "$task_build/package/Payload" dist
cp "$task_build/core-checks.txt" dist/CORE-CHECKS.txt
cp YKCompanion.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved dist/Package.resolved
ditto "$app_path" "$task_build/package/Payload/YKCompanion.app"
ditto -c -k --keepParent "$task_build/package/Payload" dist/YK-AI-iPhone-unsigned.ipa
unzip -t dist/YK-AI-iPhone-unsigned.ipa
shasum -a 256 dist/YK-AI-iPhone-unsigned.ipa > dist/SHA256.txt
printf '%s\n' 'Unsigned iPhone build. Import using AltStore to sign for your own device.' \
  'This is not an App Store release. On-device AI, GPS and voice still need testing.' \
  > dist/INSTALL-NOTE.txt
bash scripts/check-simulator.sh "$task_build"
