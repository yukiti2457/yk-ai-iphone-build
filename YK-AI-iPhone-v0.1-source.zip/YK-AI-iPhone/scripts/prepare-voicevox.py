"""Fetch pinned official iOS dependencies. Runs during build, never on the phone."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
import shutil
import tarfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT / '.voicevox-cache'
VENDOR = ROOT / 'Vendor'
ASSETS = ROOT / 'YKCompanion' / 'VoicevoxAssets'
for directory in (CACHE, VENDOR, ASSETS / 'Licenses'):
    directory.mkdir(parents=True, exist_ok=True)

def fetch(name, url, digest):
    path = CACHE / name
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != digest:
        with urllib.request.urlopen(url, timeout=120) as response:
            path.write_bytes(response.read())
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, f'Checksum failed: {name}'
    print('Verified:', name, flush=True)
    return path

def unzip(path, destination):
    with zipfile.ZipFile(path) as archive:
        for item in archive.infolist():
            target = (destination / item.filename).resolve()
            assert target.is_relative_to(destination.resolve()), item.filename
        archive.extractall(destination)

core = fetch('core.zip',
    'https://github.com/VOICEVOX/voicevox_core/releases/download/0.17.1/voicevox_core-xcframework-0.17.1.zip',
    'd01e1d511895944a86857d736bc0e0a1a079a4ed68f985477f4f327bdb22ec61')
runtime = fetch('runtime.zip',
    'https://github.com/VOICEVOX/onnxruntime-builder/releases/download/voicevox_onnxruntime-1.17.3/voicevox_onnxruntime-ios-xcframework-1.17.3.zip',
    '5b0138f25e68c3fb99771d37978837d5038a67b0720f96d912c900887164494b')
unzip(core, VENDOR)
unzip(runtime, VENDOR)
# Upstream framework identifiers include underscores, rejected by iOS bundle
# validation. Normalize metadata only; binaries, symbols and model stay intact.
for path in VENDOR.glob('*.xcframework/ios-*/*.framework/Info.plist'):
    value = plistlib.loads(path.read_bytes())
    identifier = value['CFBundleIdentifier'].replace('_', '-')
    assert re.fullmatch(r'[A-Za-z0-9.-]+', identifier), identifier
    value['CFBundleIdentifier'] = identifier
    path.write_bytes(plistlib.dumps(value))
dictionary = fetch('dict.tar.gz',
    'https://github.com/r9y9/open_jtalk/releases/download/v1.11.1/open_jtalk_dic_utf_8-1.11.tar.gz',
    'fe6ba0e43542cef98339abdffd903e062008ea170b04e7e2a35da805902f382a')
with tarfile.open(dictionary) as archive:
    # Only ordinary files/directories under the intended resource folder.
    for item in archive.getmembers():
        assert item.isfile() or item.isdir(), item.name
        assert (ASSETS / item.name).resolve().is_relative_to(ASSETS.resolve()), item.name
    archive.extractall(ASSETS, filter='data')
catalog = json.loads((ROOT / 'YKCompanion/VoiceCatalog.json').read_text(encoding='utf-8'))
for item in catalog['models']:
    name = item['name']
    assert re.fullmatch(r'[0-9]+\.vvm', name)
    model = fetch(name,
        f"https://github.com/VOICEVOX/voicevox_vvm/releases/download/{catalog['version']}/{name}", item['sha256'])
    # Verify every exposed style against metadata from the pinned official model.
    with zipfile.ZipFile(model) as archive:
        metadata = json.loads(archive.read('metas.json'))
    actual = {(speaker['name'], style['name'], style['id']) for speaker in metadata for style in speaker['styles']}
    for character in catalog['characters']:
        for style in character['styles']:
            if style['model'] == name:
                assert (character['name'], style['name'], style['id']) in actual, style
    shutil.copyfile(model, ASSETS / name)

licenses = [
 ('VOICEVOX-Model-Terms', 'https://github.com/VOICEVOX/voicevox_vvm/releases/download/0.17.0/README.txt',
  '12a64121db0815fc5e6ea8cdf13cd3ed052b7c7d7a170a70a2c0eced2fc63573'),
 ('VOICEVOX-Core-LICENSE', 'https://raw.githubusercontent.com/VOICEVOX/voicevox_core/0.17.1/LICENSE',
  'f3d1c14bdea7fc3121303662a2e3ce32a7bc1ef3bbd63375a416044df9b2dc59'),
 ('ONNXRuntime-LICENSE', 'https://raw.githubusercontent.com/microsoft/onnxruntime/v1.17.3/LICENSE',
  '2f07c72751aed99790b8a4869cf2311df85a860b22ded05fa22803587a48922c'),
 ('ONNXRuntime-ThirdPartyNotices', 'https://raw.githubusercontent.com/microsoft/onnxruntime/v1.17.3/ThirdPartyNotices.txt',
  '4f9e2bb7b4b407d710a68168615bbc6f70e3d7cc8ba9410fb6c65d92fa71accf'),
]
for name, url, digest in licenses:
    shutil.copyfile(fetch(name + '.txt', url, digest), ASSETS / 'Licenses' / (name + '.txt'))
shutil.copyfile(ASSETS / 'open_jtalk_dic_utf_8-1.11' / 'COPYING',
                ASSETS / 'Licenses' / 'OpenJTalk-Dictionary-COPYING.txt')
print('VOICEVOX iOS assets prepared:', ', '.join('VOICEVOX:' + c['name'] for c in catalog['characters']), flush=True)
